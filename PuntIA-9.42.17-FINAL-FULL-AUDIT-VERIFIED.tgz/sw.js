const CACHE='puntia-9.42.17-shell-v1';
const SHELL=['/','/css/app.css','/js/app.js','/offline-sync.js','/manifest.webmanifest','/assets/mascot/puntia-maestra-v2.svg'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(async c=>{for(const url of SHELL){try{await c.add(url)}catch{}}}).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET')return;event.respondWith(fetch(event.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(event.request,copy)).catch(()=>{});}return r}).catch(()=>caches.match(event.request).then(r=>r||caches.match('/'))));});
