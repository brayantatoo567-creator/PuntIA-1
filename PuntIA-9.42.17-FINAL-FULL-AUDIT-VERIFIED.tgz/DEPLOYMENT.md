# PuntIA 9.42.17 — Despliegue de producción

## Requisitos

- Docker Engine con Compose v2.
- Un dominio HTTPS delante del contenedor (reverse proxy o plataforma cloud).
- PostgreSQL, Redis y almacenamiento S3-compatible administrados externamente.
- Credenciales reales para OpenAI y, si se habilita cobro, Stripe.

## Configuración

1. Copia `.env.example` a `.env.production`.
2. Define `PUNTIA_PUBLIC_URL` con la URL HTTPS real.
3. Define `PUNTIA_CLOUD_MODE=true`, `DATABASE_URL`, `REDIS_URL` y `PUNTIA_STORAGE_BUCKET`.
4. Define `PUNTIA_PERSISTENT_DIR=/data/puntia`.
5. Define `OPENAI_API_KEY` **o** una `PUNTIA_CONFIG_MASTER_KEY` válida de 32 bytes.
6. Define las credenciales administrativas.
7. No subas `.env.production` al repositorio.

## Arranque

```bash
docker compose -f docker-compose.production.yml up -d --build
```

La aplicación escucha en `0.0.0.0:8080` dentro del contenedor. El almacenamiento persistente se monta en `/data/puntia`.

## Comprobaciones

```bash
docker compose -f docker-compose.production.yml ps
docker compose -f docker-compose.production.yml logs --tail=200 puntia
curl -fsS http://127.0.0.1:8080/api/live
curl -fsS http://127.0.0.1:8080/api/ready
```

`/api/live` confirma que el proceso está vivo. `/api/ready` comprueba las dependencias cloud cuando `PUNTIA_CLOUD_MODE=true`.

## Limitación de esta auditoría

El entorno de desarrollo utilizado para esta revisión no dispone del binario Docker, por lo que no se declara una ejecución real del contenedor. La configuración se valida estáticamente y mediante las pruebas del proyecto.
