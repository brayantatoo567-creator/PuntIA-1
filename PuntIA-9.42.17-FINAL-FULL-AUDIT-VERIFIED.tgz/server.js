'use strict';

const { createServer } = require('./src/app/server');
const productConfig = require('./src/core/config');
const { validateProductionConfig } = require('./src/infrastructure/config/production-config');
const { getCloudRuntime, closeCloudRuntime } = require('./src/infrastructure/cloud-runtime');

async function main() {
  const validation = validateProductionConfig(process.env);
  if (!validation.ok) throw new Error(`Configuración inválida: ${validation.errors.join(' ')}`);
  if (String(process.env.PUNTIA_CLOUD_MODE || '').toLowerCase() === 'true') await getCloudRuntime();
  const server = createServer();
  const port = Number.parseInt(process.env.PORT || String(productConfig.app.port || 8080), 10) || 8080;
  const host = String(process.env.PUNTIA_HOST || productConfig.app.host || '127.0.0.1').trim() || '127.0.0.1';
  await server.__puntiaWarmup?.();
  server.listen(port, host, () => {
    console.log(`PuntIA ${productConfig.app.version} escuchando en http://${host}:${port}`);
  });
}

main().catch(async error => {
  console.error(`PuntIA no pudo iniciar: ${error.message}`);
  try { await closeCloudRuntime(); } catch {}
  process.exit(1);
});
