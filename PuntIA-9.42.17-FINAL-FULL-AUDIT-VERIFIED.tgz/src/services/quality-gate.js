'use strict';

const { executePattern } = require('../core/pattern-execution');

const MAX_TEXT = 5000;
const REQUIRED_OPERATION_TYPES = new Set(['single', 'increase', 'decrease']);

function text(value) {
  return typeof value === 'string' ? value.trim() : '';
}

function nonEmptyStringArray(value, label, issues) {
  if (!Array.isArray(value) || value.length === 0) {
    issues.push(`${label}: falta contenido.`);
    return false;
  }
  for (let i = 0; i < value.length; i++) {
    const item = text(value[i]);
    if (!item) issues.push(`${label}[${i + 1}]: debe ser texto no vacío.`);
    else if (item.length > MAX_TEXT) issues.push(`${label}[${i + 1}]: excede el límite de texto.`);
  }
  return true;
}

function evaluatePattern(pattern, validation = null) {
  const issues = [];
  const warnings = [];
  const checks = {
    structure: false,
    mathematics: false,
    readability: false,
    geometry: false,
    pieces: true
  };

  if (!pattern || typeof pattern !== 'object' || Array.isArray(pattern)) {
    return { accepted: false, quality: 0, issues: ['El patrón no es un objeto válido.'], warnings, checks, reason: 'PATTERN_QUALITY_GATE' };
  }

  const title = text(pattern.title);
  if (!title) issues.push('title: falta título.');
  else if (title.length > 200) issues.push('title: excede 200 caracteres.');
  if (!Number.isInteger(Number(pattern.initialStitches)) || Number(pattern.initialStitches) < 1) {
    issues.push('initialStitches: debe ser un entero positivo.');
  }
  nonEmptyStringArray(pattern.materials, 'materials', issues);
  nonEmptyStringArray(pattern.abbreviations, 'abbreviations', issues);
  nonEmptyStringArray(pattern.assembly, 'assembly', issues);
  if (!Array.isArray(pattern.notes)) issues.push('notes: debe ser un arreglo.');
  else if (pattern.notes.some(note => typeof note !== 'string')) issues.push('notes: todos los elementos deben ser texto.');
  checks.structure = issues.length === 0;

  const execution = executePattern(pattern);
  checks.mathematics = execution.ok;
  if (!execution.ok) issues.push(...execution.errors.map(error => `Matemática: ${error}`));

  const rounds = Array.isArray(pattern.rounds) ? pattern.rounds : [];
  if (!rounds.length) issues.push('rounds: debe contener al menos una vuelta.');
  for (let i = 0; i < rounds.length; i++) {
    const round = rounds[i] || {};
    const operations = Array.isArray(round.operations) ? round.operations : [];
    for (const operation of operations) {
      const type = String(operation?.type || '').toLowerCase();
      if (!REQUIRED_OPERATION_TYPES.has(type)) issues.push(`Legibilidad: vuelta ${i + 1} contiene una operación no soportada.`);
      if (!Number.isInteger(Number(operation?.count)) || Number(operation.count) < 1) issues.push(`Legibilidad: vuelta ${i + 1} tiene count inválido.`);
      if (!Number.isInteger(Number(operation?.repeats)) || Number(operation.repeats) < 1) issues.push(`Legibilidad: vuelta ${i + 1} tiene repeats inválido.`);
    }
  }
  checks.readability = rounds.length > 0 && issues.filter(issue => issue.startsWith('Legibilidad:')).length === 0;

  const geometry = pattern.geometry;
  if (geometry !== undefined) {
    const geometryType = text(geometry?.type);
    const height = Number(geometry?.targetHeightCm);
    if (!geometryType) issues.push('Geometría: falta type.');
    if (!Number.isFinite(height) || height <= 0) issues.push('Geometría: targetHeightCm debe ser mayor que cero.');
    checks.geometry = Boolean(geometryType) && Number.isFinite(height) && height > 0;
  } else {
    warnings.push('El patrón no declara geometría; no se puede verificar su objetivo dimensional.');
    checks.geometry = true;
  }

  const piecePlans = Array.isArray(pattern.piecePlans) ? pattern.piecePlans : [];
  if (piecePlans.length) {
    const ids = new Set();
    for (const piece of piecePlans) {
      const id = text(piece?.id);
      if (!id) issues.push('Piezas: existe una pieza sin id.');
      else if (ids.has(id)) issues.push(`Piezas: id duplicado "${id}".`);
      else ids.add(id);
      if (!text(piece?.name)) issues.push(`Piezas: "${id || 'sin id'}" no tiene nombre.`);
      if (!Number.isInteger(Number(piece?.quantity)) || Number(piece.quantity) < 1) issues.push(`Piezas: "${id || 'sin id'}" tiene quantity inválida.`);
      if (!Array.isArray(piece?.rounds) || !piece.rounds.length) issues.push(`Piezas: "${id || 'sin id'}" no tiene rondas.`);
    }
  }
  checks.pieces = !issues.some(issue => issue.startsWith('Piezas:'));

  if (validation && validation.qualityOk !== true) {
    for (const issue of Array.isArray(validation.issues) ? validation.issues : []) {
      if (!issues.includes(issue)) issues.push(issue);
    }
  }

  const failedChecks = Object.entries(checks).filter(([, ok]) => !ok).map(([name]) => name);
  const deductions = failedChecks.length * 20;
  const quality = Math.max(0, 100 - Math.min(100, deductions + Math.min(40, issues.length * 5)));
  const accepted = issues.length === 0 && failedChecks.length === 0 && (!validation || validation.qualityOk === true);

  return {
    accepted,
    quality,
    issues,
    warnings,
    checks,
    failedChecks,
    execution,
    reason: accepted ? 'PASS' : 'PATTERN_QUALITY_GATE'
  };
}

module.exports = { evaluatePattern };
