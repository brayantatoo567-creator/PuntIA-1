'use strict';
const TRANSITIONS = Object.freeze({
  queued: new Set(['running','cancelled','failed']),
  running: new Set(['queued','completed','failed','cancelled','dead_letter']),
  completed: new Set(),
  failed: new Set(['queued','dead_letter']),
  cancelled: new Set()
});
function assertTransition(from,to){
  const a=String(from||'queued'), b=String(to||'');
  if(!TRANSITIONS[a]?.has(b)) throw Object.assign(new Error(`Transición de trabajo no permitida: ${a} → ${b}`),{code:'INVALID_JOB_TRANSITION',status:409});
  return true;
}
function nextRetry(attempt,maxAttempts){return Number(attempt||0)+1 < Number(maxAttempts||3);}
function backoffMs(attempt,base=500,max=30000){const n=Math.max(0,Number(attempt||0));return Math.min(max,base*Math.pow(2,n));}
module.exports={TRANSITIONS,assertTransition,nextRetry,backoffMs};
