# Servicios de dominio

- `quality-gate.js`: política final de aceptación de patrones.
- `job-policy.js`: reglas de reintento para trabajos asíncronos.

Los servicios no deben conocer HTTP, DOM ni secretos.
