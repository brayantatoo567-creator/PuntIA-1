'use strict';
const RETRYABLE=new Set(['RATE_LIMIT','TIMEOUT','UPSTREAM_5XX','NETWORK']);
function shouldRetry(error,attempt,max=2){const code=String(error?.code||'UNKNOWN');return attempt<max&&RETRYABLE.has(code)}
module.exports={shouldRetry};
