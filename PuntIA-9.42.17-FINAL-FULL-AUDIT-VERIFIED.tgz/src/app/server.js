'use strict';

/**
 * Composition root de PuntIA.
 * No contiene reglas de negocio ni detalles de HTTP; únicamente conecta
 * configuración, runtime HTTP y servicios de aplicación.
 */
const { createHttpRuntime } = require('../infrastructure/http/runtime');

function createServer(overrides = {}) {
  return createHttpRuntime(overrides);
}

module.exports = { createServer };
