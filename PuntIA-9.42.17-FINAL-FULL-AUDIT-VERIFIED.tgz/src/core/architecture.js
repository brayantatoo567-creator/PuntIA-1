'use strict';
/** Product boundaries. The current local server remains compatible with Termux while these ports allow cloud adapters to replace JSON storage safely. */
const PORTS=Object.freeze({
  projectRepository:['list','get','create','update','remove'],
  jobQueue:['enqueue','get','claim','complete','fail'],
  objectStorage:['put','get','remove'],
  usageLedger:['reserve','confirm','release'],
  eventSink:['record'],
});
function assertPort(port,name){const required=PORTS[name]||[];for(const method of required)if(typeof port?.[method]!=='function')throw new Error(`Adapter ${name} no implementa ${method}`);return port;}
module.exports={PORTS,assertPort};
