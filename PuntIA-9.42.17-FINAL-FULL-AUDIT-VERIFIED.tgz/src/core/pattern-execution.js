'use strict';

/**
 * Deterministic execution model for the supported stitch operations.
 * It does not simulate physical yarn tension; it verifies the logical stitch
 * consumption/production sequence that a crocheter can actually follow.
 */
function executePattern(pattern, options = {}) {
  const rounds = Array.isArray(pattern?.rounds) ? pattern.rounds : [];
  const initial = Number(pattern?.initialStitches);
  const errors = [];
  const trace = [];
  if (!Number.isInteger(initial) || initial < 1) {
    return { ok: false, errors: ['initialStitches debe ser un entero positivo.'], trace: [], finalStitches: null };
  }
  let available = initial;
  for (let index = 0; index < rounds.length; index++) {
    const round = rounds[index] || {};
    const expectedRound = index + 1;
    const roundNo = Number(round.round);
    if (roundNo !== expectedRound) errors.push(`Vuelta ${expectedRound}: numeración no consecutiva.`);
    const declaredInput = Number(round.inputStitches);
    if (declaredInput !== available) errors.push(`Vuelta ${expectedRound}: entrada declarada ${declaredInput} pero hay ${available} puntos disponibles.`);
    let remaining = available;
    let produced = 0;
    const operations = Array.isArray(round.operations) ? round.operations : [];
    if (!operations.length) errors.push(`Vuelta ${expectedRound}: no hay operaciones ejecutables.`);
    const operationTrace = [];
    for (let opIndex = 0; opIndex < operations.length; opIndex++) {
      const op = operations[opIndex] || {};
      const type = String(op.type || '').toLowerCase();
      const count = Number(op.count);
      const repeats = Number(op.repeats ?? 1);
      if (!Number.isInteger(count) || count < 1 || !Number.isInteger(repeats) || repeats < 1) {
        errors.push(`Vuelta ${expectedRound}, operación ${opIndex + 1}: count/repeats inválidos.`);
        continue;
      }
      let consumeEach, produceEach;
      if (type === 'single') { consumeEach = count; produceEach = count; }
      else if (type === 'increase' && count === 1) { consumeEach = 1; produceEach = 2; }
      else if (type === 'decrease' && count === 1) { consumeEach = 2; produceEach = 1; }
      else {
        errors.push(`Vuelta ${expectedRound}, operación ${opIndex + 1}: operación no soportada o count inválido.`);
        continue;
      }
      const consumed = consumeEach * repeats;
      const made = produceEach * repeats;
      if (consumed > remaining) {
        errors.push(`Vuelta ${expectedRound}, operación ${opIndex + 1}: intenta consumir ${consumed} puntos y solo quedan ${remaining}.`);
        continue;
      }
      remaining -= consumed;
      produced += made;
      operationTrace.push({ index: opIndex + 1, type, count, repeats, consumed, produced: made, remainingInput: remaining });
    }
    if (remaining !== 0) errors.push(`Vuelta ${expectedRound}: quedan ${remaining} puntos sin consumir.`);
    const expected = Number(round.expectedStitches);
    if (Number.isInteger(expected) && produced !== expected) errors.push(`Vuelta ${expectedRound}: ejecución produce ${produced}, expectedStitches=${expected}.`);
    trace.push({ round: expectedRound, inputStitches: available, operations: operationTrace, produced, expectedStitches: Number.isInteger(expected) ? expected : null, ok: remaining === 0 && (!Number.isInteger(expected) || produced === expected) });
    available = Number.isInteger(expected) ? expected : produced;
  }
  const maxRounds = Number(options.maxRounds ?? 500);
  if (rounds.length > maxRounds) errors.push(`El patrón excede el máximo ejecutable de ${maxRounds} vueltas.`);
  return { ok: errors.length === 0, errors, trace, finalStitches: rounds.length ? available : initial };
}

function validateExecutablePattern(pattern, options = {}) {
  const result = executePattern(pattern, options);
  const assembly = Array.isArray(pattern?.assembly) ? pattern.assembly : [];
  const materials = Array.isArray(pattern?.materials) ? pattern.materials : [];
  const issues = [...result.errors];
  if (!materials.length) issues.push('El patrón ejecutable no declara materiales.');
  if (!assembly.length) issues.push('El patrón ejecutable no declara ensamblaje.');
  return { ...result, ok: issues.length === 0, issues, execution: { rounds: result.trace.length, finalStitches: result.finalStitches } };
}

module.exports = { executePattern, validateExecutablePattern };
