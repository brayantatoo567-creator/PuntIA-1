'use strict';

const OP_LABELS = Object.freeze({ single: 'pb', increase: 'aum', decrease: 'dis' });

function operationText(operation) {
  const type = String(operation?.type || '').toLowerCase();
  const count = Number(operation?.count);
  const repeats = Number(operation?.repeats ?? 1);
  if (!OP_LABELS[type] || !Number.isInteger(count) || !Number.isInteger(repeats) || count < 1 || repeats < 1) {
    return null;
  }
  const stitch = OP_LABELS[type];
  if (type === 'single') {
    return repeats === 1 ? `${count} ${stitch}` : `${count} ${stitch} por ${repeats} repeticiones`;
  }
  return repeats === 1 ? `${stitch}` : `${stitch} × ${repeats}`;
}

function roundInstruction(roundData) {
  if (!roundData || !Array.isArray(roundData.operations) || !roundData.operations.length) return null;
  const parts = roundData.operations.map(operationText);
  if (parts.some(part => !part)) return null;
  return {
    round: Number(roundData.round),
    inputStitches: Number(roundData.inputStitches),
    instruction: parts.length === 1 ? parts[0] : parts.join(', '),
    expectedStitches: Number(roundData.expectedStitches),
    operations: parts
  };
}

function buildPieceInstructions(piece) {
  if (!piece?.id || !Array.isArray(piece.rounds) || !piece.rounds.length) return null;
  const rounds = piece.rounds.map(roundInstruction);
  if (rounds.some(round => !round)) return null;
  const quantity = Number(piece.quantity);
  return {
    id: piece.id,
    name: String(piece.name || piece.id),
    quantity: Number.isInteger(quantity) && quantity > 0 ? quantity : 1,
    geometry: String(piece.geometry || 'custom'),
    targetHeightCm: Number.isFinite(Number(piece.targetHeightCm)) ? Number(piece.targetHeightCm) : null,
    rounds,
    materials: Array.isArray(piece.materials) ? [...piece.materials] : [],
    abbreviations: Array.isArray(piece.abbreviations) ? [...piece.abbreviations] : [],
    assembly: Array.isArray(piece.assembly) ? [...piece.assembly] : []
  };
}

function buildPatternReader(pattern) {
  if (!pattern || !Array.isArray(pattern.rounds) || !pattern.rounds.length) {
    return { ok: false, issues: ['El patrón no tiene vueltas para convertir a instrucciones.'] };
  }
  const rounds = pattern.rounds.map(roundInstruction);
  if (rounds.some(round => !round)) return { ok: false, issues: ['Existe una vuelta con operaciones inválidas o incompletas.'] };

  const piecePlans = Array.isArray(pattern.piecePlans) ? pattern.piecePlans : [];
  const pieces = piecePlans.map(buildPieceInstructions);
  if (pieces.some(piece => !piece)) return { ok: false, issues: ['Existe una pieza con un plan de instrucciones inválido.'] };

  const materials = Array.isArray(pattern.materials) ? [...pattern.materials] : [];
  const abbreviations = Array.isArray(pattern.abbreviations) ? [...pattern.abbreviations] : [];
  const assembly = Array.isArray(pattern.assembly) ? [...pattern.assembly] : [];
  const guidedSteps = [
    { step: 1, type: 'prepare', title: 'Prepara materiales', instruction: materials.length ? `Prepara: ${materials.join(', ')}.` : 'Prepara el estambre y las herramientas necesarias.' },
    { step: 2, type: 'read', title: 'Lee las abreviaturas', instruction: abbreviations.length ? `Abreviaturas: ${abbreviations.join(', ')}.` : 'Usa las abreviaturas indicadas en el patrón.' },
    { step: 3, type: 'start', title: 'Comienza', instruction: `Inicia con ${Number(pattern.initialStitches)} puntos.` },
    ...rounds.map(round => ({ step: round.round + 3, type: 'round', round: round.round, title: `Vuelta ${round.round}`, instruction: round.instruction, expectedStitches: round.expectedStitches })),
    { step: rounds.length + 4, type: 'assembly', title: 'Ensambla', instruction: assembly.length ? assembly.join(' ') : 'Une las piezas según su posición.' }
  ];

  return {
    ok: true,
    title: String(pattern.title || 'Patrón de crochet'),
    start: { initialStitches: Number(pattern.initialStitches) },
    materials,
    abbreviations,
    rounds,
    pieces,
    assembly,
    guidedSteps
  };
}

function validatePatternReader(pattern, reader = buildPatternReader(pattern)) {
  const issues = [];
  if (!reader?.ok) return { ok: false, issues: reader?.issues || ['Lector inválido.'] };
  if (reader.rounds.length !== pattern.rounds.length) issues.push('El lector no conserva todas las vueltas.');
  for (let i = 0; i < reader.rounds.length; i++) {
    const source = pattern.rounds[i];
    const rendered = reader.rounds[i];
    if (rendered.round !== source.round || rendered.inputStitches !== source.inputStitches || rendered.expectedStitches !== source.expectedStitches) {
      issues.push(`La vuelta ${i + 1} perdió datos matemáticos.`);
    }
  }
  if (Array.isArray(pattern.piecePlans) && reader.pieces.length !== pattern.piecePlans.length) issues.push('El lector perdió piezas.');
  if (!reader.guidedSteps.length) issues.push('No se generaron pasos guiados.');
  return { ok: issues.length === 0, issues };
}

module.exports = { operationText, roundInstruction, buildPieceInstructions, buildPatternReader, validatePatternReader };
