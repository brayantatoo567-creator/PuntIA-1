'use strict';

const COLORS = ['negro','blanco','rojo','azul','verde','amarillo','naranja','rosa','morado','lila','violeta','café','marrón','gris','turquesa','dorado','plateado'];
const FEATURES = [
  ['ojos','eyes'], ['ojo','eyes'], ['alas','wings'], ['ala','wings'], ['cola','tail'], ['colas','tail'],
  ['cuernos','horns'], ['cuerno','horns'], ['orejas','ears'], ['oreja','ears'], ['patas','legs'], ['pata','legs'],
  ['brazos','arms'], ['brazo','arms'], ['piernas','legs'], ['pierna','legs'], ['hocico','muzzle'], ['nariz','nose'],
  ['aletas','fins'], ['aleta','fins'], ['antenas','antennae'], ['antena','antennae'], ['mochila','backpack'],
  ['sombrero','hat'], ['corona','crown'], ['vestido','dress'], ['ropa','clothing'], ['capucha','hood']
];
const CATEGORIES = [
  ['dragón','fantasy'],['dragon','fantasy'],['dinosaurio','animal'],['gato','animal'],['perro','animal'],['oso','animal'],
  ['conejo','animal'],['zorro','animal'],['lobo','animal'],['pájaro','animal'],['ave','animal'],['pez','animal'],
  ['personaje','character'],['persona','character'],['humano','character'],['muñeca','character'],['robot','character'],
  ['monstruo','fantasy'],['unicornio','fantasy'],['hada','fantasy'],['alien','fantasy'],['planta','plant'],['flor','plant'],
  ['corazón','object'],['estrella','object'],['comida','food'],['pastel','food'],['fruta','food'],['objeto','object']
];
const ALWAYS_PIECES = [
  { id:'body', name:'Cuerpo principal', role:'main', geometry:'body', required:true, order:1 },
  { id:'head', name:'Cabeza', role:'main', geometry:'head', required:false, order:2 }
];

function clean(value, max=2000) {
  return String(value ?? '').replace(/\s+/g,' ').trim().slice(0,max);
}
function normalizeKey(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
}
function unique(values) { return [...new Set(values)]; }

function parseDimensions(text, fallbackHeight) {
  const matches = [...text.matchAll(/(\d+(?:[.,]\d+)?)\s*(?:cm|cent[ií]metros?)/gi)].map(m=>Number(String(m[1]).replace(',','.'))).filter(n=>n>0 && n<=1000);
  const height = matches[0] || Number(String(fallbackHeight || '').replace(',','.')) || null;
  return { heightCm: height, source: matches.length ? 'text' : (height ? 'input' : 'unspecified') };
}

function detectCategory(text) {
  const key = normalizeKey(text);
  for (const [term, category] of CATEGORIES) if (key.includes(normalizeKey(term))) return category;
  return 'custom';
}

function detectFeatures(text) {
  const key = normalizeKey(text);
  return unique(FEATURES.filter(([term])=>key.includes(normalizeKey(term))).map(([,feature])=>feature));
}

function buildPieces(features, category) {
  const pieces = ALWAYS_PIECES.map(x=>({...x}));
  const add = (id,name,role,geometry,required=false)=>{ if(!pieces.some(p=>p.id===id)) pieces.push({id,name,role,geometry,required,order:pieces.length+1}); };
  if (category === 'object' || category === 'food' || category === 'plant') pieces.splice(1,1);
  if (features.includes('eyes')) add('eyes','Ojos','detail','flat',false);
  if (features.includes('wings')) add('wings','Alas','appendage','wing',true);
  if (features.includes('tail')) add('tail','Cola','appendage','tail',false);
  if (features.includes('horns')) add('horns','Cuernos','detail','cone',false);
  if (features.includes('ears')) add('ears','Orejas','appendage','ear',false);
  if (features.includes('legs')) add('legs','Patas','appendage','limb',false);
  if (features.includes('arms')) add('arms','Brazos','appendage','limb',false);
  if (features.includes('fins')) add('fins','Aletas','appendage','wing',false);
  if (features.includes('antennae')) add('antennae','Antenas','appendage','limb',false);
  if (features.includes('hat')) add('hat','Sombrero','accessory','custom',false);
  if (features.includes('crown')) add('crown','Corona','accessory','custom',false);
  return pieces.map((p,i)=>({...p,order:i+1}));
}

function interpretConcept(input = {}) {
  const raw = clean(input.description ?? input.name ?? input.prompt, 2000);
  if (!raw) throw Object.assign(new Error('Describe qué quieres convertir en un amigurumi.'), { code:'CONCEPT_DESCRIPTION_REQUIRED', status:400 });
  const normalized = normalizeKey(raw);
  const dimensions = parseDimensions(raw, input.height);
  const colors = unique(COLORS.filter(c=>normalized.includes(normalizeKey(c))));
  const features = detectFeatures(raw);
  const category = detectCategory(raw);
  const pieces = buildPieces(features, category);
  const subject = raw.replace(/\b(?:de|con)\s+\d+(?:[.,]\d+)?\s*cm\b/gi,'').trim() || raw;
  const clarification = category === 'custom';
  return {
    version:'1.0', source:'deterministic-text-interpreter', input:raw, subject, category,
    dimensions, colors, features,
    pieces,
    constraints:[],
    requiresClarification:clarification,
    clarification: clarification ? 'El concepto es libre. Se conservará como pieza personalizada; si quieres más precisión, indica forma, partes y tamaño.' : null
  };
}

function validateConceptCoverage(concept, pattern) {
  const assembly = Array.isArray(pattern?.assembly) ? pattern.assembly.join(' ').toLowerCase() : '';
  const notes = Array.isArray(pattern?.notes) ? pattern.notes.join(' ').toLowerCase() : '';
  const searchable = `${assembly} ${notes}`;
  const missing = [];
  for (const piece of (concept?.pieces || [])) {
    if (!piece.required || piece.id === 'body') continue;
    const aliases = { eyes:['ojo','ojos'], wings:['ala','alas'], tail:['cola','colas'], horns:['cuerno','cuernos'], ears:['oreja','orejas'], legs:['pata','patas','pierna','piernas'], arms:['brazo','brazos'], fins:['aleta','aletas'], antennae:['antena','antenas'] }[piece.id] || [piece.name];
    if (!aliases.some(alias => searchable.includes(alias))) missing.push(piece.id);
  }
  return { ok: missing.length === 0, missing, issues: missing.map(id => `La pieza requerida "${id}" no aparece en assembly/notes.`) };
}

function conceptPromptBlock(concept) {
  return JSON.stringify({
    subject:concept.subject, category:concept.category, dimensions:concept.dimensions,
    colors:concept.colors, features:concept.features,
    pieces:concept.pieces.map(p=>({id:p.id,name:p.name,role:p.role,geometry:p.geometry,required:p.required})),
    rule:'El patrón final debe representar las piezas requeridas en assembly/notes y no inventar piezas incompatibles con el concepto.'
  });
}

module.exports = { interpretConcept, conceptPromptBlock, validateConceptCoverage, COLORS, FEATURES, CATEGORIES };
