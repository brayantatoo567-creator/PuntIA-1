'use strict';

const { validateExecutablePattern } = require('./pattern-execution');

const GEOMETRY_TYPES = new Set(['sphere','cylinder','cone','limb','head','body','ear','wing','tail','flat','custom']);

function geometryQuality(pattern) {
  const rounds = Array.isArray(pattern?.rounds) ? pattern.rounds : [];
  const geometry = pattern?.geometry || {};
  let score = 0;
  const issues = [];
  if (GEOMETRY_TYPES.has(String(geometry.type || '').toLowerCase())) score += 25;
  else issues.push('geometry.type no especificado');
  if (Number(geometry.targetHeightCm) > 0 || Number(geometry.targetDiameterCm) > 0) score += 25;
  else issues.push('falta objetivo dimensional');
  if (rounds.length >= 2) score += 25;
  else issues.push('insuficientes vueltas para evaluación geométrica');
  if (Array.isArray(pattern.assembly) && pattern.assembly.length) score += 25;
  else issues.push('falta ensamblaje');
  return { score, issues };
}

function validatePattern(pattern, options = {}) {
  const strict = options.strict === true;
  const rounds = Array.isArray(pattern?.rounds) ? pattern.rounds : [];
  const issues = [];
  const checked = [];
  if (!rounds.length) return { ok:false, issues:['El patrón no contiene vueltas.'], rounds:[], totalRounds:0, quality:0 };
  if (rounds.length > 500) return { ok:false, issues:['El patrón contiene demasiadas vueltas.'], rounds:[], totalRounds:rounds.length, quality:0 };
  const initial = Number(pattern?.initialStitches);
  const hasInitialStitches = Number.isInteger(initial) && initial > 0;
  let previous = hasInitialStitches ? initial : null;
  if (previous === null) issues.push('Falta initialStitches: la primera vuelta debe declarar el número de puntos de entrada.');
  const seen = new Set();
  for (let i = 0; i < rounds.length; i++) {
    const r = rounds[i] || {};
    const roundNumber = Number(r.round);
    if (!Number.isInteger(roundNumber) || roundNumber !== i + 1) issues.push(`Vuelta ${i + 1}: la numeración debe ser consecutiva.`);
    if (seen.has(roundNumber)) issues.push(`Vuelta ${i + 1}: número de vuelta duplicado.`);
    seen.add(roundNumber);
    const operations = Array.isArray(r.operations) ? r.operations : [];
    if (!operations.length) issues.push(`Vuelta ${i + 1}: no contiene operaciones.`);
    let produced = 0, consumed = 0;
    for (const op of operations) {
      const type = String(op?.type || '').toLowerCase();
      const count = Number(op?.count);
      const repeats = Number(op?.repeats ?? 1);
      if (!['single','increase','decrease'].includes(type)) { issues.push(`Vuelta ${i + 1}: operación “${type || 'vacía'}” no soportada.`); continue; }
      if (!Number.isInteger(count) || count < 1 || count > 1000 || !Number.isInteger(repeats) || repeats < 1 || repeats > 1000) { issues.push(`Vuelta ${i + 1}: count/repeats inválidos.`); continue; }
      if ((type === 'increase' || type === 'decrease') && count !== 1) { issues.push(`Vuelta ${i + 1}: ${type === 'increase' ? 'aum' : 'disminución'} debe usar count=1.`); continue; }
      if (type === 'single') { produced += count * repeats; consumed += count * repeats; }
      else if (type === 'increase') { produced += 2 * repeats; consumed += repeats; }
      else { produced += repeats; consumed += 2 * repeats; }
    }
    const expected = Number(r.expectedStitches);
    const declaredInput = r.inputStitches === undefined || r.inputStitches === null ? null : Number(r.inputStitches);
    if (!Number.isInteger(expected) || expected < 1 || expected > 100000) issues.push(`Vuelta ${i + 1}: expectedStitches debe ser un entero positivo.`);
    if (declaredInput !== null && (!Number.isInteger(declaredInput) || declaredInput < 1)) issues.push(`Vuelta ${i + 1}: inputStitches inválido.`);
    if (Number.isInteger(expected) && operations.length && produced !== expected) issues.push(`Vuelta ${i + 1}: las operaciones producen ${produced} puntos, pero expectedStitches indica ${expected}.`);
    if (previous !== null && declaredInput !== null && declaredInput !== previous) issues.push(`Vuelta ${i + 1}: inputStitches (${declaredInput}) no coincide con la entrada esperada (${previous}).`);
    if (previous !== null && consumed !== previous) issues.push(`Vuelta ${i + 1}: las operaciones consumen ${consumed} puntos, pero hay ${previous} disponibles.`);
    const ok = operations.length > 0 && Number.isInteger(expected) && produced === expected && previous !== null && consumed === previous && (declaredInput === null || declaredInput === previous);
    checked.push({ round:i + 1, calculated:produced, consumed, expected:Number.isInteger(expected) ? expected : null, input:previous, ok });
    if (Number.isInteger(expected)) previous = expected;
  }
  const semantic = [];
  if (!Array.isArray(pattern.materials) || pattern.materials.length === 0) semantic.push('Faltan materiales.');
  if (!Array.isArray(pattern.abbreviations)) semantic.push('Faltan abreviaturas.');
  if (!Array.isArray(pattern.assembly)) semantic.push('Falta información de ensamblaje.');
  if (strict && semantic.length) issues.push(...semantic);
  const quality = Math.max(0, Math.round(100 - Math.min(80, issues.length * 8)));
  const geometry = geometryQuality(pattern);
  const geometryRequired = Boolean(pattern?.geometry);
  const finalQuality = Math.round(quality * 0.7 + geometry.score * 0.3);
  if (strict && geometryRequired) issues.push(...geometry.issues);
  const execution = validateExecutablePattern(pattern);
  if (strict && !execution.ok) issues.push(...execution.issues.map(x => `Ejecución: ${x}`));
  const ok = issues.length === 0;
  return { ok, qualityOk:ok && finalQuality >= 80, issues, rounds:checked, totalRounds:rounds.length, quality:finalQuality, geometry, geometryRequired, execution, semanticChecks:{materials:Array.isArray(pattern.materials)&&pattern.materials.length>0,abbreviations:Array.isArray(pattern.abbreviations),assembly:Array.isArray(pattern.assembly),initialStitches:hasInitialStitches} };
}

function extractFirstJsonObject(text) {
  const source = String(text || ''); let start = -1, depth = 0, inString = false, escaped = false;
  for (let i = 0; i < source.length; i++) {
    const c = source[i];
    if (start < 0) { if (c === '{') { start = i; depth = 1; } continue; }
    if (inString) { if (escaped) escaped = false; else if (c === '\\') escaped = true; else if (c === '"') inString = false; continue; }
    if (c === '"') { inString = true; continue; }
    if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) { try { return JSON.parse(source.slice(start, i + 1)); } catch { return null; } } }
  }
  return null;
}

module.exports = { GEOMETRY_TYPES, geometryQuality, validatePattern, extractFirstJsonObject };
