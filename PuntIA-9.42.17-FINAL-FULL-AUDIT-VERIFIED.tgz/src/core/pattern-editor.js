'use strict';

const { validatePattern } = require('./pattern-engine');
const { executePattern } = require('./pattern-execution');
const { planPatternPieces, validatePieceCoverageByPlan } = require('./pattern-piece-planner');
const { buildPatternReader, validatePatternReader } = require('./pattern-reader');

const MAX_SCALE = 4;
const MIN_SCALE = 0.25;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function numberOrNull(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }

function synthesizeRound(inputStitches, desiredOutput, roundNumber) {
  if (!Number.isInteger(inputStitches) || inputStitches < 1 || !Number.isInteger(desiredOutput) || desiredOutput < 1) {
    throw Object.assign(new Error('Dimensiones incompatibles con un patrón ejecutable.'), { code:'EDITOR_INVALID_STITCH_TARGET' });
  }
  const delta = desiredOutput - inputStitches;
  const operations = [];
  if (delta > 0) operations.push({ type:'increase', count:1, repeats:delta });
  const neutral = inputStitches - Math.max(delta, 0);
  if (neutral > 0) operations.push({ type:'single', count:1, repeats:neutral });
  if (delta < 0) {
    const decreases = -delta;
    if (decreases * 2 > inputStitches) {
      throw Object.assign(new Error(`La vuelta ${roundNumber} no puede disminuir de ${inputStitches} a ${desiredOutput} con la gramática actual.`), { code:'EDITOR_UNREPRESENTABLE_ROUND' });
    }
    operations.length = 0;
    operations.push({ type:'decrease', count:1, repeats:decreases });
    const neutralAfter = inputStitches - (decreases * 2);
    if (neutralAfter > 0) operations.push({ type:'single', count:1, repeats:neutralAfter });
  }
  return { round:roundNumber, inputStitches, operations, expectedStitches:desiredOutput };
}

function resizePattern(pattern, scale) {
  const factor = Number(scale);
  if (!Number.isFinite(factor) || factor < MIN_SCALE || factor > MAX_SCALE) {
    throw Object.assign(new Error(`sizeScale debe estar entre ${MIN_SCALE} y ${MAX_SCALE}.`), { code:'EDITOR_INVALID_SIZE_SCALE', status:400 });
  }
  const rounds = Array.isArray(pattern?.rounds) ? pattern.rounds : [];
  if (!rounds.length) throw Object.assign(new Error('El patrón no tiene vueltas para redimensionar.'), { code:'EDITOR_NO_ROUNDS', status:422 });
  const initial = Math.max(1, Math.round(Number(pattern.initialStitches) * factor));
  const targets = rounds.map(r => Math.max(1, Math.round(Number(r.expectedStitches) * factor)));
  const rebuilt = [];
  let input = initial;
  for (let i = 0; i < targets.length; i++) rebuilt.push(synthesizeRound(input, targets[i], i + 1)), input = targets[i];
  const result = { ...clone(pattern), initialStitches:initial, rounds:rebuilt };
  if (result.geometry && Number.isFinite(Number(result.geometry.targetHeightCm))) result.geometry.targetHeightCm = Math.max(0.1, Math.round(Number(result.geometry.targetHeightCm) * factor * 10) / 10);
  if (result.piecePlans) result.piecePlans = result.piecePlans.map(piece => {
    const next = { ...piece, initialStitches:Math.max(1, Math.round(Number(piece.initialStitches || 6) * factor)) };
    const pieceRounds = Array.isArray(piece.rounds) ? piece.rounds : [];
    if (pieceRounds.length) {
      let pieceInput = next.initialStitches;
      next.rounds = pieceRounds.map((r, i) => {
        const target = Math.max(1, Math.round(Number(r.expectedStitches) * factor));
        const rebuiltRound = synthesizeRound(pieceInput, target, i + 1);
        pieceInput = target;
        return rebuiltRound;
      });
      if (Number.isFinite(Number(next.targetHeightCm))) next.targetHeightCm = Math.max(0.1, Math.round(Number(next.targetHeightCm) * factor * 10) / 10);
    }
    return next;
  });
  return result;
}

function applyColorChanges(pattern, colors) {
  if (colors === undefined) return pattern;
  if (!Array.isArray(colors) || !colors.length || colors.length > 30 || colors.some(c => typeof c !== 'string' || !c.trim() || c.length > 80)) {
    throw Object.assign(new Error('colors debe ser una lista no vacía de nombres válidos.'), { code:'EDITOR_INVALID_COLORS', status:400 });
  }
  const next = clone(pattern);
  next.design = { ...(next.design || {}), colors:[...new Set(colors.map(c => c.trim()))] };
  return next;
}

function applyDifficulty(pattern, difficulty) {
  if (difficulty === undefined) return pattern;
  const allowed = new Set(['Principiante','Intermedio','Avanzado']);
  if (!allowed.has(String(difficulty))) throw Object.assign(new Error('Nivel inválido.'), { code:'EDITOR_INVALID_DIFFICULTY', status:400 });
  const next = clone(pattern);
  next.design = { ...(next.design || {}), difficulty:String(difficulty) };
  next.notes = Array.isArray(next.notes) ? next.notes.filter(n => !String(n).startsWith('Nivel de dificultad:')) : [];
  next.notes.push(`Nivel de dificultad: ${difficulty}.`);
  return next;
}

function applyPieceChanges(pattern, changes, concept) {
  if (!changes) return pattern;
  if (!Array.isArray(pattern.piecePlans)) throw Object.assign(new Error('El patrón no contiene piezas editables.'), { code:'EDITOR_PIECE_PLANS_REQUIRED', status:422 });
  const next = clone(pattern);
  const remove = new Set(Array.isArray(changes.remove) ? changes.remove.map(String) : []);
  if (remove.size) {
    const required = new Set((concept?.pieces || []).filter(p => p.required).map(p => p.id));
    for (const id of remove) if (required.has(id)) throw Object.assign(new Error(`No se puede eliminar la pieza requerida "${id}".`), { code:'EDITOR_REQUIRED_PIECE', status:422 });
    next.piecePlans = next.piecePlans.filter(p => !remove.has(String(p.id)));
  }
  if (Array.isArray(changes.rename)) {
    for (const item of changes.rename) {
      if (!item || !item.id || typeof item.name !== 'string' || !item.name.trim()) throw Object.assign(new Error('Cada renombrado requiere id y name.'), { code:'EDITOR_INVALID_RENAME', status:400 });
      const piece = next.piecePlans.find(p => p.id === item.id);
      if (!piece) throw Object.assign(new Error(`No existe la pieza "${item.id}".`), { code:'EDITOR_PIECE_NOT_FOUND', status:404 });
      piece.name = item.name.trim().slice(0,120);
    }
  }
  return next;
}

function editPattern({ pattern, changes = {}, concept = null } = {}) {
  if (!pattern || typeof pattern !== 'object') throw Object.assign(new Error('pattern es obligatorio.'), { code:'EDITOR_PATTERN_REQUIRED', status:400 });
  const before = clone(pattern);
  let next = clone(pattern);
  if (changes.sizeScale !== undefined) next = resizePattern(next, changes.sizeScale);
  next = applyColorChanges(next, changes.colors);
  next = applyDifficulty(next, changes.difficulty);
  next = applyPieceChanges(next, changes.pieces, concept);

  if (concept && Array.isArray(next.piecePlans)) {
    const coverage = validatePieceCoverageByPlan(concept, next.piecePlans);
    if (!coverage.ok) throw Object.assign(new Error(coverage.issues.join(' ')), { code:'EDITOR_PIECE_COVERAGE', status:422, details:coverage });
  }

  const execution = executePattern(next);
  if (!execution.ok) throw Object.assign(new Error(`El patrón editado no es ejecutable: ${execution.errors.join(' ')}`), { code:'EDITOR_EXECUTION_FAILED', status:422, details:execution });
  const validation = validatePattern(next, { strict:true });
  if (!validation.qualityOk) throw Object.assign(new Error(`El patrón editado no supera el Quality Gate: ${validation.issues.join(' ')}`), { code:'EDITOR_QUALITY_GATE', status:422, details:validation });

  if (concept && Array.isArray(next.piecePlans)) {
    const pieceValidations = next.piecePlans.map(piece => validatePattern({ initialStitches:piece.initialStitches, rounds:piece.rounds, materials:piece.materials || ['estambre'], abbreviations:piece.abbreviations || ['pb','aum','dis'], assembly:piece.assembly || ['Unir al cuerpo.'], geometry:{type:piece.geometry || 'custom',targetHeightCm:Number(piece.targetHeightCm)||1} }, { strict:true }));
    const bad = pieceValidations.flatMap((v,i)=>v.qualityOk?[]:[`${next.piecePlans[i].id}: ${v.issues.join(' ')}`]);
    if (bad.length) throw Object.assign(new Error(bad.join(' ')), { code:'EDITOR_PIECE_EXECUTION_FAILED', status:422, details:{issues:bad} });
  }
  next.reader = buildPatternReader(next);
  const readerValidation = validatePatternReader(next, next.reader);
  if (!readerValidation.ok) throw Object.assign(new Error(readerValidation.issues.join(' ')), { code:'EDITOR_READER_FAILED', status:422, details:readerValidation });
  return {
    ok:true,
    pattern:next,
    changes:clone(changes),
    before,
    execution,
    validation,
    readerValidation,
    changed:JSON.stringify(before) !== JSON.stringify(next)
  };
}

module.exports = { editPattern, resizePattern, synthesizeRound, MIN_SCALE, MAX_SCALE };
