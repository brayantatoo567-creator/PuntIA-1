'use strict';

const { executePattern } = require('./pattern-execution');

const PIECE_ALIASES = Object.freeze({
  body: ['cuerpo', 'cuerpo principal'], head: ['cabeza'], eyes: ['ojo', 'ojos'], wings: ['ala', 'alas'],
  tail: ['cola'], horns: ['cuerno', 'cuernos'], ears: ['oreja', 'orejas'], legs: ['pata', 'patas'],
  arms: ['brazo', 'brazos'], fins: ['aleta', 'aletas'], antennae: ['antena', 'antenas'], hat: ['sombrero'], crown: ['corona']
});

function quantityFor(id) {
  return new Set(['eyes','wings','legs','arms','ears','fins','antennae']).has(id) ? 2 : 1;
}

function op(type, count, repeats) { return { type, count, repeats }; }
function round(round, inputStitches, operations, expectedStitches) { return { round, inputStitches, operations, expectedStitches }; }

function baseRounds(geometry) {
  switch (geometry) {
    case 'body': case 'head': case 'sphere':
      return [round(1,6,[op('single',6,1)],6), round(2,6,[op('increase',1,6)],12), round(3,12,[op('increase',1,12)],24), round(4,24,[op('decrease',1,12)],12), round(5,12,[op('decrease',1,6)],6)];
    case 'cone':
      return [round(1,6,[op('single',6,1)],6), round(2,6,[op('decrease',1,3)],3)];
    case 'flat': case 'ear': case 'wing':
      return [round(1,6,[op('single',6,1)],6), round(2,6,[op('increase',1,6)],12)];
    case 'limb': case 'tail': case 'cylinder':
      return [round(1,6,[op('single',6,1)],6), round(2,6,[op('single',6,1)],6), round(3,6,[op('single',6,1)],6)];
    default:
      return [round(1,6,[op('single',6,1)],6)];
  }
}

function cloneRounds(rounds) { return rounds.map(r => ({ ...r, operations: r.operations.map(o => ({ ...o })) })); }

function normalizeGeometry(piece) {
  return ['sphere','cylinder','cone','head','body','limb','ear','wing','tail','flat','custom'].includes(piece?.geometry) ? piece.geometry : 'custom';
}

function targetFor(piece, concept, pattern) {
  const overall = Number(concept?.dimensions?.heightCm) || Number(pattern?.geometry?.targetHeightCm) || null;
  if (!overall) return null;
  const ratio = piece.id === 'body' ? 0.55 : piece.id === 'head' ? 0.30 : 0.18;
  return Math.max(1, Math.round(overall * ratio * 10) / 10);
}

function buildPiecePlan(piece, concept, pattern) {
  const geometry = normalizeGeometry(piece);
  const sourceRounds = piece.id === 'body' && Array.isArray(pattern?.rounds) && pattern.rounds.length ? cloneRounds(pattern.rounds) : baseRounds(geometry);
  const initialStitches = sourceRounds[0]?.inputStitches || 6;
  const targetHeightCm = targetFor(piece, concept, pattern);
  return {
    id: piece.id,
    name: piece.name,
    role: piece.role,
    geometry,
    required: Boolean(piece.required),
    quantity: quantityFor(piece.id),
    construction: 'crocheted',
    initialStitches,
    rounds: sourceRounds,
    targetHeightCm,
    materials: ['estambre'],
    abbreviations: ['pb', 'aum', 'dis'],
    assembly: piece.id === 'body' ? ['Pieza principal; unir las demás piezas según su posición.'] : [`Unir ${piece.name.toLowerCase()} al cuerpo principal según el ensamblaje.`],
    source: piece.id === 'body' && pattern?.rounds?.length ? 'approved-main-pattern' : 'deterministic-piece-template'
  };
}

function validatePiecePlan(plan) {
  if (!plan || !plan.id || !Array.isArray(plan.rounds) || !plan.rounds.length) return { ok:false, issues:['La pieza no tiene un plan de rondas.'] };
  const executable = executePattern({ initialStitches:plan.initialStitches, rounds:plan.rounds });
  const issues = [...(executable.errors || [])];
  if (!Number.isInteger(plan.quantity) || plan.quantity < 1) issues.push('quantity inválida.');
  if (!plan.geometry) issues.push('geometry ausente.');
  return { ok: issues.length === 0, issues, execution:executable };
}

function planPatternPieces(concept, pattern) {
  const pieces = Array.isArray(concept?.pieces) ? concept.pieces : [];
  if (!pieces.length) return { ok:false, issues:['El concepto no contiene piezas.'], piecePlans:[] };
  const piecePlans = pieces.map(piece => buildPiecePlan(piece, concept, pattern));
  const validations = piecePlans.map(validatePiecePlan);
  const invalid = validations.flatMap((v,i) => v.ok ? [] : v.issues.map(issue => `${piecePlans[i].id}: ${issue}`));
  const missingRequired = pieces.filter(p => p.required && !piecePlans.some(plan => plan.id === p.id)).map(p => p.id);
  const issues = [...invalid, ...missingRequired.map(id => `Falta plan ejecutable para pieza requerida "${id}".`)];
  return { ok:issues.length === 0, issues, piecePlans, validations };
}

function validatePieceCoverageByPlan(concept, piecePlans) {
  const ids = new Set((piecePlans || []).map(p => p.id));
  const missing = (concept?.pieces || []).filter(p => p.required && !ids.has(p.id)).map(p => p.id);
  return { ok:missing.length === 0, missing, issues:missing.map(id => `La pieza requerida "${id}" no tiene plan.`) };
}

module.exports = { planPatternPieces, validatePiecePlan, validatePieceCoverageByPlan, PIECE_ALIASES };
