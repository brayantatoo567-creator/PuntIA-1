'use strict';
function env(name, fallback=''){const value=process.env[name];return value==null||String(value).trim()===''?fallback:String(value).trim();}
module.exports={
  app:{name:'PuntIA',version:'9.42.17',host:env('PUNTIA_HOST','127.0.0.1'),port:Number(env('PORT','8080'))||8080,publicUrl:env('PUNTIA_PUBLIC_URL','')},
  ai:{chatModel:env('PUNTIA_CHAT_MODEL',env('OPENAI_MODEL','gpt-6-luna')),patternModel:env('PUNTIA_PATTERN_MODEL',env('OPENAI_PATTERN_MODEL','gpt-6-sol')),visionModel:env('PUNTIA_VISION_MODEL',env('OPENAI_VISION_MODEL','gpt-6-sol')),imageModel:env('PUNTIA_IMAGE_MODEL','gpt-image-2')},
  persistence:{databaseUrl:env('DATABASE_URL',''),redisUrl:env('REDIS_URL',''),objectStorage:env('OBJECT_STORAGE_ENDPOINT','')},
  security:{nodeEnv:env('NODE_ENV','development'),trustProxy:env('PUNTIA_TRUST_PROXY','false')==='true'}
};
