'use strict';

const PROJECT_STATUSES = Object.freeze(['idea','pattern','pattern_ready','in_progress','completed']);
const JOB_STATUSES = Object.freeze(['queued','running','completed','failed','cancelled','dead_letter']);
const USAGE_KINDS = Object.freeze(['pattern','chat','image','vision','pdf']);
const PLANS = Object.freeze(['free','premium','pro']);
const VISUAL_ASSET_STATES = Object.freeze(['generated','validating','accepted','rejected','superseded']);

function contractError(code, message, status=400, details={}) {
  return Object.assign(new Error(message), { code, status, details });
}
function requireId(value, field='id') {
  const v = String(value || '').trim();
  if (!v) throw contractError('INVALID_ID', `${field} es obligatorio.`);
  if (v.length > 128) throw contractError('INVALID_ID', `${field} excede el límite.`);
  return v;
}
function ownerId(userOrId) {
  const id = typeof userOrId === 'object' ? userOrId?.id : userOrId;
  return id ? requireId(id, 'ownerId') : 'local';
}
function normalizeProjectInput(input={}, existing={}, owner='local') {
  const source = input && typeof input === 'object' ? input : {};
  const current = existing && typeof existing === 'object' ? existing : {};
  const resolvedOwner = ownerId(owner);
  if (source.status !== undefined && !PROJECT_STATUSES.includes(source.status)) throw contractError('INVALID_PROJECT_STATUS','Estado de proyecto inválido.');
  if (source.progress !== undefined && (!Number.isFinite(Number(source.progress)) || Number(source.progress) < 0 || Number(source.progress) > 100)) throw contractError('INVALID_PROJECT_PROGRESS','El progreso debe estar entre 0 y 100.');
  const version = Number(current.version || 1);
  if (!Number.isInteger(version) || version < 1) throw contractError('INVALID_PROJECT_VERSION','Versión de proyecto inválida.');
  return {
    ...current,
    id: current.id || source.id || requireId(requireIdLike(source.id), 'id'),
    ownerId: resolvedOwner,
    title: String(source.title ?? current.title ?? 'Proyecto sin nombre').trim().slice(0,120) || 'Proyecto sin nombre',
    description: String(source.description ?? current.description ?? '').slice(0,1000),
    level: String(source.level ?? current.level ?? 'Principiante').slice(0,40) || 'Principiante',
    size: String(source.size ?? current.size ?? '').slice(0,60),
    style: String(source.style ?? current.style ?? '').slice(0,120),
    status: source.status ?? current.status ?? 'idea',
    progress: Number(source.progress ?? current.progress ?? 0),
    pattern: String(source.pattern ?? current.pattern ?? '').slice(0,50000),
    image: String(source.image ?? current.image ?? '').slice(0,2000000),
    notes: String(source.notes ?? current.notes ?? '').slice(0,5000),
    assets: normalizeProjectAssets(source.assets ?? current.assets),
    progressState: normalizeProgressState(source.progressState ?? current.progressState),
    visualIdentity: normalizeVisualIdentity(source.visualIdentity ?? current.visualIdentity),
    versions: Array.isArray(current.versions) ? current.versions.slice(-20) : [],
    lastMutationKey: String(source.idempotencyKey ?? current.lastMutationKey ?? '').slice(0,200),
    version,
    createdAt: current.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}
function requireIdLike(value) { return value ? String(value) : cryptoRandomId(); }
function cryptoRandomId() { return require('crypto').randomUUID(); }
function normalizeProjectAssets(value=[]) {
  const list=Array.isArray(value)?value:[];
  return list.slice(-100).map((a,i)=>({
    id:String(a?.id||`${i+1}` ).slice(0,128),
    type:String(a?.type||'other').slice(0,40),
    url:String(a?.url||'').slice(0,2000),
    key:String(a?.key||'').slice(0,500),
    patternHash:String(a?.patternHash||'').slice(0,128),
    state:VISUAL_ASSET_STATES.includes(a?.state)?a.state:'generated',
    supersedesAssetId:String(a?.supersedesAssetId||'').slice(0,128),
    version:Number.isInteger(Number(a?.version))?Number(a.version):1,
    createdAt:String(a?.createdAt||new Date().toISOString()),
    metadata:a?.metadata&&typeof a.metadata==='object'?a.metadata:{}
  }));
}
function normalizeProgressState(value={}) {
  const v=value&&typeof value==='object'?value:{};
  return {
    currentRound:Math.max(0,Number(v.currentRound||0)),
    completedRounds:Array.isArray(v.completedRounds)?v.completedRounds.map(Number).filter(Number.isInteger).slice(-500):[],
    stitchesCompleted:Math.max(0,Number(v.stitchesCompleted||0)),
    lastCheckpoint:String(v.lastCheckpoint||'').slice(0,240),
    updatedAt:String(v.updatedAt||new Date().toISOString())
  };
}
function normalizeVisualIdentity(value={}) {
  const v = value && typeof value === 'object' ? value : {};
  return {
    subject: String(v.subject || '').slice(0,300),
    palette: Array.isArray(v.palette) ? v.palette.map(x=>String(x).slice(0,60)).slice(0,12) : [],
    style: String(v.style || '').slice(0,160),
    proportions: String(v.proportions || '').slice(0,500)
  };
}
function assertProject(project) {
  if (!project || typeof project !== 'object') throw contractError('INVALID_PROJECT','Proyecto inválido.');
  requireId(project.id,'project.id'); requireId(project.ownerId,'project.ownerId');
  if (!PROJECT_STATUSES.includes(project.status)) throw contractError('INVALID_PROJECT_STATUS','Estado de proyecto inválido.');
  if (!Number.isInteger(Number(project.version)) || Number(project.version) < 1) throw contractError('INVALID_PROJECT_VERSION','Versión de proyecto inválida.');
  if (!Number.isFinite(Number(project.progress)) || Number(project.progress)<0 || Number(project.progress)>100) throw contractError('INVALID_PROJECT_PROGRESS','Progreso de proyecto inválido.');
  project.assets=normalizeProjectAssets(project.assets); project.progressState=normalizeProgressState(project.progressState);
  return project;
}
function normalizeJob(job) {
  if (!job || typeof job !== 'object') throw contractError('INVALID_JOB','Trabajo inválido.');
  const out = {...job, id:requireId(job.id,'job.id'), ownerId:ownerId(job.ownerId), status:job.status || 'queued', progress:Number(job.progress ?? 0)};
  if (!JOB_STATUSES.includes(out.status)) throw contractError('INVALID_JOB_STATUS','Estado de trabajo inválido.');
  if (!Number.isFinite(out.progress) || out.progress<0 || out.progress>100) throw contractError('INVALID_JOB_PROGRESS','Progreso de trabajo inválido.');
  if (out.kind && !USAGE_KINDS.includes(out.kind)) throw contractError('INVALID_JOB_KIND','Tipo de trabajo inválido.');
  if (out.attempts !== undefined && (!Number.isInteger(Number(out.attempts)) || Number(out.attempts) < 0)) throw contractError('INVALID_JOB_ATTEMPTS','Intentos de trabajo inválidos.');
  if (out.maxAttempts !== undefined && (!Number.isInteger(Number(out.maxAttempts)) || Number(out.maxAttempts) < 1)) throw contractError('INVALID_JOB_MAX_ATTEMPTS','Máximo de intentos inválido.');
  if (out.progressMessage !== undefined) out.progressMessage = String(out.progressMessage).slice(0,240);
  if (out.idempotencyKey !== undefined) out.idempotencyKey = String(out.idempotencyKey).slice(0,200);
  return out;
}
function assertUsageKind(kind) { if (!USAGE_KINDS.includes(kind)) throw contractError('INVALID_USAGE_KIND','Tipo de consumo inválido.'); return kind; }
function normalizeUsageSnapshot(value={}) {
  const v=value&&typeof value==='object'?value:{};
  const out={period:String(v.period||''),pattern:0,chat:0,image:0,vision:0,pdf:0};
  for(const k of USAGE_KINDS) out[k]=Math.max(0,Number(v[k]||0));
  return out;
}
function normalizePlan(plan) { return PLANS.includes(plan) ? plan : 'free'; }
function assertApiError(error) {
  return { ok:false, error:String(error?.message||'Error interno.'), code:String(error?.code||'REQUEST_ERROR'), status:Number(error?.status)||500 };
}
function assertPatternResult(result) {
  if (!result || typeof result !== 'object') throw contractError('INVALID_PATTERN_RESULT','Resultado de patrón inválido.');
  if (!result.validation || typeof result.validation !== 'object') throw contractError('INVALID_PATTERN_RESULT','Falta la validación del patrón.');
  return result;
}
function assertJob(job) {
  return normalizeJob(job);
}
function assertProjectList(value) {
  if (!Array.isArray(value)) throw contractError('INVALID_PROJECT_LIST','El repositorio devolvió una lista de proyectos inválida.');
  return value.map(assertProject);
}
function assertQueueResult(job) {
  if (job == null) return null;
  return assertJob(job);
}
function assertObjectPutResult(result) {
  if (!result || typeof result !== 'object' || !requireId(result.key,'object.key') || !Number.isFinite(Number(result.size)) || Number(result.size) < 0) {
    throw contractError('INVALID_OBJECT_RESULT','Resultado de almacenamiento inválido.');
  }
  return {key:String(result.key), size:Number(result.size)};
}
function assertUsageReservation(result) {
  if (!result || typeof result !== 'object') throw contractError('INVALID_USAGE_RESERVATION','Reserva de uso inválida.');
  if (typeof result.allowed !== 'boolean') throw contractError('INVALID_USAGE_RESERVATION','Falta allowed en la reserva.');
  if (!Number.isFinite(Number(result.used)) || Number(result.used) < 0) throw contractError('INVALID_USAGE_RESERVATION','used inválido en la reserva.');
  if (!(Number.isFinite(Number(result.limit)) || result.limit === Infinity)) throw contractError('INVALID_USAGE_RESERVATION','limit inválido en la reserva.');
  if (result.reservationId != null) requireId(result.reservationId,'reservationId');
  return result;
}
module.exports={PROJECT_STATUSES,JOB_STATUSES,USAGE_KINDS,PLANS,VISUAL_ASSET_STATES,contractError,requireId,ownerId,normalizeProjectInput,normalizeProjectAssets,normalizeProgressState,normalizeVisualIdentity,assertProject,assertProjectList,normalizeJob,assertJob,assertQueueResult,assertObjectPutResult,assertUsageReservation,assertUsageKind,normalizeUsageSnapshot,normalizePlan,assertApiError,assertPatternResult};
