# Controllers

Capa reservada para traducción HTTP -> comandos de aplicación.

Las rutas actuales ya delegan en `src/application`. Los controladores se incorporarán
por módulo sin introducir lógica de negocio en HTTP.
