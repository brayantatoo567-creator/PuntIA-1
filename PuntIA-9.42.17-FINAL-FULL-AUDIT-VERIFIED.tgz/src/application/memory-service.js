'use strict';
const crypto = require('crypto');

const MAX_CONVERSATIONS = 20;
const MAX_TURNS = 60;
const MAX_PATTERNS = 20;
const MAX_TEXT = 12000;

function createMemoryService(deps = {}) {
  const file = deps.MEMORY_FILE;
  const ownerOf = user => String(user?.id || user || 'local').trim() || 'local';
  const cloud = () => deps.cloud?.memoryRepo || null;

  function normalizeText(value, max = MAX_TEXT) { return String(value || '').trim().slice(0, max); }
  function id() { return crypto.randomUUID(); }
  function now() { return new Date().toISOString(); }

  function readLocal() {
    if (!file) return {};
    const value = deps.loadJsonFile ? deps.loadJsonFile(file, {}) : {};
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  }
  function writeLocal(value) { if (file && deps.saveJsonFile) deps.saveJsonFile(file, value); }

  function ensureBucket(store, owner) {
    if (!store[owner] || typeof store[owner] !== 'object') store[owner] = { conversations: [], patterns: [] };
    if (!Array.isArray(store[owner].conversations)) store[owner].conversations = [];
    if (!Array.isArray(store[owner].patterns)) store[owner].patterns = [];
    return store[owner];
  }

  async function conversation(ownerId, conversationId = null) {
    const repo = cloud();
    if (repo) return repo.getConversation(ownerId, conversationId);
    const store = readLocal(); const bucket = ensureBucket(store, ownerId);
    return bucket.conversations.find(x => !conversationId || x.id === conversationId) || null;
  }

  async function saveConversation(ownerId, value) {
    const repo = cloud();
    if (repo) return repo.upsertConversation(ownerId, value);
    const store = readLocal(); const bucket = ensureBucket(store, ownerId);
    const i = bucket.conversations.findIndex(x => x.id === value.id);
    if (i >= 0) bucket.conversations[i] = value; else bucket.conversations.unshift(value);
    bucket.conversations = bucket.conversations.slice(0, MAX_CONVERSATIONS);
    writeLocal(store); return value;
  }

  async function appendTurn(user, { conversationId = null, role, text, context = {} } = {}) {
    const owner = ownerOf(user); const clean = normalizeText(text);
    if (!clean) throw Object.assign(new Error('El mensaje no puede estar vacío.'), { code:'MEMORY_EMPTY_TEXT', status:400 });
    let current = await conversation(owner, conversationId);
    if (!current) current = { id: conversationId || id(), ownerId: owner, title: clean.slice(0, 80), turns: [], createdAt: now(), updatedAt: now() };
    const turn = { id:id(), role: role === 'assistant' ? 'assistant' : 'user', text:clean, context: context && typeof context === 'object' ? {
      projectId: normalizeText(context.projectId, 128), patternId: normalizeText(context.patternId, 128), round:Number.isFinite(Number(context.round)) ? Number(context.round) : null
    } : {}, createdAt:now() };
    current.turns = [...(Array.isArray(current.turns) ? current.turns : []), turn].slice(-MAX_TURNS);
    current.updatedAt = now();
    await saveConversation(owner, current);
    return current;
  }

  async function rememberPattern(user, { pattern, input = {}, model = null, projectId = null } = {}) {
    const owner = ownerOf(user); if (!pattern || typeof pattern !== 'object') return null;
    const serialized = JSON.stringify(pattern); const entry = {
      id:id(), ownerId:owner, name:normalizeText(input.name || pattern.name || 'Patrón', 160),
      pattern: serialized.slice(0, 120000), patternHash:crypto.createHash('sha256').update(serialized).digest('hex'),
      model:normalizeText(model, 120), projectId:normalizeText(projectId, 128), createdAt:now()
    };
    const repo = cloud();
    if (repo) return repo.addPattern(owner, entry);
    const store = readLocal(); const bucket = ensureBucket(store, owner);
    bucket.patterns = [entry, ...bucket.patterns.filter(x => x.patternHash !== entry.patternHash)].slice(0, MAX_PATTERNS);
    writeLocal(store); return entry;
  }

  async function recent(user, { conversationId = null, limit = 12 } = {}) {
    const owner = ownerOf(user); const current = await conversation(owner, conversationId);
    const repo = cloud();
    const patterns = repo ? await repo.listPatterns(owner, MAX_PATTERNS) : (() => { const store=readLocal(); return ensureBucket(store,owner).patterns.slice(0,MAX_PATTERNS); })();
    return { conversation: current, turns: (current?.turns || []).slice(-Math.max(1, Math.min(20, Number(limit)||12))), patterns };
  }

  async function contextForChat(user, { conversationId = null, limit = 12 } = {}) {
    const memory = await recent(user, { conversationId, limit });
    return {
      conversationId: memory.conversation?.id || conversationId || null,
      recentTurns: memory.turns.map(t => ({ role:t.role, text:t.text, createdAt:t.createdAt })),
      generatedPatterns: memory.patterns.map(p => ({ id:p.id, name:p.name, patternHash:p.patternHash, projectId:p.projectId, createdAt:p.createdAt }))
    };
  }

  async function forgetUser(userId) {
    const owner = ownerOf(userId); const repo = cloud();
    if (repo) return repo.deleteUser(owner);
    const store = readLocal(); const had = Boolean(store[owner]); delete store[owner]; if (had) writeLocal(store); return had ? 1 : 0;
  }

  return { appendTurn, rememberPattern, recent, contextForChat, forgetUser, constants:{MAX_CONVERSATIONS,MAX_TURNS,MAX_PATTERNS} };
}
module.exports = { createMemoryService };
