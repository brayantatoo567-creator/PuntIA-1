'use strict';

/** Server-authoritative billing/entitlement policy. Stripe transport remains in the route/adapter layer. */
function createBillingService(deps) {
  async function entitlement(user) {
    if (!user?.id) return { plan:'free', status:'guest', access:false };
    if (deps.cloud?.billingRepo) return deps.cloud.billingRepo.entitlement(user.id);
    return deps.billingEffectiveLocal ? deps.billingEffectiveLocal(user.id) : { plan:user.plan || 'free', status:'local', access:(user.plan || 'free') !== 'free' };
  }
  function plans() {
    return {
      free: { id:'free', label:'Gratis', price:0, currency:'MXN', interval:'month', limits:deps.FREE_LIMITS, features:['5 patrones/mes','40 mensajes/mes','3 imágenes/mes','3 análisis visuales/mes','3 exportaciones/mes'] },
      premium: { id:'premium', label:'PuntIA Plus', price:99, currency:'MXN', interval:'month', limits:deps.PREMIUM_LIMITS, features:['80 patrones/mes','800 mensajes/mes','40 imágenes/mes','40 análisis visuales/mes','40 exportaciones/mes'] },
      pro: { id:'pro', label:'PuntIA Pro', price:199, currency:'MXN', interval:'month', limits:deps.PRO_LIMITS, features:['250 patrones/mes','2500 mensajes/mes','120 imágenes/mes','120 análisis visuales/mes','120 exportaciones/mes'] }
    };
  }
  return {
    plans,
    usage(user) { return deps.usagePayload(user); },
    validatePlan(plan) { return deps.validatePlan(plan); },
    entitlement,
    canUsePaidFeatures: async user => (await entitlement(user)).access
  };
}
module.exports = { createBillingService };
