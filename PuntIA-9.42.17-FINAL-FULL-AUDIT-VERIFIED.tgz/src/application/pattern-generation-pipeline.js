'use strict';

const { contractError } = require('../core/contracts');
const { validateConceptCoverage } = require('../core/concept-decomposition');
const { planPatternPieces, validatePieceCoverageByPlan } = require('../core/pattern-piece-planner');
const { buildPatternReader, validatePatternReader } = require('../core/pattern-reader');
const { evaluatePattern } = require('../services/quality-gate');

/**
 * Single authoritative pattern-generation pipeline.
 * AI may propose/repair; only the domain validator can approve.
 */
function createPatternGenerationPipeline(deps, services) {
  const maxAttempts = 3;

  function normalizeInput(input = {}) {
    const name = deps.safeText(input.name || input.description || input.prompt, 300).trim();
    if (!name) throw contractError('MISSING_PATTERN_NAME', 'Falta la descripción del patrón.');
    const concept = services.pattern.interpretConcept({ ...input, name });
    return {
      name,
      description: deps.safeText(input.description || input.name || input.prompt, 2000),
      level: deps.safeText(input.level, 50) || 'Principiante',
      height: deps.safeText(input.height, 60),
      style: deps.safeText(input.style, 120) || 'kawaii',
      concept,
      referenceImage: typeof input.referenceImage === 'string' ? input.referenceImage.slice(0, 120000) : null
    };
  }

  function buildPrompt(input, issues = []) {
    const repair = issues.length
      ? `\nREPARACIÓN OBLIGATORIA. El intento anterior falló estas validaciones: ${issues.join(' | ')}. Regenera TODO el JSON desde cero y corrige cada problema. No conserves errores.`
      : '';
    return `${services.pattern.buildPrompt(input)}${repair}`;
  }

  async function generate({ user = null, input = {}, persist = false, reservation = null, correlationId = null, jobId = null } = {}) {
    const normalized = normalizeInput(input);
    let lastValidation = null;
    let lastRaw = '';
    let lastStructured = null;
    let lastModel = null;
    let repaired = false;
    let attemptsUsed = 0;

    const audit = services.audit;
    const actorId = user?.id || null;
    await audit?.record({ action:'pattern.generation.started', resourceType:'pattern', actorId, correlationId, metadata:{ jobId, name:normalized.name, persist, conceptCategory:normalized.concept.category, pieceCount:normalized.concept.pieces.length } });
    try {
      if (!reservation && services.usage) {
        const quota = await services.usage.reserve(user, 'pattern');
        if (!quota.allowed) {
          throw Object.assign(new Error(`Límite mensual de patrones alcanzado (${quota.limit}).`), { code: 'USAGE_LIMIT', status: 429 });
        }
        reservation = quota.reservationId ? quota : null;
      }

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        attemptsUsed = attempt;
        const callProvider = () => deps.openaiPostModelFallback('responses', {
          instructions: `${deps.SYSTEM} Eres el motor profesional de patrones de PuntIA. Calcula cada vuelta con precisión matemática. Nunca declares válido un patrón que no pase la validación del motor.`,
          input: [{ role: 'user', content: buildPrompt(normalized, lastValidation?.issues || []) }],
          text: { format: services.pattern.responseFormat() }
        }, deps.runtime.patternModel || deps.PATTERN_MODEL, deps.runtime.textModel || deps.CHAT_MODEL);
        const routed = services.observability?.run
          ? await services.observability.run('pattern-provider', callProvider, { correlationId })
          : await callProvider();

        lastModel = routed.model;
        const providerCost = services.costAccounting?.recordProviderUsage({ model:routed.model, kind:'pattern', response:routed.data, userId:actorId, requestId:correlationId, metadata:{ attempt, fallback:Boolean(routed.fallback) } });
        lastRaw = deps.outputText(routed.data) || '';
        lastStructured = services.pattern.extract(lastRaw);
        lastValidation = lastStructured ? deps.validatePattern(lastStructured, { strict: true }) : null;
        if (lastStructured && lastValidation?.qualityOk) {
          const coverage = validateConceptCoverage(normalized.concept, lastStructured);
          if (!coverage.ok) {
            lastValidation = { ...lastValidation, qualityOk:false, ok:false, issues:[...lastValidation.issues, ...coverage.issues], conceptCoverage:coverage };
          } else {
            const piecePlan = planPatternPieces(normalized.concept, lastStructured);
            const pieceCoverage = validatePieceCoverageByPlan(normalized.concept, piecePlan.piecePlans);
            if (!piecePlan.ok || !pieceCoverage.ok) {
              lastValidation = {
                ...lastValidation,
                qualityOk:false,
                ok:false,
                issues:[...lastValidation.issues, ...piecePlan.issues, ...pieceCoverage.issues],
                conceptCoverage:coverage,
                piecePlanning:piecePlan,
                pieceCoverage
              };
            } else {
              lastStructured = { ...lastStructured, piecePlans: piecePlan.piecePlans };
              const reader = buildPatternReader(lastStructured);
              const readerValidation = validatePatternReader(lastStructured, reader);
              if (!readerValidation.ok) {
                lastValidation = { ...lastValidation, qualityOk:false, ok:false, issues:[...lastValidation.issues, ...readerValidation.issues], readerValidation, conceptCoverage:coverage, piecePlanning:piecePlan, pieceCoverage };
              } else {
                lastStructured = { ...lastStructured, reader };
                const qualityGate = evaluatePattern(lastStructured, lastValidation);
                if (!qualityGate.accepted) {
                  lastValidation = { ...lastValidation, qualityOk:false, ok:false, issues:[...lastValidation.issues, ...qualityGate.issues], qualityGate, conceptCoverage:coverage, piecePlanning:piecePlan, pieceCoverage, readerValidation };
                } else {
                  lastValidation = { ...lastValidation, conceptCoverage:coverage, piecePlanning:piecePlan, pieceCoverage, readerValidation, qualityGate };
                }
              }
            }
          }
        }

        if (lastStructured && lastValidation?.qualityOk) {
          if (attempt > 1) repaired = true;
          break;
        }
      }

      if (!lastStructured || !lastValidation?.qualityOk) {
        const error = Object.assign(new Error('El Quality Gate rechazó el patrón después de todos los intentos.'), {
          code: 'PATTERN_QUALITY_GATE',
          status: 422,
          details: { validation: lastValidation, attempts: maxAttempts }
        });
        throw error;
      }

      // Persistence is explicit. The HTTP generation endpoint only generates;
      // project creation is a separate user action. Never silently report an
      // approved pattern as persisted when no persistence adapter exists.
      let persisted = false;
      if (persist) {
        if (typeof deps.persistApprovedPattern !== 'function') {
          throw Object.assign(new Error('La persistencia del patrón no está configurada.'), {
            code: 'PATTERN_PERSISTENCE_UNAVAILABLE',
            status: 503
          });
        }
        await deps.persistApprovedPattern({ user, input: normalized, pattern: lastStructured, validation: lastValidation, model: lastModel });
        persisted = true;
      }
      // Compatibility fallback for isolated legacy tests; production uses real provider usage above.
      if (!services.costAccounting && typeof deps.recordCost === 'function') deps.recordCost(lastModel, 'pattern', deps.estimateCost('pattern'));
      if (reservation) await services.usage.confirm(user, 'pattern', reservation.reservationId);
      // Persist a compact memory reference after approval. Memory is non-authoritative: a
      // memory-store failure must never invalidate an already approved pattern.
      try { await services.memory?.rememberPattern(user, { pattern:lastStructured, input:normalized, model:lastModel }); } catch (memoryError) {
        await audit?.record({ action:'pattern.memory.failed', resourceType:'pattern', actorId, correlationId, status:'failure', metadata:{ code:memoryError?.code || 'MEMORY_WRITE_FAILED' } });
      }

      await audit?.record({ action:'pattern.generation.approved', resourceType:'pattern', actorId, correlationId, status:'success', metadata:{ jobId, model:lastModel, attempts:attemptsUsed, repaired, persisted, validation:{ qualityOk:true } } });
      return {
        ok: true,
        pattern: lastRaw,
        concept: normalized.concept,
        structured: lastStructured,
        validation: lastValidation,
        model: lastModel,
        repaired,
        attempts: attemptsUsed,
        persisted,
        mode: 'provider'
      };
    } catch (error) {
      await audit?.record({ action:'pattern.generation.failed', resourceType:'pattern', actorId, correlationId, status:'failure', metadata:{ jobId, code:error?.code || 'UNKNOWN', status:error?.status || 500, attempts:attemptsUsed, lastModel } });
      if (reservation) {
        try { await services.usage.release(user, 'pattern', reservation.reservationId); } catch {}
      }
      throw error;
    }
  }

  return { generate, normalizeInput };
}

module.exports = { createPatternGenerationPipeline };
