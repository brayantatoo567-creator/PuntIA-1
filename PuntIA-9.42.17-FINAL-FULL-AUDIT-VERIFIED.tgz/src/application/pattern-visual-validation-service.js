'use strict';
const crypto = require('crypto');

const VISUAL_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['matchesPattern','confidence','criticalMismatches','observations'],
  properties: {
    matchesPattern: { type: 'boolean' },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    criticalMismatches: { type: 'array', items: { type: 'string', maxLength: 300 }, maxItems: 12 },
    observations: { type: 'array', items: { type: 'string', maxLength: 500 }, maxItems: 20 },
    detectedMaterials: { type: 'array', items: { type: 'string', maxLength: 120 }, maxItems: 30 },
    detectedGeometry: { type: 'string', maxLength: 200 },
    detectedParts: { type: 'array', items: { type: 'string', maxLength: 120 }, maxItems: 30 }
  }
};

function createPatternVisualValidationService(deps, services) {
  const MIN_CONFIDENCE = 0.80;

  function hashPattern(pattern) {
    return crypto.createHash('sha256').update(JSON.stringify(pattern)).digest('hex');
  }

  function normalizeResult(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw Object.assign(new Error('El verificador visual no devolvió un objeto JSON válido.'), { code: 'VISUAL_VALIDATION_SCHEMA', status: 502 });
    const confidence = Number(value.confidence);
    if (typeof value.matchesPattern !== 'boolean' || !Number.isFinite(confidence) || confidence < 0 || confidence > 1) {
      throw Object.assign(new Error('La respuesta del verificador visual no cumple el contrato.'), { code: 'VISUAL_VALIDATION_SCHEMA', status: 502 });
    }
    return {
      matchesPattern: value.matchesPattern,
      confidence,
      criticalMismatches: Array.isArray(value.criticalMismatches) ? value.criticalMismatches.map(x => String(x).slice(0,300)).slice(0,12) : [],
      observations: Array.isArray(value.observations) ? value.observations.map(x => String(x).slice(0,500)).slice(0,20) : [],
      detectedMaterials: Array.isArray(value.detectedMaterials) ? value.detectedMaterials.map(x => String(x).slice(0,120)).slice(0,30) : [],
      detectedGeometry: value.detectedGeometry ? String(value.detectedGeometry).slice(0,200) : null,
      detectedParts: Array.isArray(value.detectedParts) ? value.detectedParts.map(x => String(x).slice(0,120)).slice(0,30) : []
    };
  }

  function extractJson(text) {
    const parsed = deps.extractFirstJsonObject ? deps.extractFirstJsonObject(text) : null;
    if (parsed && typeof parsed === 'object') return parsed;
    try { return JSON.parse(String(text || '')); } catch { return null; }
  }

  function buildPrompt(pattern) {
    const geometry = pattern.geometry || {};
    const materials = Array.isArray(pattern.materials) ? pattern.materials.join(', ') : '';
    const assembly = Array.isArray(pattern.assembly) ? pattern.assembly.join('; ') : '';
    const rounds = Array.isArray(pattern.rounds) ? pattern.rounds.length : 0;
    const parts = Array.isArray(pattern.parts) ? pattern.parts.join(', ') : '';
    return [
      'Actúa como inspector visual de crochet/amigurumi de PuntIA.',
      'Compara exclusivamente la imagen con el patrón VALIDADO que se proporciona.',
      `Título: ${String(pattern.title || '').slice(0,300)}.`,
      `Geometría esperada: ${String(geometry.type || 'custom')}; altura objetivo: ${String(geometry.targetHeightCm || 'no especificada')} cm.`,
      `Materiales/colores declarados: ${materials || 'no especificados'}.`,
      `Construcción: ${rounds} rondas; ensamblaje: ${assembly || 'no especificado'}.`,
      `Partes declaradas: ${parts || 'no especificadas'}.`,
      'Marca matchesPattern=true SOLO si la imagen representa de forma razonablemente fiel el objeto y sus partes principales.',
      'Marca false ante extremidades, accesorios o estructuras principales incompatibles, geometría claramente distinta o colores/materiales esenciales contradictorios.',
      'No inventes información que no puedas observar. La confianza debe reflejar la evidencia visual.',
      'Devuelve exclusivamente JSON conforme al esquema solicitado.'
    ].join(' ');
  }

  async function validate({ user = null, pattern, image, patternHash = null, assetKey = null, projectId = null, assetId = null, expectedVersion = null, correlationId = null, finalizeLifecycle = true } = {}) {
    const audit = services.audit;
    const actorId = user?.id || null;
    await audit?.record({action:'visual.validation.started',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,metadata:{projectId}});
    const validation = deps.validatePattern(pattern, { strict: true });
    if (!validation?.qualityOk) throw Object.assign(new Error('La validación visual requiere un patrón aprobado por Quality Gate.'), { code: 'PATTERN_QUALITY_GATE', status: 422, details: { validation } });
    const computedHash = hashPattern(pattern);
    if (patternHash && patternHash !== computedHash) throw Object.assign(new Error('patternHash no coincide con el patrón enviado.'), { code: 'PATTERN_HASH_MISMATCH', status: 409, details: { expected: computedHash, received: patternHash } });

    let imageDataUrl = String(image || '');
    if (!imageDataUrl && assetKey && deps.objectStorage) {
      const ownerPrefix = `users/${user?.id || 'guest'}/`;
      if (!String(assetKey).startsWith(ownerPrefix)) throw Object.assign(new Error('El recurso visual no pertenece al usuario actual.'), { code: 'VISUAL_ASSET_FORBIDDEN', status: 403 });
      const buffer = await deps.objectStorage.get(assetKey);
      if (!buffer) throw Object.assign(new Error('No se encontró el recurso visual.'), { code: 'VISUAL_ASSET_NOT_FOUND', status: 404 });
      imageDataUrl = `data:image/png;base64,${Buffer.from(buffer).toString('base64')}`;
    }
    if (!/^data:image\/(png|jpeg|jpg|webp);base64,/i.test(imageDataUrl)) throw Object.assign(new Error('La imagen debe enviarse como data URL PNG, JPEG o WebP.'), { code: 'VISUAL_IMAGE_REQUIRED', status: 400 });

    let reservation = null;
    try {
      if (projectId && assetId && services.visualAssets) await services.visualAssets.transition({user,projectId,assetId,state:'validating',expectedVersion});
      const quota = await services.usage.reserve(user, 'vision');
      if (!quota.allowed) throw Object.assign(new Error(`Límite mensual de análisis visual alcanzado (${quota.limit}).`), { code: 'USAGE_LIMIT', status: 429 });
      reservation = quota.reservationId ? quota : null;

      const routed = await deps.openaiPostModelFallback('responses', {
        instructions: buildPrompt(pattern),
        input: [{ role: 'user', content: [{ type: 'input_text', text: 'Inspecciona esta imagen contra el patrón.' }, { type: 'input_image', image_url: imageDataUrl, detail: 'high' }] }],
        text: { format: { type: 'json_schema', name: 'puntia_visual_validation', strict: true, schema: VISUAL_SCHEMA } }
      }, deps.runtime.visionModel || deps.VISION_MODEL_DEFAULT, deps.runtime.textModel || deps.CHAT_MODEL);

      const result = normalizeResult(extractJson(deps.outputText(routed.data)));
      const accepted = result.matchesPattern && result.confidence >= MIN_CONFIDENCE && result.criticalMismatches.length === 0;
      if (services.costAccounting) services.costAccounting.recordProviderUsage({ model:routed.model, kind:'vision', response:routed.data, userId:user?.id||null, requestId:correlationId, metadata:{ fallback:Boolean(routed.fallback) } });
      else if (typeof deps.recordCost === 'function') deps.recordCost(routed.model,'vision',deps.estimateCost('vision'));
      if (reservation) await services.usage.confirm(user, 'vision', reservation.reservationId);
      let lifecycle=null;
      if (projectId && assetId && services.visualAssets) {
        const lifecycleState = accepted ? (finalizeLifecycle ? 'accepted' : null) : 'rejected';
        if (lifecycleState) lifecycle=await services.visualAssets.transition({user,projectId,assetId,state:lifecycleState,expectedVersion:null});
      }
      await audit?.record({action:'visual.validation.completed',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,status:accepted?'success':'rejected',metadata:{projectId,patternHash:computedHash,model:routed.model,confidence:result.confidence,accepted}});
      return { ok: true, accepted, threshold: MIN_CONFIDENCE, patternHash: computedHash, binding: 'validated-pattern', model: routed.model, fallback: !!routed.fallback, validation: result, assetId: assetId || null, lifecycle: lifecycle?.asset || null, project: lifecycle?.project || null };
    } catch (error) {
      await audit?.record({action:'visual.validation.failed',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,status:'failure',metadata:{projectId,code:error?.code||'UNKNOWN'}});
      if (reservation) { try { await services.usage.release(user, 'vision', reservation.reservationId); } catch {} }
      if (projectId && assetId && services.visualAssets) { try { await services.visualAssets.transition({user,projectId,assetId,state:'rejected',expectedVersion:null}); } catch {} }
      throw error;
    }
  }

  return { validate, buildPrompt, hashPattern, normalizeResult, MIN_CONFIDENCE };
}

module.exports = { createPatternVisualValidationService, VISUAL_SCHEMA };
