'use strict';
const crypto = require('crypto');
const { shouldRetry } = require('../services/job-policy');

/** Distributed worker: Redis is transport/notification; PostgreSQL is the job source of truth. */
function createDistributedWorker({ queue, jobRepo, services, resolveUser, pollMs = 1000, leaseMs = 30000, heartbeatMs = 10000 } = {}) {
  if (!queue || typeof queue.claim !== 'function') throw new Error('Worker requiere queue.claim.');
  if (!jobRepo || typeof jobRepo.claim !== 'function') throw new Error('Worker requiere jobRepo.claim.');
  let stopped = false;
  let loopPromise = null;
  const workerId = `${process.pid}:${crypto.randomUUID()}`;

  async function execute(job) {
    if (job.kind !== 'pattern') throw Object.assign(new Error(`Tipo de job no soportado: ${job.kind}`), { code: 'UNSUPPORTED_JOB_KIND' });
    const user = await resolveUser(job.ownerId, job.meta?.user || null);
    const input = job.meta?.input || {};
    const reservation = job.meta?.reservationId ? { reservationId: job.meta.reservationId } : null;
    return services.patternPipeline.generate({ user, input, persist: false, reservation, correlationId: `job:${job.id}`, jobId: job.id });
  }

  async function processOne(queueName='patterns') {
    const queued = await queue.claim(queueName, 1);
    if (!queued?.id) return false;
    const job = await jobRepo.claim(queued.id, workerId, leaseMs);
    if (!job) return false; // another worker owns it or it reached terminal state
    const heartbeat = setInterval(() => { jobRepo.heartbeat(job.id, workerId, leaseMs).catch(()=>{}); }, Math.max(1000, heartbeatMs));
    try {
      const result = await execute(job);
      await jobRepo.completeByWorker(job.id, workerId, result);
      await queue.ack?.('patterns', job.id);
    } catch (error) {
      const retry = shouldRetry(error, Number(job.attempts || 0), Number(job.maxAttempts || 3));
      const finalJob = await jobRepo.failByWorker(job.id, workerId, error, { retry });
      await queue.ack?.('patterns', job.id);
      if (finalJob?.status === 'queued') await queue.enqueue('patterns', { id: job.id, kind: job.kind });
      if (finalJob?.status === 'dead_letter') await queue.deadLetter?.('patterns', job.id);
    } finally {
      clearInterval(heartbeat);
    }
    return true;
  }

  async function recover() {
    const stale = await jobRepo.recoverStale(100);
    for (const job of stale) {
      if (job?.id && job.status === 'queued') await queue.enqueue('patterns', { id: job.id, kind: job.kind });
    }
    return stale.length;
  }

  async function start() {
    if (loopPromise) return loopPromise;
    stopped = false;
    loopPromise = (async () => {
      while (!stopped) {
        try { await recover(); await processOne('patterns'); }
        catch { await new Promise(r => setTimeout(r, pollMs)); }
      }
    })();
    return loopPromise;
  }
  async function stop() { stopped = true; await loopPromise; loopPromise = null; }
  return { workerId, processOne, recover, start, stop };
}
module.exports = { createDistributedWorker };
