'use strict';

const { assertUsageKind, normalizeUsageSnapshot } = require('../core/contracts');

/** Application-level usage policy. HTTP-independent. */
function createUsageService(deps) {
  return {
    period: () => deps.usagePeriod(),
    current: (user) => normalizeUsageSnapshot(deps.usageFor(user?.id)),
    limits: (user) => {
      const plan = user?.plan === 'pro' ? deps.PRO_LIMITS : user?.plan === 'premium' ? deps.PREMIUM_LIMITS : deps.FREE_LIMITS;
      return plan;
    },
    snapshot: (user) => deps.usagePayload(user),
    reserve: (user, kind) => deps.reserveUsage(user, assertUsageKind(kind)),
    release: (user, kind, reservationId) => deps.releaseUsage(user, assertUsageKind(kind), reservationId),
    confirm: (user, kind, reservationId) => deps.confirmUsage ? deps.confirmUsage(user, assertUsageKind(kind), reservationId) : {ok:true,state:'confirmed'},
    consume: (user, kind) => deps.consumeUsage(user, assertUsageKind(kind))
  };
}
module.exports = { createUsageService };
