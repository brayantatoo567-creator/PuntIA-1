'use strict';

const { normalizeJob, ownerId, contractError, assertPatternResult } = require('../core/contracts');

/** Job application service. Queue mechanics and AI execution stay outside HTTP. */
function createJobService(deps, services) {
  // Serializa la creación por clave de idempotencia dentro del proceso.
  // Evita que dos requests concurrentes reserven cuota antes de descubrir el mismo job.
  const inFlight = new Map();

  async function createPatternJobInternal({ user, input }) {
      const owner = ownerId(user);
      const name = deps.safeText(input.name, 300);
      if (!name) throw contractError('MISSING_PATTERN_NAME','Falta la descripción del patrón.');
      const idempotencyKey = deps.safeText(input.idempotencyKey, 200) || null;
      if (idempotencyKey && deps.findJobByIdempotency) {
        const existing = await deps.findJobByIdempotency('pattern', owner, idempotencyKey);
        if (existing) return existing;
      }
      const quota = await services.usage.reserve(user, 'pattern');
      if (!quota.allowed) throw Object.assign(new Error(`Límite mensual de patrones alcanzado (${quota.limit}).`), { code: 'USAGE_LIMIT', status: 429 });
      const job = normalizeJob(await deps.createJob('pattern', owner, {
        idempotencyKey,
        maxAttempts: 3,
        name,
        level: deps.safeText(input.level, 50) || 'Principiante',
        height: deps.safeText(input.height, 60),
        style: deps.safeText(input.style, 120),
        usageReserved: true,
        reservationId: quota.reservationId || null,
        user: { id: owner, plan: user?.plan || 'free' },
        input: { name, description: deps.safeText(input.description || input.name, 2000), level: deps.safeText(input.level, 50) || 'Principiante', height: deps.safeText(input.height, 60), style: deps.safeText(input.style, 120), referenceImage: typeof input.referenceImage === 'string' ? input.referenceImage.slice(0, 120000) : null }
      }));
      await deps.updateJob(job.id, { ownerId: owner, usageReserved: true });
      await services.audit?.record({ action:'pattern.job.created', resourceType:'job', resourceId:job.id, actorId:owner, correlationId:`job:${job.id}`, metadata:{kind:'pattern', idempotencyKey:Boolean(idempotencyKey)} });
      if (deps.cloudQueue) {
        await deps.cloudQueue.enqueue('patterns', { id: job.id, kind: job.kind });
      } else {
        deps.enqueueLocalJob(job, async () => {
          const run = () => services.patternPipeline.generate({ user, input, persist: false, reservation: quota, correlationId:`job:${job.id}`, jobId:job.id });
          const result = services.observability?.run
            ? await services.observability.run('job.pattern', run, { correlationId:`job:${job.id}`, threshold: 5, cooldownMs: 10000 })
            : await run();
          return assertPatternResult(result);
        });
      }
      return job;
  }

  async function createPatternJob(args) {
    const owner = ownerId(args.user);
    const key = deps.safeText(args.input?.idempotencyKey, 200) || null;
    if (!key) return createPatternJobInternal(args);
    const lockKey = `pattern:${owner}:${key}`;
    const pending = inFlight.get(lockKey);
    if (pending) return pending;
    const execute = async () => {
      if (deps.distributedLock?.acquire) {
        const lease = await deps.distributedLock.acquire(lockKey, 15000);
        if (!lease) {
          const existing = deps.findJobByIdempotency?.('pattern', owner, key);
          if (existing) return existing;
          throw Object.assign(new Error('Operación concurrente; inténtalo de nuevo.'), {code:'DISTRIBUTED_LOCK_BUSY',status:409});
        }
        try { return await createPatternJobInternal(args); } finally { await lease.release(); }
      }
      return createPatternJobInternal(args);
    };
    const promise = execute().finally(() => {
      if (inFlight.get(lockKey) === promise) inFlight.delete(lockKey);
    });
    inFlight.set(lockKey, promise);
    return promise;
  }

  return {
    createPatternJob,
    async get(user, id) { return await deps.getJob(id, ownerId(user)); },
    async cancel(user, id) { return await deps.cancelJob(id, ownerId(user)); }
  };
}
module.exports = { createJobService };
