'use strict';

const FIELDS = Object.freeze([
  'title','description','level','size','style','status','progress',
  'pattern','image','notes','assets','progressState','visualIdentity'
]);

function equal(a,b) { return JSON.stringify(a) === JSON.stringify(b); }

/** Three-way merge. Never silently overwrites concurrent edits. */
function createConflictResolutionService() {
  return {
    merge({ base, local, remote }) {
      if (!base || !local || !remote) return { status:'conflict', reason:'MISSING_BASE' };
      const merged = { ...remote };
      const conflicts = [];
      for (const field of FIELDS) {
        const b = base[field], l = local[field], r = remote[field];
        if (equal(l, b)) merged[field] = r;
        else if (equal(r, b)) merged[field] = l;
        else if (equal(l, r)) merged[field] = l;
        else conflicts.push(field);
      }
      if (conflicts.length) return { status:'conflict', reason:'SAME_FIELD_EDIT', conflicts, base, local, remote };
      merged.id = remote.id;
      merged.ownerId = remote.ownerId;
      merged.version = remote.version;
      return { status:'merged', project:merged, mergedFields:FIELDS.filter(f=>!equal(merged[f],remote[f])) };
    },
    resolveDelete({ base, remote }) {
      if (!base || !remote) return { status:'conflict', reason:'MISSING_BASE' };
      if (equal(base, remote)) return { status:'delete' };
      return { status:'conflict', reason:'DELETE_VS_UPDATE', conflicts:['__delete__'], base, remote };
    }
  };
}
module.exports = { createConflictResolutionService, CONFLICT_FIELDS:FIELDS };
