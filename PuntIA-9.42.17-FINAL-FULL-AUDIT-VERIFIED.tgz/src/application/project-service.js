'use strict';

const { ownerId, normalizeProjectInput, assertProject, contractError } = require('../core/contracts');

/** Project domain/application service. Owns versioning and ownership rules. */
function createProjectService(deps) {
  function resolveOwner(user) { return ownerId(user); }
  function owned(project, id) { return (project?.ownerId || 'local') === id; }
  return {
    ownerId: resolveOwner,
    list(user) {
      const id = resolveOwner(user);
      return deps.projectStore().filter(p => owned(p, id)).sort((a,b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
    },
    get(user, id) {
      return deps.projectStore().find(p => p.id === id && owned(p, resolveOwner(user))) || null;
    },
    listSince(user, cursor={updatedAt:'',id:''}, limit=100) {
      const id=resolveOwner(user); const safeLimit=Math.max(1,Math.min(100,Number(limit)||100));
      const list=deps.projectStore().filter(p=>owned(p,id)).sort((a,b)=>String(a.updatedAt).localeCompare(String(b.updatedAt))||String(a.id).localeCompare(String(b.id)));
      const changed=list.filter(p=>String(p.updatedAt)>String(cursor.updatedAt||'') || (String(p.updatedAt)===String(cursor.updatedAt||'') && String(p.id)>String(cursor.id||'')));
      return changed.slice(0,safeLimit);
    },
    create(user, input) {
      const all = deps.projectStore();
      const owner = resolveOwner(user);
      const mine = all.filter(p => owned(p, owner));
      if (all.length >= deps.MAX_PROJECTS_TOTAL) throw Object.assign(new Error('La capacidad local de proyectos está llena.'), { code: 'PROJECT_STORE_FULL', status: 507 });
      if (mine.length >= deps.MAX_PROJECTS) throw Object.assign(new Error('Se alcanzó el límite local de proyectos.'), { code: 'PROJECT_LIMIT', status: 409 });
      const mutationKey = String(input?.idempotencyKey || '').trim().slice(0, 200);
      if (mutationKey) {
        const replay = mine.find(p => String(p.lastMutationKey || '') === mutationKey);
        if (replay) return replay;
      }
      const project = assertProject(normalizeProjectInput(input, {}, owner));
      all.unshift(project);
      deps.saveProjects(all);
      return project;
    },
    update(user, id, input) {
      const all = deps.projectStore();
      const owner = resolveOwner(user);
      const index = all.findIndex(p => p.id === id && owned(p, owner));
      if (index < 0) throw Object.assign(new Error('Proyecto no encontrado.'), { code: 'PROJECT_NOT_FOUND', status: 404 });
      const before = all[index];
      const mutationKey = String(input?.idempotencyKey || '').trim().slice(0,200);
      if (mutationKey && before.lastMutationKey === mutationKey) return before;
      if (input && input.expectedVersion !== undefined && Number(input.expectedVersion) !== Number(before.version || 1)) throw contractError('PROJECT_VERSION_CONFLICT','El proyecto cambió en otro dispositivo.',409,{expectedVersion:Number(input.expectedVersion),actualVersion:Number(before.version||1)});
      const next = assertProject(normalizeProjectInput(input, before, owner));
      const snapshot = { version: before.version || 1, title: before.title, description: before.description, pattern: before.pattern, image: before.image, progress: before.progress, assets: before.assets, progressState: before.progressState, visualIdentity: before.visualIdentity, updatedAt: before.updatedAt };
      next.versions = [...(before.versions || []), snapshot].slice(-20);
      if (mutationKey) next.lastMutationKey = mutationKey;
      next.version = (before.version || 1) + 1;
      all[index] = next;
      deps.saveProjects(all);
      return next;
    },
    remove(user, id) {
      const all = deps.projectStore();
      const owner = resolveOwner(user);
      const next = all.filter(p => !(p.id === id && owned(p, owner))); 
      if (next.length === all.length) throw Object.assign(new Error('Proyecto no encontrado.'), { code: 'PROJECT_NOT_FOUND', status: 404 });
      deps.saveProjects(next);
      return id;
    }
  };
}
module.exports = { createProjectService };
