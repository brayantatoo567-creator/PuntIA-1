'use strict';
const crypto = require('crypto');

const SENSITIVE = /pass(word)?|secret|token|authorization|cookie|api[-_]?key|access[-_]?key|private[-_]?key|base64|dataurl|prompt/i;

function sanitize(value, depth = 0) {
  if (depth > 3) return '[TRUNCATED]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return value.length > 300 ? `${value.slice(0,300)}…` : value;
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) return value.slice(0,20).map(v => sanitize(v, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const [key, raw] of Object.entries(value).slice(0,40)) {
      if (SENSITIVE.test(key)) {
        out[key] = '[REDACTED]';
      } else if (key === 'pattern' && raw && typeof raw === 'object') {
        const json = JSON.stringify(raw);
        out.patternHash = crypto.createHash('sha256').update(json).digest('hex');
        out.patternSize = json.length;
      } else if (key === 'image' && typeof raw === 'string') {
        out.imageHash = crypto.createHash('sha256').update(raw).digest('hex');
        out.imageSize = raw.length;
      } else {
        out[key] = sanitize(raw, depth + 1);
      }
    }
    return out;
  }
  return String(value);
}

function createAuditService(deps) {
  const sink = deps.auditSink;
  async function record({ action, resourceType = 'system', resourceId = null, actorId = null, correlationId = null, status = 'success', metadata = {} } = {}) {
    if (!sink?.record) return null;
    const event = {
      eventId: crypto.randomUUID(),
      occurredAt: new Date().toISOString(),
      action: String(action || 'unknown').slice(0,100),
      resourceType: String(resourceType || 'system').slice(0,80),
      resourceId: resourceId == null ? null : String(resourceId).slice(0,200),
      actorId: actorId == null ? null : String(actorId).slice(0,200),
      correlationId: correlationId == null ? null : String(correlationId).slice(0,120),
      status: String(status || 'success').slice(0,40),
      metadata: sanitize(metadata)
    };
    return sink.record(event);
  }
  async function verify() {
    if (typeof sink.verify === 'function') return sink.verify();
    return { ok: true, supported: false };
  }
  async function list(limit = 100) {
    if (typeof sink.list !== 'function') return [];
    return sink.list(Math.min(500, Math.max(1, Number(limit) || 100)));
  }
  return { record, verify, list, sanitize };
}
module.exports = { createAuditService, sanitize };
