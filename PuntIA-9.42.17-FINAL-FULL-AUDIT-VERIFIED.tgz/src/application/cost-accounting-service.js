'use strict';

/**
 * Provider cost accounting. Never invents a cost when provider usage is absent.
 * Prices are USD per 1M tokens and must be updated when provider pricing changes.
 */
const PRICING_VERSION = 'openai-2026-10-06';
const PRICES_USD_PER_M = Object.freeze({
  'gpt-6-luna': { input: 0.10, cachedInput: 0.01, cacheWrite: 0.125, output: 0.50 },
  'gpt-6.1-sol': { input: 2.00, cachedInput: 0.20, cacheWrite: 2.50, output: 10.00 },
  'gpt-6-sol': { input: 2.00, cachedInput: 0.20, cacheWrite: 2.50, output: 10.00 },
  'gpt-image-2': { input: 2.50, cachedInput: 0.625, output: 15.00, imageInput: 4.00, cachedImageInput: 1.00, imageOutput: 15.00 },
  'gpt-image-2-2026-04-21': { input: 2.50, cachedInput: 0.625, output: 15.00, imageInput: 4.00, cachedImageInput: 1.00, imageOutput: 15.00 }
});

function n(v) { const x = Number(v); return Number.isFinite(x) && x >= 0 ? x : 0; }
function pick(o, keys) { for (const k of keys) if (o && Number.isFinite(Number(o[k]))) return Number(o[k]); return 0; }
function usageOf(response) {
  const u = response?.usage || response?.response?.usage || {};
  const input = pick(u, ['input_tokens','prompt_tokens']);
  const output = pick(u, ['output_tokens','completion_tokens']);
  const cachedInput = pick(u, ['cached_input_tokens','prompt_cached_tokens']);
  const cacheWrite = pick(u, ['cache_write_input_tokens','cache_creation_input_tokens']);
  const imageInput = pick(u, ['image_input_tokens']);
  const cachedImageInput = pick(u, ['cached_image_input_tokens']);
  const imageOutput = pick(u, ['image_output_tokens']);
  return { input, output, cachedInput, cacheWrite, imageInput, cachedImageInput, imageOutput, present: Object.keys(u).length > 0 };
}
function priceFor(model) { return PRICES_USD_PER_M[String(model || '').trim()] || null; }
function calculateProviderCost({ model, response, serviceTier='standard', regional=false } = {}) {
  const price = priceFor(model);
  const usage = usageOf(response);
  if (!price || !usage.present) return { known:false, usd:null, reason:!price?'MODEL_PRICE_NOT_CONFIGURED':'PROVIDER_USAGE_NOT_RETURNED', pricingVersion:PRICING_VERSION, model, usage };
  let usd = 0;
  usd += n(usage.input - usage.cachedInput - usage.cacheWrite) * (price.input || 0) / 1e6;
  usd += n(usage.cachedInput) * (price.cachedInput ?? price.input ?? 0) / 1e6;
  usd += n(usage.cacheWrite) * (price.cacheWrite ?? price.input ?? 0) / 1e6;
  usd += n(usage.output) * (price.output || 0) / 1e6;
  usd += n(usage.imageInput) * (price.imageInput ?? price.input ?? 0) / 1e6;
  usd += n(usage.cachedImageInput) * (price.cachedImageInput ?? price.cachedInput ?? price.input ?? 0) / 1e6;
  usd += n(usage.imageOutput) * (price.imageOutput ?? price.output ?? 0) / 1e6;
  const tier = String(serviceTier || 'standard').toLowerCase();
  if (tier === 'fast' || tier === 'priority') usd *= 2;
  if (regional) usd *= 1.10;
  return { known:true, usd:Number(usd.toFixed(10)), pricingVersion:PRICING_VERSION, model, usage, serviceTier:tier, regional };
}
function createCostAccountingService(deps) {
  return {
    pricingVersion: PRICING_VERSION,
    calculate: calculateProviderCost,
    recordProviderUsage({ model, kind, response, userId=null, requestId=null, metadata={} } = {}) {
      const result = calculateProviderCost({ model, response, serviceTier:metadata.serviceTier, regional:Boolean(metadata.regional) });
      deps.recordCostEvent({ model, kind, userId, requestId, ...result, metadata });
      return result;
    }
  };
}
module.exports = { PRICING_VERSION, PRICES_USD_PER_M, usageOf, calculateProviderCost, createCostAccountingService };
