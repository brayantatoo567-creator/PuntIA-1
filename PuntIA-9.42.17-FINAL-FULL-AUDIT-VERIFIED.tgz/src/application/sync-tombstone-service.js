'use strict';
const { contractError } = require('../core/contracts');

function createSyncTombstoneService(deps) {
  const repo = deps.syncTombstoneRepo || null;
  const file = deps.SYNC_TOMBSTONES_FILE;
  const load = () => file ? deps.loadJsonFile(file, {}) : (deps.__syncTombstones || {});
  const save = (value) => { if (file) deps.saveJsonFile(file, value); else deps.__syncTombstones = value; };
  return {
    list(ownerId) { if(repo) return repo.list(ownerId); const all=load(); return Object.values(all).filter(x=>x.ownerId===String(ownerId)); },
    get(ownerId,id) { if(repo) return repo.get(ownerId,id); return this.list(ownerId).find(x=>x.id===String(id)) || null; },
    put(ownerId,id,version,deletedAt=new Date().toISOString()) {
      if (!ownerId || !id) throw contractError('INVALID_TOMBSTONE','Tombstone requiere propietario e id.');
      if(repo) return repo.put(ownerId,id,version,deletedAt);
      const all=load(), key=`${ownerId}:${id}`, current=all[key];
      if (current && Number(current.version)>=Number(version||1)) return current;
      const item={ownerId:String(ownerId),id:String(id),version:Number(version||1),deletedAt:String(deletedAt)};
      all[key]=item; save(all); return item;
    },
    remove(ownerId,id){if(repo) return repo.remove(ownerId,id);const all=load();delete all[`${ownerId}:${id}`];save(all);return true;}
  };
}
module.exports={createSyncTombstoneService};
