'use strict';
const { contractError, assertProject } = require('../core/contracts');

function createSyncService(deps, conflictService = null) {
  function encodeCursor(value) { return Buffer.from(JSON.stringify(value), 'utf8').toString('base64url'); }
  function decodeCursor(value) {
    if (!value) return { updatedAt: '', id: '' };
    try {
      const parsed = JSON.parse(Buffer.from(String(value), 'base64url').toString('utf8'));
      return { updatedAt: String(parsed.updatedAt || ''), id: String(parsed.id || '') };
    } catch { throw contractError('INVALID_SYNC_CURSOR', 'Cursor de sincronización inválido.'); }
  }
  function afterCursor(project, cursor) {
    const a = String(project.updatedAt || '');
    const b = String(cursor.updatedAt || '');
    if (a > b) return true;
    return a === b && String(project.id) > String(cursor.id || '');
  }
  function sortProjects(list) {
    return [...list].sort((a,b) => String(a.updatedAt).localeCompare(String(b.updatedAt)) || String(a.id).localeCompare(String(b.id)));
  }
  const conflicts = conflictService;
  return {
    encodeCursor,
    decodeCursor,
    async pull({ user, repo, cursor, limit=100, tombstones }) {
      const owner = user?.id || 'local';
      const safeLimit = Math.max(1, Math.min(100, Number(limit) || 100));
      const parsed = decodeCursor(cursor);
      const all = repo ? await repo.list(owner) : deps.projectStore().filter(p => (p.ownerId || 'local') === owner);
      const changed = sortProjects(all.filter(p => afterCursor(p, parsed)));
      const deleted = (tombstones ? await tombstones.list(owner) : []).filter(t => afterCursor({updatedAt:t.deletedAt,id:t.id}, parsed)).sort((a,b)=>String(a.deletedAt).localeCompare(String(b.deletedAt))||String(a.id).localeCompare(String(b.id)));
      const merged = [...changed.map(project=>({kind:'project',updatedAt:project.updatedAt,id:project.id,project})), ...deleted.map(t=>({kind:'tombstone',updatedAt:t.deletedAt,id:t.id,tombstone:t}))].sort((a,b)=>String(a.updatedAt).localeCompare(String(b.updatedAt))||String(a.id).localeCompare(String(b.id)));
      const page = merged.slice(0,safeLimit);
      const projects = page.filter(x=>x.kind==='project').map(x=>assertProject(x.project));
      const tombstonePage = page.filter(x=>x.kind==='tombstone').map(x=>x.tombstone);
      const last = page[page.length-1];
      const next = last ? encodeCursor({ updatedAt:last.updatedAt, id:last.id }) : (cursor || encodeCursor(parsed));
      return { projects, tombstones:tombstonePage, nextCursor:next, hasMore:merged.length>page.length, count:page.length };
    },
    async push({ user, items, repo, projectService, tombstones }) {
      if (!Array.isArray(items) || items.length > 100) throw contractError('INVALID_SYNC_BATCH', 'El lote de sincronización debe contener entre 0 y 100 proyectos.');
      const owner = user?.id || 'local';
      const results = [];
      for (const item of items) {
        if (!item || typeof item !== 'object') throw contractError('INVALID_SYNC_ITEM', 'Elemento de sincronización inválido.');
        const id = String(item.id || '').trim();
        if (item.deleted === true) {
          const current = repo ? await repo.get(id, owner) : projectService.get(user, id);
          const expected = item.expectedVersion !== undefined ? Number(item.expectedVersion) : Number(item.version || 1);
          if (current && expected !== Number(current.version || 1)) {
            if (!(conflicts && item.baseProject)) {
              results.push({id,status:'conflict',error:{code:'PROJECT_VERSION_CONFLICT',message:'El proyecto cambió antes de eliminarse.',details:{expectedVersion:expected,actualVersion:Number(current.version||1),project:current}}});
              continue;
            }
            const resolution = conflicts.resolveDelete({base:item.baseProject,remote:current});
            if (resolution.status !== 'delete') {
              results.push({id,status:'conflict',error:{code:'PROJECT_CONFLICT',message:'No se puede eliminar porque el proyecto cambió en otro dispositivo.',details:{expectedVersion:expected,actualVersion:Number(current.version||1),resolution}}});
              continue;
            }
          }
          if (current) { if (repo) await repo.remove(id, owner); else projectService.remove(user,id); }
          if (tombstones) await tombstones.put(owner,id,expected,item.deletedAt);
          results.push({id,status:'deleted',tombstone:tombstones ? await tombstones.get(owner,id) : {ownerId:owner,id,version:expected,deletedAt:item.deletedAt||new Date().toISOString()}});
          continue;
        }
        if (!id) throw contractError('INVALID_SYNC_ITEM', 'Cada proyecto sincronizado requiere id.');
        const current = repo ? await repo.get(id, owner) : projectService.get(user, id);
        try {
          if (!current) {
            if (item.expectedVersion !== undefined && Number(item.expectedVersion) !== 0) throw contractError('PROJECT_VERSION_CONFLICT','El proyecto no existe en el servidor y esperaba otra versión.',409,{expectedVersion:Number(item.expectedVersion),actualVersion:0});
            const created = repo ? await repo.create({...item, id, ownerId:owner, version:1}, owner) : projectService.create(user, {...item, id, ownerId:owner, version:1});
            results.push({ id, status:'created', project:created });
          } else {
            const expected = item.expectedVersion !== undefined ? Number(item.expectedVersion) : Number(current.version || 1);
            let payload = {...item, id, ownerId:owner, expectedVersion:expected};
            if (expected !== Number(current.version || 1)) {
              if (!(conflicts && item.baseProject)) throw contractError('PROJECT_VERSION_CONFLICT','El proyecto cambió en otro dispositivo.',409,{expectedVersion:expected,actualVersion:Number(current.version || 1),project:current});
              const resolution = conflicts.merge({base:item.baseProject,local:item,remote:current});
              if (resolution.status !== 'merged') throw contractError('PROJECT_CONFLICT','No se puede fusionar automáticamente este cambio.',409,{expectedVersion:expected,actualVersion:Number(current.version||1),resolution});
              payload = {...resolution.project, id, ownerId:owner, expectedVersion:Number(current.version||1)};
            }
            delete payload.baseProject;
            const updated = repo ? await repo.update(id, payload, owner) : projectService.update(user, id, payload);
            results.push({ id, status:expected !== Number(current.version || 1) ? 'merged' : 'updated', project:updated });
          }
        } catch (error) {
          if (error.code === 'PROJECT_VERSION_CONFLICT' || error.code === 'PROJECT_CONFLICT') results.push({ id, status:'conflict', error:{code:error.code,message:error.message,details:error.details} });
          else throw error;
        }
      }
      return { results, count:results.length };
    }
  };
}
module.exports = { createSyncService };
