'use strict';

/** Authentication application service. HTTP/session transport remains in the route layer. */
function createAuthService(deps) {
  return {
    findByEmail(email) {
      const users = deps.loadJsonFile(deps.USERS_FILE, []);
      return users.find(u => u.email === String(email || '').trim().toLowerCase()) || null;
    },
    findById(id) {
      return deps.loadJsonFile(deps.USERS_FILE, []).find(u => u.id === id) || null;
    },
    list() { return deps.loadJsonFile(deps.USERS_FILE, []); },
    save(users) { deps.saveJsonFile(deps.USERS_FILE, users); },
    createPassword(password) { return deps.hashPassword(password); },
    verifyPassword(password, user) { return deps.verifyPassword(password, user); },
    publicUser(user) { return deps.publicUser(user); }
  };
}
module.exports = { createAuthService };
