'use strict';
const crypto=require('crypto');

function createContextualAssistantService(deps={}) {
  const validate=deps.validatePattern || (()=>({qualityOk:false,quality:0,errors:['Quality Gate no disponible']}));
  function diagnose(pattern, ctx={}) {
    const gate=validate(pattern,{strict:true});
    if(!gate.qualityOk) return {ok:false,code:'PATTERN_NOT_APPROVED',message:'El patrón no está aprobado por Quality Gate.',gate};
    const roundNo=Math.max(0,Number(ctx.currentRound||0));
    const round=Array.isArray(pattern.rounds)?pattern.rounds.find(r=>Number(r.round)===roundNo):null;
    if(!roundNo) return {ok:true,type:'progress',message:'Selecciona una vuelta para analizarla.',round:null,gate};
    if(!round) return {ok:false,code:'ROUND_NOT_FOUND',message:`La vuelta ${roundNo} no existe en este patrón.`,gate};
    const expected=Number(round.expectedStitches||0);
    const actual=ctx.actualStitches===undefined?null:Number(ctx.actualStitches);
    const delta=actual===null?null:actual-expected;
    let type='ok',message=`La vuelta ${roundNo} requiere ${expected} puntos.`;
    if(actual!==null && delta!==0){ type=delta>0?'extra_stitches':'missing_stitches'; message=delta>0?`Tienes ${delta} puntos de más; la vuelta espera ${expected}.`:`Te faltan ${Math.abs(delta)} puntos; la vuelta espera ${expected}.`; }
    return {ok:true,type,message,round:{number:roundNo,expectedStitches:expected,inputStitches:Number(round.inputStitches||0),operations:round.operations||[]},actualStitches:actual,delta,gate};
  }
  function answer(pattern,ctx={}) {
    const diagnosis=diagnose(pattern,ctx);
    if(!diagnosis.ok) return diagnosis;
    const q=String(ctx.question||'').trim();
    let advice=diagnosis.message;
    if(diagnosis.type==='extra_stitches') advice+=' Revisa especialmente aumentos repetidos o una repetición ejecutada una vez de más.';
    if(diagnosis.type==='missing_stitches') advice+=' Revisa disminuciones, puntos omitidos y el conteo de cada repetición.';
    if(q) advice+=` Pregunta recibida: ${q}`;
    return {ok:true,answer:advice,diagnosis,contextHash:crypto.createHash('sha256').update(JSON.stringify({round:diagnosis.round,actual:diagnosis.actualStitches})).digest('hex')};
  }
  return {diagnose,answer};
}
module.exports={createContextualAssistantService};
