'use strict';
const crypto = require('crypto');

function createPatternVisualService(deps, services) {
  function hashPattern(pattern) {
    return crypto.createHash('sha256').update(JSON.stringify(pattern)).digest('hex');
  }
  function buildPrompt(pattern, userPrompt='') {
    const geometry=pattern.geometry||{};
    const materials=(pattern.materials||[]).join(', ');
    const assembly=(pattern.assembly||[]).join('; ');
    const notes=(pattern.notes||[]).join('; ');
    const rounds=Array.isArray(pattern.rounds)?pattern.rounds.length:0;
    return [
      'Create a faithful crochet/amigurumi reference image for the validated PuntIA pattern below.',
      `Subject: ${pattern.title}.`,
      `Geometry: ${geometry.type||'custom'}, target height: ${geometry.targetHeightCm||'unspecified'} cm.`,
      `Materials/colors described by the pattern: ${materials||'not specified'}.`,
      `Construction: ${rounds} rounds; assembly: ${assembly||'not specified'}.`,
      `Pattern notes: ${notes||'none'}.`,
      'Show a physically plausible crocheted object with visible yarn texture, proportions consistent with the geometry, and only details compatible with the pattern.',
      'Do not invent unrelated accessories, extra limbs, impossible knitted structures, text, logos, or watermarks.',
      userPrompt ? `Additional non-conflicting presentation request: ${String(userPrompt).slice(0,800)}.` : ''
    ].filter(Boolean).join(' ');
  }
  async function generate({user=null, pattern, prompt='', persist=true, projectId=null, correlationId=null}={}) {
    const audit = services.audit;
    const actorId = user?.id || null;
    const maxAttempts = 2;
    await audit?.record({action:'visual.generation.started',resourceType:'pattern-visual',actorId,correlationId,metadata:{projectId,maxAttempts}});
    const validation=deps.validatePattern(pattern,{strict:true});
    if (!validation?.qualityOk) throw Object.assign(new Error('La referencia visual requiere un patrón aprobado por Quality Gate.'),{code:'PATTERN_QUALITY_GATE',status:422,details:{validation}});
    if (!services.patternVisualValidation?.validate) {
      throw Object.assign(new Error('La validación visual no está configurada; se rechaza la publicación de la imagen.'),{code:'VISUAL_VALIDATION_UNAVAILABLE',status:503});
    }
    const patternHash=hashPattern(pattern);
    let lastValidation=null;
    let lastModel=null;
    let attemptsUsed=0;
    let lastImage=null;
    let lastAssetId=crypto.randomUUID();
    let registeredLifecycle = null;
    if (projectId && services.visualAssets) {
      registeredLifecycle = await services.visualAssets.registerGenerated({
        user,
        projectId,
        asset: { id:lastAssetId, key:'', url:'', patternHash, createdAt:new Date().toISOString(), metadata:{ model:null, lifecycle:'visual' } }
      });
    }

    for (let attempt=1; attempt<=maxAttempts; attempt++) {
      attemptsUsed=attempt;
      let reservation=null;
      let assetKey=null;
      const assetId=lastAssetId;
      try {
        const quota=await services.usage.reserve(user,'image');
        if(!quota.allowed) throw Object.assign(new Error(`Límite mensual de imágenes alcanzado (${quota.limit}).`),{code:'USAGE_LIMIT',status:429});
        reservation=quota.reservationId?quota:null;

        const callProvider = () => deps.openaiPost('images/generations',{model:deps.runtime.imageModel||deps.IMAGE_MODEL_DEFAULT,prompt:buildPrompt(pattern,prompt).slice(0,4000),size:deps.IMAGE_SIZE,quality:'high',output_format:'png'});
        const routed=services.observability?.run
          ? await services.observability.run('image-provider', callProvider, { correlationId })
          : await callProvider();
        lastModel=routed.model||deps.runtime.imageModel;
        const b64=routed?.data?.[0]?.b64_json;
        if(!b64) throw Object.assign(new Error('El proveedor no devolvió una imagen.'),{code:'IMAGE_PROVIDER_EMPTY',status:502});
        lastImage=`data:image/png;base64,${b64}`;
        if (services.costAccounting) services.costAccounting.recordProviderUsage({ model:lastModel, kind:'image', response:routed.data, userId:user?.id||null, requestId:correlationId, metadata:{ attempt } });
        else if (typeof deps.recordCost === 'function') deps.recordCost(lastModel,'image',deps.estimateCost('image'));
        // The provider call is billable even when the visual gate rejects the result.
        if(reservation) { await services.usage.confirm(user,'image',reservation.reservationId); reservation=null; }

        const visualValidation=await services.patternVisualValidation.validate({
          user,
          pattern,
          image:lastImage,
          patternHash,
          projectId:projectId || null,
          assetId:projectId ? assetId : null,
          correlationId,
          finalizeLifecycle:false
        });
        lastValidation=visualValidation;

        if (!visualValidation.accepted) {
          await audit?.record({action:'visual.generation.rejected',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,status:'rejected',metadata:{projectId,patternHash,attempt,confidence:visualValidation.validation?.confidence||0,mismatches:visualValidation.validation?.criticalMismatches||[]}});
          if (attempt<maxAttempts) continue;
          throw Object.assign(new Error('La imagen generada no coincide con el patrón después de todos los intentos.'),{code:'VISUAL_QUALITY_GATE',status:422,details:{attempts:maxAttempts,validation:visualValidation}});
        }

        if(persist && deps.objectStorage){
          assetKey=`users/${user?.id||'guest'}/pattern-visuals/${patternHash}-${assetId}.png`;
          await deps.objectStorage.put(assetKey,Buffer.from(b64,'base64'));
        }

        let lifecycle=null;
        if (projectId && services.visualAssets) {
          try {
            lifecycle = await services.visualAssets.transition({user,projectId,assetId,state:'accepted',expectedVersion:null});
            if (assetKey && deps.objectStorage) {
              lifecycle = await services.visualAssets.attachAcceptedAsset({
                user, projectId, assetId,
                key:assetKey,
                url:`storage:${assetKey}`,
                metadata:{model:lastModel,visualValidation:lastValidation.validation,patternHash}
              });
            }
          } catch (e) {
            if (assetKey && deps.objectStorage) { try { await deps.objectStorage.remove(assetKey); } catch {} }
            throw e;
          }
        }
        await audit?.record({action:'visual.generation.completed',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,status:'success',metadata:{projectId,patternHash,model:lastModel,assetKey:assetKey||null,attempts:attempt}});
        return {ok:true,image:lastImage,assetKey,model:lastModel,patternHash,sourcePattern:{title:pattern.title,geometry:pattern.geometry||null},binding:'validated-pattern',assetId,lifecycle:lifecycle?.asset||null,project:lifecycle?.project||null,visualValidation:lastValidation,attempts:attempt};
      } catch(error){
        if(reservation) { try{await services.usage.release(user,'image',reservation.reservationId);}catch{} }
        if (projectId && services.visualAssets && attempt === maxAttempts && !['VISUAL_QUALITY_GATE','USAGE_LIMIT'].includes(error?.code)) {
          try { await services.visualAssets.transition({user,projectId,assetId,state:'rejected',expectedVersion:null}); } catch {}
        }
        await audit?.record({action:'visual.generation.failed',resourceType:'pattern-visual',resourceId:assetId,actorId,correlationId,status:'failure',metadata:{projectId,code:error?.code||'UNKNOWN',attempt}});
        if(error?.code==='VISUAL_QUALITY_GATE' || error?.code==='USAGE_LIMIT' || error?.code==='VISUAL_VALIDATION_UNAVAILABLE') throw error;
        if(attempt===maxAttempts) throw error;
      }
    }
    throw Object.assign(new Error('La generación visual no produjo un resultado aprobado.'),{code:'VISUAL_QUALITY_GATE',status:422,details:{attempts:attemptsUsed,validation:lastValidation,assetId:lastAssetId}});
  }

  return {generate,buildPrompt,hashPattern};
}
module.exports={createPatternVisualService};
