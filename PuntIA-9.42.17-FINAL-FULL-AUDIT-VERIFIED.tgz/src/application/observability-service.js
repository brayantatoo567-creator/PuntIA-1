'use strict';

const crypto = require('crypto');

function createObservabilityService(deps, services = {}) {
  const startedAt = Date.now();
  const metrics = new Map();
  const breakers = new Map();
  const MAX_METRIC_SERIES = 64;
  const MAX_CIRCUITS = 32;

  function normalizeName(name) {
    const value = String(name ?? '').trim();
    if (!value || value.length > 80 || !/^[a-zA-Z0-9._:-]+$/.test(value)) {
      throw Object.assign(new Error('Nombre de observabilidad inválido.'), { code: 'OBSERVABILITY_INVALID_NAME', status: 400 });
    }
    return value;
  }

  function metric(name) {
    const key = normalizeName(name);
    if (!metrics.has(key)) {
      if (metrics.size >= MAX_METRIC_SERIES) {
        throw Object.assign(new Error('Límite de series de métricas alcanzado.'), { code: 'OBSERVABILITY_CARDINALITY_LIMIT', status: 503 });
      }
      metrics.set(key, { count: 0, failures: 0, totalMs: 0, totalMsMax: 0, lastError: null, lastAt: null });
    }
    return metrics.get(key);
  }

  function record(name, ms, ok, error = null) {
    const m = metric(name);
    m.count++;
    const duration = Math.max(0, Number(ms) || 0);
    m.totalMs += duration;
    m.totalMsMax = Math.max(m.totalMsMax, duration);
    if (!ok) { m.failures++; m.lastError = String(error?.code || error?.message || 'UNKNOWN').slice(0, 120); }
    m.lastAt = new Date().toISOString();
  }

  function getBreaker(name, options = {}) {
    const key = normalizeName(name);
    if (!breakers.has(key)) {
      if (breakers.size >= MAX_CIRCUITS) {
        throw Object.assign(new Error('Límite de circuit breakers alcanzado.'), { code: 'OBSERVABILITY_CIRCUIT_LIMIT', status: 503 });
      }
      breakers.set(key, {
      state: 'closed', failures: 0, openedAt: 0,
        threshold: Number(options.threshold || 3), cooldownMs: Number(options.cooldownMs || 15000)
      });
    }
    return breakers.get(key);
  }

  function canCall(name, options) {
    const b = getBreaker(name, options);
    if (b.state !== 'open') return true;
    if (Date.now() - b.openedAt >= b.cooldownMs) { b.state = 'half-open'; return true; }
    return false;
  }

  function success(name) {
    const b = getBreaker(name);
    b.failures = 0;
    if (b.state === 'half-open') b.state = 'closed';
  }

  function failure(name, error) {
    const b = getBreaker(name);
    b.failures++;
    if (b.failures >= b.threshold) { b.state = 'open'; b.openedAt = Date.now(); }
    return b;
  }

  async function run(name, fn, options = {}) {
    if (!canCall(name, options)) {
      const error = Object.assign(new Error(`Proveedor temporalmente bloqueado: ${name}`), { code: 'CIRCUIT_OPEN', status: 503 });
      record(name, 0, false, error);
      await services.audit?.record({ action: 'provider.circuit_open', resourceType: 'provider', correlationId: options.correlationId || null, status: 'failure', metadata: { provider: name } });
      throw error;
    }
    const start = Date.now();
    try {
      const result = await fn();
      const ms = Date.now() - start;
      record(name, ms, true);
      success(name);
      return result;
    } catch (error) {
      const ms = Date.now() - start;
      record(name, ms, false, error);
      failure(name, error);
      throw error;
    }
  }

  function snapshot() {
    const out = {};
    for (const [name, m] of metrics) out[name] = { ...m, avgMs: m.count ? Math.round(m.totalMs / m.count) : 0 };
    const circuitBreakers = {};
    for (const [name, b] of breakers) circuitBreakers[name] = { state: b.state, failures: b.failures, openedAt: b.openedAt || null };
    return { uptimeMs: Date.now() - startedAt, metrics: out, circuitBreakers };
  }

  function health() {
    const snap = snapshot();
    const open = Object.values(snap.circuitBreakers).filter(v => v.state === 'open').length;
    return { ok: open === 0, ...snap, openCircuits: open };
  }

  function reset(name) {
    const b = breakers.get(name);
    if (b) { b.state = 'closed'; b.failures = 0; b.openedAt = 0; }
  }

  return { run, record, snapshot, health, reset };
}

module.exports = { createObservabilityService };
