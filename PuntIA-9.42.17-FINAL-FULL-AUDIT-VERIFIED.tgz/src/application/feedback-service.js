'use strict';
const crypto = require('crypto');
const ALLOWED_TYPES = Object.freeze(['pattern','image','project']);
const ALLOWED_CATEGORIES = Object.freeze(['incorrect_count','unclear_instructions','wrong_shape','wrong_colors','missing_part','visual_mismatch','too_difficult','other']);
function createFeedbackService(deps) {
  const file = deps.FEEDBACK_FILE;
  const cloud = deps.feedbackRepo || deps.cloud?.feedbackRepo || null;
  function sanitize(input={}) {
    const rating = Number(input.rating);
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw Object.assign(new Error('La calificación debe estar entre 1 y 5.'), {status:400,code:'INVALID_FEEDBACK_RATING'});
    const type = String(input.resultType || 'pattern').trim();
    if (!ALLOWED_TYPES.includes(type)) throw Object.assign(new Error('Tipo de resultado no permitido.'), {status:400,code:'INVALID_FEEDBACK_TYPE'});
    const categories = Array.isArray(input.categories) ? [...new Set(input.categories.map(String).filter(x=>ALLOWED_CATEGORIES.includes(x)))].slice(0,5) : [];
    return {rating,resultType:type,resultId:String(input.resultId||'').slice(0,128),projectId:String(input.projectId||'').slice(0,128),patternHash:String(input.patternHash||'').slice(0,128),categories,comment:String(input.comment||'').slice(0,1000)};
  }
  function readLocal(){try{return String(deps.fs.readFileSync(file,'utf8')||'').split(/\r?\n/).filter(Boolean).map(x=>{try{return JSON.parse(x)}catch{return null}}).filter(Boolean)}catch{return []}}
  async function submit(user,input){
    const owner=String(user?.id||'').trim(); if(!owner) throw Object.assign(new Error('Usuario requerido.'),{status:401,code:'AUTH_REQUIRED'});
    const clean=sanitize(input); if(!clean.resultId && !clean.projectId) throw Object.assign(new Error('Falta resultId o projectId.'),{status:400,code:'FEEDBACK_TARGET_REQUIRED'});
    const projectId=clean.projectId||null;
    if(projectId && deps.services?.projects?.get){ const project=await deps.services.projects.get(user,projectId); if(!project) throw Object.assign(new Error('Proyecto no encontrado.'),{status:404,code:'PROJECT_NOT_FOUND'}); }
    if(!projectId && clean.resultType==='pattern' && deps.getJob){ const job=await deps.getJob(clean.resultId,owner); if(!job) throw Object.assign(new Error('Resultado no encontrado.'),{status:404,code:'FEEDBACK_RESULT_NOT_FOUND'}); }
    if(!projectId && clean.resultType!=='pattern') throw Object.assign(new Error('Para este tipo de resultado se requiere projectId.'),{status:400,code:'FEEDBACK_PROJECT_REQUIRED'});
    const item={id:crypto.randomUUID(),userId:owner,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),...clean};
    if(cloud?.upsert) { const saved=await cloud.upsert(item); await deps.services?.audit?.record?.({action:'feedback.submitted',resourceType:'feedback',resourceId:saved.id,actorId:owner,metadata:{rating:saved.rating,resultType:saved.resultType,categories:saved.categories}}); return saved; }
    const all=readLocal(); const idx=all.findIndex(x=>x.userId===owner&&x.resultType===clean.resultType&&x.resultId===clean.resultId);
    if(idx>=0){item.id=all[idx].id;item.createdAt=all[idx].createdAt;all[idx]=item;} else all.push(item);
    deps.fs.mkdirSync(deps.path.dirname(file),{recursive:true,mode:0o700}); deps.fs.writeFileSync(file,all.map(x=>JSON.stringify(x)).join('\n')+'\n',{mode:0o600});
    await deps.services?.audit?.record?.({action:'feedback.submitted',resourceType:'feedback',resourceId:item.id,actorId:owner,metadata:{rating:item.rating,resultType:item.resultType,categories:item.categories}});
    return item;
  }
  async function mine(user){const owner=String(user?.id||''); if(cloud?.listForUser)return cloud.listForUser(owner); return readLocal().filter(x=>x.userId===owner).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt)))}
  async function overview(){if(cloud?.metrics)return cloud.metrics(); const rows=readLocal(); const count=rows.length; const avg=count?Number((rows.reduce((s,x)=>s+Number(x.rating||0),0)/count).toFixed(2)):0; const negative=rows.filter(x=>Number(x.rating)<=2).length; const categories={}; for(const x of rows) for(const c of (x.categories||[])) categories[c]=(categories[c]||0)+1; return {count,averageRating:avg,negative,categoryCounts:categories};}
  return {submit,mine,overview,ALLOWED_TYPES,ALLOWED_CATEGORIES};
}
module.exports={createFeedbackService,ALLOWED_TYPES,ALLOWED_CATEGORIES};
