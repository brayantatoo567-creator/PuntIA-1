'use strict';

const { contractError } = require('../core/contracts');

function text(value, max = 600) {
  return String(value ?? '').trim().slice(0, max);
}

function operationLabel(op) {
  const names = { single: 'punto bajo', increase: 'aumento', decrease: 'disminución' };
  const name = names[op.type] || op.type;
  const count = Number(op.count || 1);
  const repeats = Number(op.repeats || 1);
  return repeats === 1 ? `${count} ${name}` : `${count} ${name}, repetir ${repeats} veces`;
}

function createTutorialService(deps) {
  function create(pattern, options = {}) {
    const validation = deps.validatePattern(pattern, { strict: true });
    if (!pattern || !validation?.qualityOk) {
      throw contractError('TUTORIAL_PATTERN_REJECTED', 'Solo se puede crear un tutorial a partir de un patrón aprobado por el Quality Gate.', 422, { validation });
    }

    const rounds = pattern.rounds.map((round, index) => ({
      step: index + 1,
      round: round.round,
      title: `Vuelta ${round.round}`,
      objective: index === 0 ? `Comienza con ${round.inputStitches} puntos.` : `Continúa desde ${round.inputStitches} puntos.`,
      actions: round.operations.map(operationLabel),
      expectedStitches: round.expectedStitches,
      checkpoints: [
        `Entrada: ${round.inputStitches} puntos`,
        `Salida: ${round.expectedStitches} puntos`
      ],
      tip: 'Cuenta los puntos al terminar la vuelta antes de avanzar.',
      teacher: {
        state: 'explaining',
        script: [
          `Vamos con la vuelta ${round.round}.`,
          `Empieza con ${round.inputStitches} puntos y sigue la secuencia indicada.`,
          `Al terminar debes tener ${round.expectedStitches} puntos.`,
          'Si el conteo no coincide, detente y revisamos antes de continuar.'
        ],
        checkpoint: { expectedStitches: round.expectedStitches, inputStitches: round.inputStitches }
      }
    }));

    return {
      schemaVersion: 1,
      title: text(pattern.title, 200),
      level: text(options.level || 'Principiante', 40),
      language: 'es-MX',
      source: {
        patternTitle: text(pattern.title, 200),
        initialStitches: pattern.initialStitches,
        totalRounds: pattern.rounds.length,
        validationQuality: validation.quality
      },
      introduction: `Aprenderás a construir ${text(pattern.title, 200)} siguiendo una vuelta a la vez.`,
      materials: pattern.materials.map(x => text(x, 200)),
      abbreviations: pattern.abbreviations.map(x => text(x, 200)),
      steps: rounds,
      assembly: pattern.assembly.map(x => text(x, 500)),
      notes: pattern.notes.map(x => text(x, 500)),
      tutor: {
        supportedStates: ['idle','thinking','explaining','demonstrating','waiting_user','analyzing','correction','success','celebration'],
        interaction: ['lo_hice','no_me_sale','repetir','explicalo_mas_facil','que_sigue'],
        progression: { currentStep: 1, totalSteps: rounds.length, completedSteps: 0 }
      },
      completion: {
        checklist: [
          `Verifica las ${pattern.rounds.at(-1).expectedStitches} puntadas finales.`,
          'Revisa el ensamblaje antes de cerrar la pieza.',
          'Guarda tu progreso en el proyecto.'
        ]
      }
    };
  }

  return { create };
}

module.exports = { createTutorialService };
