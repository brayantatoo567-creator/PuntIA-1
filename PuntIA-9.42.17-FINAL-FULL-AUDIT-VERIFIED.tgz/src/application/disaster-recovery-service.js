'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function sha256File(file){
  const h=crypto.createHash('sha256');
  h.update(fs.readFileSync(file));
  return h.digest('hex');
}
function safeName(value){ return String(value||'backup').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,120); }
function createDisasterRecoveryService({execFile=defaultExecFile, now=()=>new Date()}={}){
  async function databaseBackup({databaseUrl,outputDir='/backups',label='puntia',pgDump='pg_dump'}={}){
    if(!databaseUrl) throw new Error('DATABASE_URL no configurada');
    fs.mkdirSync(outputDir,{recursive:true,mode:0o700});
    const stamp=now().toISOString().replace(/[:.]/g,'-');
    const file=path.join(outputDir,`${safeName(label)}-${stamp}.dump`);
    await execFile(pgDump,['--format=custom','--no-owner','--no-acl','--file',file,databaseUrl]);
    if(!fs.existsSync(file)) throw new Error('pg_dump no produjo el archivo de backup');
    const stat=fs.statSync(file);
    if(stat.size<=0) throw new Error('Backup PostgreSQL vacío');
    const checksum=sha256File(file);
    const manifest={version:1,type:'puntia-postgres-backup',createdAt:now().toISOString(),file:path.basename(file),size:stat.size,sha256:checksum,format:'custom',rpoMinutes:15,rtoMinutes:60};
    const manifestPath=`${file}.manifest.json`;
    fs.writeFileSync(manifestPath,JSON.stringify(manifest,null,2),{mode:0o600});
    return {ok:true,file,manifestPath,manifest};
  }
  async function verifyDatabaseBackup({file,manifestPath=`${file}.manifest.json`}={}){
    if(!file||!fs.existsSync(file)) throw new Error('Backup no encontrado');
    if(!fs.existsSync(manifestPath)) throw new Error('Manifiesto de backup no encontrado');
    const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
    const stat=fs.statSync(file);
    const checksum=sha256File(file);
    const ok=manifest.sha256===checksum&&Number(manifest.size)===stat.size&&manifest.format==='custom';
    return {ok,checksum,size:stat.size,manifest};
  }
  async function restoreDatabase({databaseUrl,backupFile,confirmRestore=false,pgRestore='pg_restore'}={}){
    if(!databaseUrl) throw new Error('DATABASE_URL no configurada');
    if(!backupFile||!fs.existsSync(backupFile)) throw new Error('Backup no encontrado');
    if(!confirmRestore) throw new Error('RESTORE_CONFIRM_REQUIRED');
    const verification=await verifyDatabaseBackup({file:backupFile});
    if(!verification.ok) throw new Error('BACKUP_INTEGRITY_FAILED');
    await execFile(pgRestore,['--clean','--if-exists','--no-owner','--no-acl','--dbname',databaseUrl,backupFile]);
    return {ok:true,restoredFrom:backupFile,verified:verification};
  }
  async function assetManifest({storage,listObjects,outputFile}={}){
    if(typeof listObjects!=='function') throw new Error('Se requiere listObjects para auditar assets');
    const objects=await listObjects();
    const normalized=(objects||[]).map(x=>({key:String(x.key),size:Number(x.size||0),etag:x.etag||null,lastModified:x.lastModified||null})).sort((a,b)=>a.key.localeCompare(b.key));
    const payload={version:1,type:'puntia-object-manifest',createdAt:now().toISOString(),count:normalized.length,objects:normalized};
    if(outputFile){fs.mkdirSync(path.dirname(outputFile),{recursive:true,mode:0o700});fs.writeFileSync(outputFile,JSON.stringify(payload,null,2),{mode:0o600});}
    return payload;
  }
  function recoveryPlan(){return {rpoMinutes:15,rtoMinutes:60,steps:['Freeze writes','Verify latest PostgreSQL dump checksum','Restore PostgreSQL into isolated target','Apply migrations','Restore/verify object manifest','Recover queued jobs from PostgreSQL leases','Run readiness and regression smoke checks','Reopen writes'],nonDestructiveRestore:true};}
  return {databaseBackup,verifyDatabaseBackup,restoreDatabase,assetManifest,recoveryPlan};
}
function defaultExecFile(command,args){
  return new Promise((resolve,reject)=>{require('child_process').execFile(command,args,{timeout:15*60*1000},(error,stdout,stderr)=>error?reject(Object.assign(error,{stdout,stderr})):resolve({stdout,stderr}));});
}
module.exports={createDisasterRecoveryService,sha256File};
