'use strict';

const FUNNEL_EVENTS = Object.freeze([
  'landing_view','account_started','account_registered','onboarding_started','onboarding_completed',
  'first_project','pattern_generated','pattern_validated','project_saved','first_value',
  'premium_cta','checkout_started','checkout_completed','project_completed','pdf_export'
]);

function createFunnelService(deps) {
  function readEvents() {
    const fs = deps.fs;
    const file = deps.EVENTS_FILE;
    try {
      return String(fs.readFileSync(file, 'utf8') || '').split(/\r?\n/).filter(Boolean).map(line => {
        try { return JSON.parse(line); } catch { return null; }
      }).filter(Boolean);
    } catch { return []; }
  }
  function event(name, userId, properties = {}) {
    if (!FUNNEL_EVENTS.includes(name)) throw Object.assign(new Error('Evento de funnel no permitido.'), { status:400, code:'INVALID_FUNNEL_EVENT' });
    deps.trackEvent(name, userId || null, properties);
    return { ok:true, name };
  }
  function userState(userId) {
    const events = readEvents().filter(e => e.userId === userId);
    const names = new Set(events.map(e => e.name));
    const steps = [
      ['account_registered', 'Cuenta creada'],
      ['onboarding_completed', 'Onboarding completado'],
      ['first_project', 'Primer proyecto'],
      ['pattern_validated', 'Primer patrón validado'],
      ['first_value', 'Primer resultado útil']
    ];
    const completed = steps.filter(([name]) => names.has(name)).map(([name,label]) => ({name,label}));
    const next = steps.find(([name]) => !names.has(name));
    return { completed, next: next ? { name:next[0], label:next[1] } : null, activated:names.has('first_value'), premiumCtaSeen:names.has('premium_cta') };
  }
  function overview() {
    const events = readEvents();
    const users = new Set(events.filter(e => e.userId).map(e => e.userId));
    const count = name => events.filter(e => e.name === name).length;
    const stages = ['account_registered','onboarding_completed','first_project','pattern_validated','first_value','premium_cta','checkout_started','checkout_completed'];
    const funnel = {};
    for (const s of stages) funnel[s] = count(s);
    const rate = (a,b) => funnel[a] ? Number((funnel[b] / funnel[a] * 100).toFixed(1)) : 0;
    return { users:users.size, funnel, conversion:{registrationToFirstValue:rate('account_registered','first_value'), firstValueToCheckout:rate('first_value','checkout_started'), checkoutToPaid:rate('checkout_started','checkout_completed')} };
  }
  return { event, userState, overview, FUNNEL_EVENTS };
}
module.exports = { createFunnelService, FUNNEL_EVENTS };
