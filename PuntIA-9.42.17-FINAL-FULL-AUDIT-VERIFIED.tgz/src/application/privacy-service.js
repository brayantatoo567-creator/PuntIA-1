'use strict';
const fs = require('fs');
const crypto = require('crypto');

function createPrivacyService(deps, services) {
  const RETENTION = {
    analyticsDays: Number(process.env.PUNTIA_ANALYTICS_RETENTION_DAYS || 90),
    auditDays: Number(process.env.PUNTIA_AUDIT_RETENTION_DAYS || 180),
    tombstoneDays: Number(process.env.PUNTIA_TOMBSTONE_RETENTION_DAYS || 30),
    resetTokenHours: Number(process.env.PUNTIA_RESET_TOKEN_RETENTION_HOURS || 24)
  };

  function owner(user) { return String(user?.id || '').trim(); }
  function confirmInput(body) {
    return String(body?.confirmation || '') === 'DELETE_ACCOUNT' && String(body?.currentPassword || '').length > 0;
  }

  function removeJsonUserMap(file, predicate) {
    if (!file || !fs.existsSync(file)) return 0;
    const value = deps.loadJsonFile(file, {});
    let count = 0;
    for (const [key, item] of Object.entries(value || {})) {
      if (predicate(item, key)) { delete value[key]; count++; }
    }
    if (count) deps.saveJsonFile(file, value);
    return count;
  }

  function removeJsonArray(file, predicate) {
    if (!file || !fs.existsSync(file)) return 0;
    const value = deps.loadJsonFile(file, []);
    if (!Array.isArray(value)) return 0;
    const next = value.filter(item => !predicate(item));
    const removed = value.length - next.length;
    if (removed) deps.saveJsonFile(file, next);
    return removed;
  }

  function removeJsonlByUser(file, userId, projectIds = [], jobIds = []) {
    if (!file || !fs.existsSync(file)) return 0;
    const projects = new Set(projectIds.map(String));
    const jobs = new Set(jobIds.map(String));
    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    const kept = [];
    let removed = 0;
    for (const line of lines) {
      let row;
      try { row = JSON.parse(line); } catch { kept.push(line); continue; }
      const match = String(row.userId || row.actorId || '') === String(userId)
        || projects.has(String(row.resourceId || ''))
        || jobs.has(String(row.resourceId || ''));
      if (match) removed++; else kept.push(line);
    }
    if (removed) {
      const tmp = `${file}.${process.pid}.${crypto.randomBytes(5).toString('hex')}.tmp`;
      fs.writeFileSync(tmp, kept.length ? `${kept.join('\n')}\n` : '', { mode: 0o600 });
      fs.renameSync(tmp, file);
    }
    return removed;
  }

  function deleteLocalIdentity(userId) {
    const users = deps.loadJsonFile(deps.USERS_FILE, []);
    const hadUser = users.some(u => String(u.id) === userId);
    if (hadUser) deps.saveJsonFile(deps.USERS_FILE, users.filter(u => String(u.id) !== userId));
    const sessionsRemoved = removeJsonUserMap(deps.SESSIONS_FILE, v => String(v?.userId || '') === userId);
    const resetRemoved = removeJsonUserMap(deps.RESET_TOKENS_FILE, v => String(v?.userId || '') === userId);
    const tombstonesRemoved = removeJsonUserMap(deps.SYNC_TOMBSTONES_FILE, v => String(v?.ownerId || '') === userId);
    return { users: hadUser ? 1 : 0, sessions: sessionsRemoved, resetTokens: resetRemoved, tombstones: tombstonesRemoved };
  }

  async function deleteLocalUserData(userId) {
    const projects = deps.loadProjects ? deps.loadProjects() : [];
    const owned = projects.filter(p => String(p.ownerId || '') === userId);
    const projectIds = owned.map(p => String(p.id));
    const assetKeys = owned.flatMap(p => Array.isArray(p.assets) ? p.assets.map(a => a?.key).filter(Boolean) : []).map(String);
    const jobIds = Object.values(deps.loadJsonFile(deps.JOB_FILE, {})).filter(j => String(j?.ownerId || '') === userId).map(j => String(j.id));

    const storage = deps.objectStorage || deps.cloud?.objectStorage;
    if (storage?.remove) {
      for (const key of assetKeys) { try { await storage.remove(key); } catch {} }
    }
    const memoryRemoved = await services.memory?.forgetUser(userId) || 0;
    const identity = deps.cloud?.authRepo ? { users: await deps.cloud.authRepo.deleteUser(userId), sessions: 'cascade', resetTokens: 'cascade', tombstones: 0 } : deleteLocalIdentity(userId);
    const billingSubscriptionsRemoved = deps.SUBSCRIPTIONS_FILE ? removeJsonUserMap(deps.SUBSCRIPTIONS_FILE, (v, key) => String(key) === userId) : 0;
    const feedbackRows = deps.FEEDBACK_FILE ? removeJsonArray(deps.FEEDBACK_FILE, v => String(v?.userId || '') === userId) : 0;
    const jobsRemoved = removeJsonUserMap(deps.JOB_FILE, v => String(v?.ownerId || '') === userId);
    const usage = deps.loadJsonFile(deps.USAGE_FILE, {});
    let usageRemoved = 0;
    for (const [key, row] of Object.entries(usage)) if (String(row?.userId || key.split(':')[0]) === userId) { delete usage[key]; usageRemoved++; }
    deps.saveJsonFile(deps.USAGE_FILE, usage);
    const reservationsRemoved = removeJsonUserMap(deps.RESERVATIONS_FILE, v => String(v?.userId || '') === userId);
    const projectsRemoved = owned.length;
    if (projectsRemoved) deps.saveProjects(projects.filter(p => String(p.ownerId || '') !== userId));
    const eventsRemoved = removeJsonlByUser(deps.EVENTS_FILE, userId, projectIds, jobIds);
    const auditRedacted = await deps.auditSink?.redactActor?.({ actorId: userId, resourceIds: [...projectIds, ...jobIds] }) || 0;
    return { ...identity, memory: memoryRemoved, billingSubscriptions: billingSubscriptionsRemoved, feedback: feedbackRows, projects: projectsRemoved, jobs: jobsRemoved, usage: usageRemoved, reservations: reservationsRemoved, analyticsEvents: eventsRemoved, auditRedacted, assets: assetKeys.length };
  }

  async function deleteCloudUserData(userId) {
    if (!deps.cloud?.privacyRepo) throw new Error('Privacy repository cloud no disponible.');
    const result = await deps.cloud.privacyRepo.deleteUserData(userId);
    const billingDeleted = await deps.cloud.billingRepo?.deleteUserData?.(userId) || {ok:true};
    const feedbackDeleted = await deps.feedbackRepo?.deleteUserData?.(userId) || {ok:true};
    const keys = new Set(result.assetKeys || []);
    if (deps.cloud.objectStorage?.list) {
      try {
        const objects = await deps.cloud.objectStorage.list();
        const prefix = `users/${userId}/`;
        for (const object of objects) if (String(object.key).startsWith(prefix)) keys.add(String(object.key));
      } catch {}
    }
    let assetsRemoved = 0;
    for (const key of keys) {
      try { if (await deps.cloud.objectStorage.remove(key)) assetsRemoved++; } catch {}
    }
    const auditRedacted = await deps.cloud.auditSink?.redactActor?.({ actorId: userId, resourceIds: [...(result.projectIds || []), ...(result.jobIds || [])] }) || 0;
    const memoryRemoved = await services.memory?.forgetUser(userId) || 0;
    const identity = deps.cloud?.authRepo ? { users: await deps.cloud.authRepo.deleteUser(userId), sessions: 'cascade', resetTokens: 'cascade', tombstones: 0 } : deleteLocalIdentity(userId);
    const billingSubscriptionsRemoved = deps.SUBSCRIPTIONS_FILE ? removeJsonUserMap(deps.SUBSCRIPTIONS_FILE, (v, key) => String(key) === userId) : 0;
    const feedbackRows = deps.FEEDBACK_FILE ? removeJsonArray(deps.FEEDBACK_FILE, v => String(v?.userId || '') === userId) : 0;
    const eventsRemoved = removeJsonlByUser(deps.EVENTS_FILE, userId, result.projectIds || [], result.jobIds || []);
    return { ...identity, memory: memoryRemoved, billing: billingDeleted, feedback: feedbackDeleted, projects: result.projectIds?.length || 0, jobs: result.jobIds?.length || 0, assets: assetsRemoved, auditRedacted, analyticsEvents: eventsRemoved, reservations: 'deleted', usage: 'deleted' };
  }

  async function deleteAccount({ user, currentPassword, confirmation } = {}) {
    const id = owner(user);
    if (!id) throw Object.assign(new Error('AUTH_REQUIRED'), { code: 'AUTH_REQUIRED', status: 401 });
    if (user.role === 'admin') throw Object.assign(new Error('La cuenta administradora no puede eliminarse desde este endpoint.'), { code: 'ADMIN_ACCOUNT_DELETE_BLOCKED', status: 403 });
    if (confirmation !== 'DELETE_ACCOUNT') throw Object.assign(new Error('Confirmación inválida.'), { code: 'DELETE_CONFIRMATION_REQUIRED', status: 400 });
    if (!services.auth.verifyPassword(currentPassword, user)) throw Object.assign(new Error('La contraseña actual no es correcta.'), { code: 'INVALID_CREDENTIALS', status: 401 });
    await services.audit?.record({ action:'account.deletion.started', resourceType:'account', actorId:id, status:'success', metadata:{policyVersion:'1'} });
    const result = deps.cloud?.privacyRepo ? await deleteCloudUserData(id) : await deleteLocalUserData(id);
    await services.audit?.record({ action:'account.deletion.completed', resourceType:'account', actorId:null, status:'success', metadata:{policyVersion:'1',deleted:result} });
    return { ok:true, deletedAt:new Date().toISOString(), retention:{backups:'subject to configured backup retention; not instantly mutable'}, deleted:result };
  }

  function retentionPolicy() {
    return { version:1, analyticsDays:RETENTION.analyticsDays, auditDays:RETENTION.auditDays, tombstoneDays:RETENTION.tombstoneDays, resetTokenHours:RETENTION.resetTokenHours, backups:'Backups are immutable retention copies and are removed only by backup lifecycle policy.' };
  }

  async function pruneRetention() {
    const now = Date.now();
    const resetCutoff = now - RETENTION.resetTokenHours * 3600 * 1000;
    if (deps.cloud?.authRepo) { const cloudPrune=await deps.cloud.authRepo.prune(); return { sessionsRemoved:cloudPrune.sessions, resetRemoved:cloudPrune.resetTokens, analyticsRemoved:0, auditRemoved:0, tombstonesRemoved:0 }; }
    const sessions = deps.loadJsonFile(deps.SESSIONS_FILE, {}); let sessionsRemoved=0;
    for (const [k,v] of Object.entries(sessions)) if (!v || Date.parse(v.expiresAt || 0) <= now) { delete sessions[k]; sessionsRemoved++; }
    if (sessionsRemoved) deps.saveJsonFile(deps.SESSIONS_FILE, sessions);
    const tokens = deps.loadJsonFile(deps.RESET_TOKENS_FILE, {}); let resetRemoved=0;
    for (const [k,v] of Object.entries(tokens)) if (!v || Date.parse(v.expiresAt || 0) <= resetCutoff) { delete tokens[k]; resetRemoved++; }
    if (resetRemoved) deps.saveJsonFile(deps.RESET_TOKENS_FILE, tokens);
    const analyticsCutoff = now - RETENTION.analyticsDays*86400000;
    let analyticsRemoved=0;
    if (deps.EVENTS_FILE && fs.existsSync(deps.EVENTS_FILE)) analyticsRemoved=removeJsonlOlderThan(deps.EVENTS_FILE, analyticsCutoff);
    let auditRemoved=0;
    if (deps.auditSink?.pruneBefore) auditRemoved=await deps.auditSink.pruneBefore(new Date(now-RETENTION.auditDays*86400000).toISOString());
    let tombstonesRemoved=0;
    if (deps.SYNC_TOMBSTONES_FILE) tombstonesRemoved=removeJsonUserMap(deps.SYNC_TOMBSTONES_FILE,v=>Date.parse(v?.deletedAt||0)<now-RETENTION.tombstoneDays*86400000);
    return { sessionsRemoved, resetRemoved, analyticsRemoved, auditRemoved, tombstonesRemoved };
  }

  function removeJsonlOlderThan(file, cutoffMs) {
    const lines=fs.readFileSync(file,'utf8').split('\n').filter(Boolean);const kept=[];let removed=0;
    for(const line of lines){let row;try{row=JSON.parse(line)}catch{kept.push(line);continue;}const t=Date.parse(row.at||row.occurredAt||0);if(Number.isFinite(t)&&t<cutoffMs)removed++;else kept.push(line);}
    if(removed){const tmp=`${file}.${process.pid}.${crypto.randomBytes(5).toString('hex')}.tmp`;fs.writeFileSync(tmp,kept.join('\n')+(kept.length?'\n':''),{mode:0o600});fs.renameSync(tmp,file);}return removed;
  }

  return { deleteAccount, retentionPolicy, pruneRetention };
}
module.exports = { createPrivacyService };
