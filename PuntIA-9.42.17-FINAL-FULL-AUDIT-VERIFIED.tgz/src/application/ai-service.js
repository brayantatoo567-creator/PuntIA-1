'use strict';

/** AI application service. Centralizes model selection and common accounting. */
function createAiService(deps) {
  return {
    async chat(input) {
      const data = await deps.openaiPost('responses', input);
      return { data, text: deps.outputText(data) || '' };
    },
    async route(pathname, payload, primary, fallback) {
      return deps.openaiPostModelFallback(pathname, payload, primary, fallback);
    },
    async imageEdit(input) {
      return deps.openaiImageEdit(input);
    },
    recordCost(model, kind) { deps.recordCost(model, kind, deps.estimateCost(kind)); },
    models() { return { chat: deps.runtime.chatModel, text: deps.runtime.textModel, pattern: deps.runtime.patternModel, vision: deps.runtime.visionModel, image: deps.runtime.imageModel }; }
  };
}
module.exports = { createAiService };
