'use strict';

const { interpretConcept, conceptPromptBlock } = require('../core/concept-decomposition');

const PATTERN_JSON_SCHEMA = Object.freeze({
  type: 'object',
  additionalProperties: false,
  required: ['title','initialStitches','materials','abbreviations','rounds','assembly','notes'],
  properties: {
    title: { type: 'string', minLength: 1, maxLength: 200 },
    initialStitches: { type: 'integer', minimum: 1 },
    materials: { type: 'array', items: { type: 'string' }, maxItems: 50 },
    abbreviations: { type: 'array', items: { type: 'string' }, maxItems: 100 },
    rounds: {
      type: 'array', minItems: 1, maxItems: 500,
      items: {
        type: 'object', additionalProperties: false,
        required: ['round','inputStitches','operations','expectedStitches'],
        properties: {
          round: { type: 'integer', minimum: 1 },
          inputStitches: { type: 'integer', minimum: 1 },
          operations: {
            type: 'array', minItems: 1, maxItems: 1000,
            items: {
              type: 'object', additionalProperties: false,
              required: ['type','count','repeats'],
              properties: {
                type: { type: 'string', enum: ['single','increase','decrease'] },
                count: { type: 'integer', minimum: 1, maximum: 1000 },
                repeats: { type: 'integer', minimum: 1, maximum: 1000 }
              }
            }
          },
          expectedStitches: { type: 'integer', minimum: 1 }
        }
      }
    },
    assembly: { type: 'array', items: { type: 'string' }, maxItems: 100 },
    notes: { type: 'array', items: { type: 'string' }, maxItems: 100 },
    geometry: {
      type: 'object', additionalProperties: false,
      required: ['type','targetHeightCm'],
      properties: {
        type: { type: 'string', enum: ['sphere','cylinder','cone','head','body','limb','ear','wing','tail','flat','custom'] },
        targetHeightCm: { type: 'number', exclusiveMinimum: 0 }
      }
    }
  }
});


/** Pattern domain/application service. No HTTP concerns. */
function createPatternService(deps) {
  return {
    validate(pattern, options = {}) {
      return deps.validatePattern(pattern, options);
    },
    extract(raw) {
      return deps.extractFirstJsonObject(raw);
    },
    interpretConcept(input = {}) {
      return interpretConcept(input);
    },
    buildPrompt(input) {
      const name = deps.safeText(input.name, 300);
      const level = deps.safeText(input.level, 50) || 'Principiante';
      const height = deps.safeText(input.height, 60);
      const style = deps.safeText(input.style, 120) || 'kawaii';
      const concept = input.concept || interpretConcept(input);
      return `Crea un patrón de crochet/amigurumi ejecutable para ${name}. Nivel: ${level}. Tamaño: ${height || 'no especificado'}. Estilo: ${style}.
INTERPRETACIÓN ESTRUCTURADA OBLIGATORIA: ${conceptPromptBlock(concept)}
La descomposición anterior es el contrato del diseño: representa todas las piezas requeridas en el ensamblaje y usa geometrías compatibles. No declares que una pieza existe si no puede asociarse a una parte tejible.
Devuelve PRIMERO JSON válido con esta forma exacta: {"title":string,"initialStitches":number,"materials":[string],"abbreviations":[string],"rounds":[{"round":number,"inputStitches":number,"operations":[{"type":"single"|"increase"|"decrease","count":number,"repeats":number}],"expectedStitches":number}],"assembly":[string],"notes":[string],"geometry":{"type":"sphere"|"cylinder"|"cone"|"head"|"body"|"limb"|"ear"|"wing"|"tail"|"flat"|"custom","targetHeightCm":number}}. Cada vuelta debe ser consecutiva y matemáticamente ejecutable.`;
    },
    responseFormat() { return { type: 'json_schema', name: 'puntia_pattern', strict: true, schema: PATTERN_JSON_SCHEMA }; },
    qualityGate(structured) {
      const validation = structured ? deps.validatePattern(structured, { strict: true }) : null;
      if (!structured || !validation?.qualityOk) {
        throw Object.assign(new Error('El Quality Gate rechazó el patrón.'), { code: 'PATTERN_QUALITY_GATE' });
      }
      return validation;
    }
  };
}
module.exports = { createPatternService, PATTERN_JSON_SCHEMA };
