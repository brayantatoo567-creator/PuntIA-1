'use strict';

const { contractError, assertProject } = require('../core/contracts');

function createVisualAssetLifecycleService(deps, services) {
  const VALID = new Set(['generated','validating','accepted','rejected','superseded']);

  function resolveOwner(user) { return user?.id || 'local'; }
  function find(project, assetId) { return (project?.assets || []).find(a => a.id === assetId) || null; }

  async function loadProject(user, projectId) {
    if (!projectId) throw contractError('PROJECT_REQUIRED','projectId es obligatorio para vincular el resultado visual.');
    const project = deps.cloud?.projectRepo
      ? await deps.cloud.projectRepo.get(projectId, resolveOwner(user))
      : services.projects.get(user, projectId);
    if (!project) throw contractError('PROJECT_NOT_FOUND','Proyecto no encontrado.',404);
    return project;
  }

  async function saveProject(user, project, patch, expectedVersion) {
    const input = { ...patch, expectedVersion };
    const next = deps.cloud?.projectRepo
      ? await deps.cloud.projectRepo.update(project.id, input, resolveOwner(user))
      : services.projects.update(user, project.id, input);
    return assertProject(next);
  }

  async function registerGenerated({ user, projectId, asset }) {
    if (!projectId) return null;
    const project = await loadProject(user, projectId);
    const assets = Array.isArray(project.assets) ? [...project.assets] : [];
    const sameHash = assets.filter(a => a.patternHash && a.patternHash === asset.patternHash && a.state === 'accepted');
    const normalized = {
      id: String(asset.id), type: 'pattern-visual', url: String(asset.url || ''), key: String(asset.key || ''),
      patternHash: String(asset.patternHash || ''), state: 'generated', supersedesAssetId: '', version: 1,
      createdAt: asset.createdAt || new Date().toISOString(), metadata: { ...(asset.metadata || {}), lifecycle: 'visual' }
    };
    for (const old of sameHash) old.state = 'superseded';
    assets.push(normalized);
    const next = await saveProject(user, project, { assets }, project.version);
    return { asset: normalized, project: next };
  }

  async function transition({ user, projectId, assetId, state, expectedVersion }) {
    if (!VALID.has(state)) throw contractError('INVALID_VISUAL_ASSET_STATE','Estado visual inválido.');
    const project = await loadProject(user, projectId);
    const current = find(project, assetId);
    if (!current) throw contractError('VISUAL_ASSET_NOT_FOUND','Asset visual no encontrado.',404);
    const allowed = {
      generated: new Set(['validating','rejected','accepted']),
      validating: new Set(['accepted','rejected']),
      accepted: new Set(['superseded']),
      rejected: new Set(['validating','accepted'])
    };
    if (current.state !== state && !allowed[current.state]?.has(state)) {
      throw contractError('INVALID_VISUAL_ASSET_TRANSITION',`No se permite pasar de ${current.state} a ${state}.`,409);
    }
    const assets = project.assets.map(a => a.id === assetId ? { ...a, state, version: Number(a.version || 1) + 1 } : { ...a });
    if (state === 'accepted') {
      for (const a of assets) {
        if (a.id !== assetId && a.patternHash === current.patternHash && a.state === 'accepted') a.state = 'superseded';
      }
    }
    const next = await saveProject(user, project, { assets }, expectedVersion ?? project.version);
    return { asset: find(next, assetId), project: next };
  }


  async function attachAcceptedAsset({ user, projectId, assetId, key = '', url = '', metadata = {}, expectedVersion } = {}) {
    const project = await loadProject(user, projectId);
    const current = find(project, assetId);
    if (!current) throw contractError('VISUAL_ASSET_NOT_FOUND','Asset visual no encontrado.',404);
    if (current.state !== 'accepted') throw contractError('VISUAL_ASSET_NOT_ACCEPTED','El asset visual debe estar aceptado antes de adjuntar su almacenamiento.',409);
    const assets = project.assets.map(a => a.id === assetId ? {
      ...a,
      key: String(key || ''),
      url: String(url || ''),
      metadata: { ...(a.metadata || {}), ...(metadata || {}) },
      version: Number(a.version || 1) + 1
    } : { ...a });
    const next = await saveProject(user, project, { assets }, expectedVersion ?? project.version);
    return { asset: find(next, assetId), project: next };
  }

  return { registerGenerated, transition, attachAcceptedAsset, loadProject, find };
}

module.exports = { createVisualAssetLifecycleService };
