# Application layer

The application layer owns use-case orchestration and domain policies. It must not depend on HTTP request/response objects.

- `usage-service.js`: quotas and usage accounting.
- `pattern-service.js`: pattern parsing, validation and quality gate.
- `project-service.js`: ownership, persistence and versioning rules.
- `job-service.js`: pattern-job lifecycle and orchestration.
- `auth-service.js`: account lookup/password operations.
- `billing-service.js`: plan/usage policies.
- `ai-service.js`: model routing and cost accounting.

Routes/controllers are responsible for transport concerns only: HTTP methods, parsing, status codes and response formatting.
