// PuntIA 9.5 route controller: analytics
'use strict';

module.exports = async function handleAnalytics(ctx) {
  const { req, res, url, p } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'POST' && p === '/api/analytics/event') {
    try { const user=currentUser(req); const body=await readJson(req); const allowed=['landing_view','first_project','pattern_generated','pattern_validated','project_saved','project_completed','pdf_export','premium_cta','account_started','account_registered','onboarding_started','onboarding_completed','first_value','checkout_started','checkout_completed']; const name=safeText(body.name,80); if(!allowed.includes(name)) return jsonError(res,400,'Evento no permitido.','INVALID_EVENT'); trackEvent(name,user?.id||null,{source:safeText(body.source,60),projectId:safeText(body.projectId,80)}); return send(res,204,''); } catch(e){ return jsonError(res,400,e.message,'ANALYTICS_FAILED'); }
  }
  return false;
};
