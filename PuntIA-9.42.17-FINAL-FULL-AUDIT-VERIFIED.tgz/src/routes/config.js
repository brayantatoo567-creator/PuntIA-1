// PuntIA 9.5 route controller: config
'use strict';

module.exports = async function handleConfig(ctx) {
  const { req, res, url, p } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, STRIPE_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime, loadSavedStripeConfig, saveStripeConfig, deleteSavedStripeConfig, getStripeConfig, stripeConfigured, stripeKeyLabel,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'GET' && p === '/api/config/openai') {
    if (!requireConfigAccess(req,res)) return;
    return send(res, 200, {
      configured: Boolean(runtime.apiKey),
      key: keyLabel(),
      source: configSource(),
      persisted: persisted(),
      textModel: runtime.textModel,
      visionModel: runtime.visionModel,
      imageModel: runtime.imageModel
    });
  }

  if (req.method === 'DELETE' && p === '/api/config/openai') {
    if (!requireConfigAccess(req,res)) return;
    try {
      deleteSavedConfig();
      if (hasEnvironmentKey()) {
        runtime.apiKey = process.env.OPENAI_API_KEY.trim();
        return send(res, 200, {
          ok: true,
          configured: true,
          key: keyLabel(),
          source: 'environment',
          persisted: true,
          textModel: runtime.textModel,
          visionModel: runtime.visionModel,
          imageModel: runtime.imageModel,
          message: 'Se eliminó la configuración guardada por la interfaz. Sigue activa la clave del entorno.'
        });
      }
      runtime.apiKey = '';
      return send(res, 200, {
        ok: true,
        configured: false,
        key: 'sin clave',
        source: 'none',
        persisted: false,
        textModel: runtime.textModel,
        visionModel: runtime.visionModel,
        imageModel: runtime.imageModel
      });
    } catch (error) {
      return jsonError(res, 500, error.message, 'CONFIG_DELETE_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/config/openai') {
    if (!requireConfigAccess(req,res)) return;
    try {
      const body = await readJson(req);
      const apiKey = String(body.apiKey || '').trim();
      if (!validKeyFormat(apiKey)) return jsonError(res, 400, 'La clave no tiene un formato válido. Debe comenzar con sk-.', 'INVALID_API_KEY_FORMAT');
      const candidate = {
        apiKey,
        textModel: normalizeModel(body.textModel, 'gpt-6-luna'),
        visionModel: normalizeModel(body.visionModel, normalizeModel(body.textModel, 'gpt-6-luna')),
        imageModel: normalizeModel(body.imageModel, 'gpt-image-2')
      };
      const verified = await verifyOpenAIKey(candidate);
      saveConfig(candidate);
      Object.assign(runtime, candidate);
      // Keep the in-memory snapshot in sync so health/config endpoints immediately report saved state.
      savedConfig.apiKey = candidate.apiKey;
      savedConfig.textModel = candidate.textModel;
      savedConfig.visionModel = candidate.visionModel;
      savedConfig.imageModel = candidate.imageModel;
      savedConfig.savedAt = new Date().toISOString();
      return send(res, 200, {
        ok: true,
        key: keyLabel(),
        textModel: candidate.textModel,
        visionModel: candidate.visionModel,
        imageModel: candidate.imageModel,
        reply: verified.reply,
        verified: true,
        persisted: true,
        message: 'Configuración guardada localmente en este servidor. La clave completa no se envía al navegador.'
      });
    } catch (error) {
      const status = error?.status === 401 || error?.status === 403 ? 401 : error?.status === 429 ? 429 : 502;
      return jsonError(res, status, `OpenAI rechazó la conexión: ${error.message}`, 'OPENAI_CONFIG_FAILED');
    }
  }

  if (req.method === 'GET' && p === '/api/config/stripe') {
    if (!requireConfigAccess(req,res)) return;
    const cfg=getStripeConfig();
    return send(res,200,{ok:true,configured:Boolean(cfg.secretKey&&cfg.prices.plus&&cfg.prices.pro),key:stripeKeyLabel(),webhookConfigured:Boolean(cfg.webhookSecret),prices:{plus:cfg.prices.plus,pro:cfg.prices.pro},persisted:Boolean(loadSavedStripeConfig().secretKey)});
  }

  if (req.method === 'POST' && p === '/api/config/stripe') {
    if (!requireConfigAccess(req,res)) return;
    try {
      const body=await readJson(req);
      const secretKey=String(body.secretKey||'').trim();
      const webhookSecret=String(body.webhookSecret||'').trim();
      const plusPrice=String(body.plusPrice||'').trim();
      const proPrice=String(body.proPrice||'').trim();
      if(!/^sk_(test|live)_[A-Za-z0-9]+$/.test(secretKey)) return jsonError(res,400,'La clave secreta de Stripe no tiene un formato válido.','INVALID_STRIPE_SECRET');
      if(!plusPrice||!proPrice) return jsonError(res,400,'Faltan los Price IDs de Plus y Pro.','INVALID_STRIPE_PRICES');
      const test=await stripeRequest('balance',{}, {method:'GET',secretKey});
      if(!test) throw new Error('Stripe no respondió correctamente.');
      saveStripeConfig({secretKey,webhookSecret,plusPrice,proPrice});
      const cfg=getStripeConfig();
      cfg.secretKey=secretKey; cfg.webhookSecret=webhookSecret; cfg.prices.plus=plusPrice; cfg.prices.pro=proPrice;
      return send(res,200,{ok:true,verified:true,configured:true,key:stripeKeyLabel(),webhookConfigured:Boolean(webhookSecret),prices:{plus:plusPrice,pro:proPrice},persisted:true,message:'Stripe validado y guardado en el servidor. Los secretos completos no se envían al navegador.'});
    } catch(error) {
      const status=error?.status===401||error?.status===403?401:error?.status===429?429:502;
      return jsonError(res,status,`Stripe rechazó la conexión: ${error.message}`,'STRIPE_CONFIG_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/config/stripe/test') {
    if (!requireConfigAccess(req,res)) return;
    try { const cfg=getStripeConfig(); if(!cfg.secretKey) return jsonError(res,400,'No hay una clave de Stripe activa.','NO_STRIPE_KEY'); await stripeRequest('balance',{}, {method:'GET'}); return send(res,200,{ok:true,verified:true,message:'La clave de Stripe fue verificada con una solicitud real.'}); }
    catch(error){ return jsonError(res,error?.status===429?429:502,`Prueba de Stripe no superada: ${error.message}`,'STRIPE_TEST_FAILED'); }
  }

  if (req.method === 'DELETE' && p === '/api/config/stripe') {
    if (!requireConfigAccess(req,res)) return;
    try { deleteSavedStripeConfig(); if(process.env.STRIPE_SECRET_KEY){ const cfg=getStripeConfig(); cfg.secretKey=process.env.STRIPE_SECRET_KEY; cfg.webhookSecret=process.env.STRIPE_WEBHOOK_SECRET||''; cfg.prices.plus=process.env.STRIPE_PRICE_PLUS||''; cfg.prices.pro=process.env.STRIPE_PRICE_PRO||''; return send(res,200,{ok:true,configured:Boolean(cfg.secretKey&&cfg.prices.plus&&cfg.prices.pro),source:'environment',message:'Configuración guardada eliminada; las variables del entorno siguen activas.'}); } const cfg=getStripeConfig(); cfg.secretKey=''; cfg.webhookSecret=''; cfg.prices.plus=''; cfg.prices.pro=''; return send(res,200,{ok:true,configured:false,source:'none'}); }
    catch(error){ return jsonError(res,500,error.message,'STRIPE_CONFIG_DELETE_FAILED'); }
  }

  if (req.method === 'POST' && p === '/api/config/openai/test') {
    if (!requireConfigAccess(req,res)) return;
    try {
      if (!runtime.apiKey) return jsonError(res, 400, 'No hay una clave OpenAI activa. Pulsa “Validar y conectar” primero.', 'NO_API_KEY');
      const verified = await verifyOpenAIKey(runtime);
      return send(res, 200, {
        ok: true,
        verified: true,
        reply: verified.reply,
        textModel: runtime.textModel,
        visionModel: runtime.visionModel,
        imageModel: runtime.imageModel,
        message: 'La clave, el modelo de texto y una solicitud real a Responses API fueron verificados.'
      });
    } catch (error) {
      return jsonError(res, error?.status === 429 ? 429 : 502, `Prueba de IA no superada: ${error.message}`, 'OPENAI_TEST_FAILED');
    }
  }


  return false;
};
