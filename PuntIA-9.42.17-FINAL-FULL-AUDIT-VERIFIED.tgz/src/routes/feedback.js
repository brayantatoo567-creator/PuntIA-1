'use strict';
module.exports = async function handleFeedback(ctx){
  const {req,res,p}=ctx;
  const {requireUser,requireAdmin,readJson,send,jsonError}=ctx.deps;
  if(req.method==='POST'&&p==='/api/feedback'){
    try{const user=requireUser(req,res);if(!user)return true;const body=await readJson(req);const result=await ctx.services.feedback.submit(user,body);return send(res,200,{ok:true,feedback:result});}
    catch(e){return jsonError(res,e.status||400,e.message,e.code||'FEEDBACK_FAILED');}
  }
  if(req.method==='GET'&&p==='/api/feedback/mine'){
    try{const user=requireUser(req,res);if(!user)return true;return send(res,200,{ok:true,feedback:await ctx.services.feedback.mine(user)});}catch(e){return jsonError(res,e.status||400,e.message,e.code||'FEEDBACK_FAILED');}
  }
  if(req.method==='GET'&&p==='/api/admin/feedback'){
    const admin=requireAdmin(req,res);if(!admin)return true;return send(res,200,{ok:true,quality:await ctx.services.feedback.overview()});
  }
  return false;
};
