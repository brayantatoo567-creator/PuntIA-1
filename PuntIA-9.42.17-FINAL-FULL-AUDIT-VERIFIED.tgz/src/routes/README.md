# PuntIA route boundary

Public HTTP contracts are preserved while handlers are split by domain:

- `health.js` — health/readiness and diagnostics
- `auth.js` — authentication, sessions, CSRF and usage
- `projects.js` — projects, versions, jobs and pattern validation
- `ai.js` — chat, pattern generation, vision/diagnosis and image generation
- `billing.js` — plans, checkout and Stripe webhooks
- `analytics.js` — product events
- `admin.js` — administrative views and cost/event reporting
- `config.js` — AI configuration and verification
- `router.js` — deterministic dispatch

Routes receive explicit dependencies through `ctx.deps`, which keeps HTTP concerns separated from the application bootstrap without changing existing URLs.
