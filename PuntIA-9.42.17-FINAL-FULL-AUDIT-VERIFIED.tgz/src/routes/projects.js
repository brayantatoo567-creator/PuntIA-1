// PuntIA 9.5 route controller: projects/jobs
'use strict';

module.exports = async function handleProjects(ctx) {
  const { req, res, url, p, deps, services } = ctx;
  const {
    REQUIRE_ACCOUNT_FOR_PROJECTS, requireUser, currentUser, readJson, send, jsonError,
    usagePayload, validatePattern
  } = deps;
  const { projects, jobs, usage, pattern } = services;
  const userForProjects = () => REQUIRE_ACCOUNT_FOR_PROJECTS ? requireUser(req, res) : currentUser(req);

  if (req.method === 'POST' && p === '/api/jobs') {
    try {
      const user = userForProjects();
      if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
      const body = await readJson(req);
      const job = await jobs.createPatternJob({ user, input: body });
      return send(res, 202, { ok: true, job });
    } catch (error) {
      return jsonError(res, error.status || 400, error.message, error.code || 'JOB_CREATE_FAILED');
    }
  }

  const jobMatch = p.match(/^\/api\/jobs\/([0-9a-f-]{36})$/i);
  if (jobMatch && req.method === 'GET') {
    const user = userForProjects();
    if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
    const job = await jobs.get(user, jobMatch[1]);
    return job ? send(res, 200, { ok: true, job }) : jsonError(res, 404, 'Trabajo no encontrado.', 'JOB_NOT_FOUND');
  }

  if (jobMatch && req.method === 'DELETE') {
    const user = userForProjects();
    if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
    const job = await jobs.cancel(user, jobMatch[1]);
    return job ? send(res, 200, { ok: true, job }) : jsonError(res, 404, 'Trabajo no encontrado.', 'JOB_NOT_FOUND');
  }

  if (req.method === 'GET' && p === '/api/projects') {
    const user = userForProjects();
    if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
    const list = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.list(user?.id || 'local') : projects.list(user);
    return send(res, 200, { ok: true, projects: list, total: list.length, account: deps.publicUser(user), usage: deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usage.snapshot(user) });
  }

  if (req.method === 'POST' && p === '/api/projects') {
    try {
      const user = userForProjects();
      if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
      const body = await readJson(req);
      const project = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.create(body, user?.id || 'local') : projects.create(user, body);
      return send(res, 201, { ok: true, project });
    } catch (error) {
      return jsonError(res, error.status || 400, error.message, error.code || 'PROJECT_CREATE_FAILED');
    }
  }

  const projectMatch = p.match(/^\/api\/projects\/([0-9a-f-]{36})$/i);
  if (projectMatch && req.method === 'GET') {
    const user = userForProjects();
    if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
    const project = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.get(projectMatch[1], user?.id || 'local') : projects.get(user, projectMatch[1]);
    if (!project) return jsonError(res, 404, 'Proyecto no encontrado.', 'PROJECT_NOT_FOUND');
    if (url.searchParams.get('versions') === '1') return send(res, 200, { ok: true, versions: project.versions || [], currentVersion: project.version || 1 });
    return send(res, 200, { ok: true, project });
  }

  if (projectMatch && req.method === 'PATCH' && url.searchParams.get('progress') === '1') {
    try {
      const user=userForProjects(); if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
      const body=await readJson(req);
      const current=deps.cloud?.projectRepo ? await deps.cloud.projectRepo.get(projectMatch[1], user?.id || 'local') : projects.get(user, projectMatch[1]);
      if (!current) return jsonError(res,404,'Proyecto no encontrado.','PROJECT_NOT_FOUND');
      const nextProgress=Math.max(0,Math.min(100,Number(body.progress)));
      if (!Number.isFinite(nextProgress)) return jsonError(res,400,'Progreso inválido.','INVALID_PROJECT_PROGRESS');
      const patch={progress:nextProgress,progressState:body.progressState||current.progressState,expectedVersion:body.expectedVersion};
      const project=deps.cloud?.projectRepo ? await deps.cloud.projectRepo.update(projectMatch[1], {...current,...patch}, user?.id || 'local') : projects.update(user, projectMatch[1], patch);
      return send(res,200,{ok:true,project});
    } catch(error) { return jsonError(res,error.status||400,error.message,error.code||'PROJECT_PROGRESS_FAILED'); }
  }

  if (projectMatch && (req.method === 'PUT' || req.method === 'PATCH')) {
    try {
      const user = userForProjects();
      if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
      const body = await readJson(req);
      const project = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.update(projectMatch[1], body, user?.id || 'local') : projects.update(user, projectMatch[1], body);
      return send(res, 200, { ok: true, project });
    } catch (error) {
      return jsonError(res, error.status || 400, error.message, error.code || 'PROJECT_UPDATE_FAILED');
    }
  }

  if (projectMatch && req.method === 'DELETE') {
    try {
      const user = userForProjects();
      if (REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
      const owner = user?.id || 'local';
      const id = projectMatch[1];
      const current = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.get(id, owner) : projects.get(user, id);
      if (!current) return jsonError(res, 404, 'Proyecto no encontrado.', 'PROJECT_NOT_FOUND');
      const deleted = deps.cloud?.projectRepo ? await deps.cloud.projectRepo.remove(id, owner) : projects.remove(user, id);
      if (services.syncTombstones) await services.syncTombstones.put(owner, id, Number(current.version || 1), new Date().toISOString());
      return send(res, 200, { ok: true, deleted });
    } catch (error) {
      return jsonError(res, error.status || 404, error.message, error.code || 'PROJECT_DELETE_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/puntia/assistant') {
    try {
      const body=await readJson(req);
      if(!body.pattern) return jsonError(res,400,'pattern es obligatorio.','PATTERN_REQUIRED');
      return send(res,200,services.assistant.answer(body.pattern,body.context||{}));
    } catch(error) { return jsonError(res,error.status||400,error.message,error.code||'ASSISTANT_FAILED'); }
  }

  if (req.method === 'POST' && p === '/api/puntia/validate-pattern') {
    try {
      const body = await readJson(req);
      return send(res, 200, pattern.validate(body, { strict: false }));
    } catch (error) {
      return jsonError(res, 400, error.message, 'PATTERN_VALIDATION_FAILED');
    }
  }

  return false;
};
