// PuntIA 9.5 route controller: auth
'use strict';

const crypto = require('node:crypto');
function tokenHash(token) { return crypto.createHash('sha256').update(String(token)).digest('hex'); }

async function createCloudSession(res,user,req,authRepo){
  const token=crypto.randomBytes(32).toString('base64url');
  const now=new Date().toISOString();
  const session={sessionId:crypto.randomUUID(),userId:user.id,authVersion:Number(user.authVersion||1),csrf:crypto.randomBytes(24).toString('base64url'),createdAt:now,lastSeenAt:now,expiresAt:new Date(Date.now()+Number(process.env.PUNTIA_SESSION_TTL_MS||1000*60*60*24*30)).toISOString(),userAgent:String(req.headers['user-agent']||'').slice(0,300)};
  await authRepo.createSession(tokenHash(token),session);
  const secure=(process.env.NODE_ENV==='production'||/^https:\/\//i.test(String(process.env.PUNTIA_PUBLIC_URL||'')))?'; Secure':'';
  const sameSite=['Strict','Lax','None'].includes(String(process.env.PUNTIA_COOKIE_SAMESITE||'Lax'))?String(process.env.PUNTIA_COOKIE_SAMESITE||'Lax'):'Lax';
  res.setHeader('Set-Cookie',`puntia_session=${encodeURIComponent(token)}; HttpOnly; SameSite=${sameSite}; Path=/; Max-Age=${Math.floor((Date.parse(session.expiresAt)-Date.now())/1000)}${secure}${sameSite==='None'&&!secure?'; Secure':''}`);
}

module.exports = async function handleAuth(ctx) {
  const { req, res, url, p, deps } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, revokeAllSessions, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    authRepo, openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'GET' && p === '/api/auth/me') {
    const user=currentUser(req); return send(res,200,{ok:true,authenticated:Boolean(user),user:publicUser(user),usage:deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usagePayload(user)});
  }
  if (req.method === 'GET' && p === '/api/auth/csrf') return send(res,200,{ok:true,csrf:csrfToken(req),required:REQUIRE_CSRF});
  if (req.method === 'POST' && p === '/api/auth/register') {
    try { const body=await readJson(req); const email=safeText(body.email,160).toLowerCase(); const name=safeText(body.name,80)||email.split('@')[0]; const password=String(body.password||'');
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return jsonError(res,400,'Correo electrónico inválido.','INVALID_EMAIL');
      if(password.length<PASSWORD_MIN || password.length>128) return jsonError(res,400,`La contraseña debe tener entre ${PASSWORD_MIN} y 128 caracteres.`,'INVALID_PASSWORD');
      const hp=hashPassword(password); const user={id:crypto.randomUUID(),email,name,passwordHash:hp.hash,passwordSalt:hp.salt,authVersion:1,plan:'free',role:'user',createdAt:new Date().toISOString()};
      if(authRepo){ if(await authRepo.findByEmail(email)) return jsonError(res,409,'Ese correo ya está registrado.','EMAIL_EXISTS'); await authRepo.createUser(user); await createCloudSession(res,user,req,authRepo); }
      else { const users=loadJsonFile(USERS_FILE,[]); if(users.some(u=>u.email===email)) return jsonError(res,409,'Ese correo ya está registrado.','EMAIL_EXISTS'); users.push(user); saveJsonFile(USERS_FILE,users); setSession(res,user.id,{userAgent:req.headers['user-agent']}); }
      return send(res,201,{ok:true,user:publicUser(user),usage:deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usagePayload(user)});
    } catch(e){return jsonError(res,400,e.message,'REGISTER_FAILED');}
  }
  if (req.method === 'POST' && p === '/api/auth/login') {
    try {
      const body=await readJson(req);
      const email=safeText(body.email,160).toLowerCase();
      const password=String(body.password||'');
      const user=authRepo ? await authRepo.findByEmail(email) : loadJsonFile(USERS_FILE,[]).find(u=>u.email===email);
      if(!user || !verifyPassword(password,user)) return jsonError(res,401,'Correo o contraseña incorrectos.','INVALID_CREDENTIALS');
      if(authRepo){
        if(!user.authVersion) user.authVersion=1;
        await createCloudSession(res,user,req,authRepo);
      } else {
        const users=loadJsonFile(USERS_FILE,[]);
        if(!user.authVersion){user.authVersion=1;const idx=users.findIndex(u=>u.id===user.id);if(idx>=0){users[idx]=user;saveJsonFile(USERS_FILE,users);}}
        setSession(res,user.id,{userAgent:req.headers['user-agent']});
      }
      return send(res,200,{ok:true,user:publicUser(user),usage:deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usagePayload(user)});
    } catch(e){return jsonError(res,400,e.message,'LOGIN_FAILED');}
  }
  if (req.method === 'POST' && p === '/api/auth/request-reset') { try { const body=await readJson(req); const email=safeText(body.email,160).toLowerCase(); const user=authRepo ? await authRepo.findByEmail(email) : loadJsonFile(USERS_FILE,[]).find(u=>u.email===email); const out={ok:true,message:'Si la cuenta existe, se ha preparado la recuperación.'}; if(!user)return send(res,200,out); const token=crypto.randomBytes(32).toString('base64url'); const expiresAt=new Date(Date.now()+900000).toISOString(); if(authRepo) await authRepo.createResetToken(tokenHash(token),user.id,expiresAt); else {const t=loadJsonFile(RESET_TOKENS_FILE,{}); t[tokenHash(token)]={userId:user.id,expiresAt}; saveJsonFile(RESET_TOKENS_FILE,t);} if(process.env.NODE_ENV!=='production')out.devToken=token; return send(res,200,out);}catch(e){return jsonError(res,400,e.message,'RESET_REQUEST_FAILED');} }
  if (req.method === 'POST' && p === '/api/auth/reset-password') { try { const body=await readJson(req); const token=String(body.token||''); const password=String(body.password||''); if(password.length<PASSWORD_MIN||password.length>128)return jsonError(res,400,`La contraseña debe tener entre ${PASSWORD_MIN} y 128 caracteres.`,'INVALID_PASSWORD'); const entry=authRepo ? await authRepo.consumeResetToken(tokenHash(token)) : loadJsonFile(RESET_TOKENS_FILE,{} )[tokenHash(token)]; if(!entry||Date.parse(entry.expiresAt)<=Date.now())return jsonError(res,400,'Token inválido o expirado.','RESET_TOKEN_INVALID'); const hp=hashPassword(password); if(authRepo){const user=await authRepo.findById(entry.userId); if(!user)return jsonError(res,404,'Cuenta no encontrada.','USER_NOT_FOUND'); await authRepo.updateUser(user.id,{passwordHash:hp.hash,passwordSalt:hp.salt,authVersion:Number(user.authVersion||1)+1}); await authRepo.revokeAllSessions(user.id);} else {const t=loadJsonFile(RESET_TOKENS_FILE,{}); const users=loadJsonFile(USERS_FILE,[]); const i=users.findIndex(u=>u.id===entry.userId); if(i<0)return jsonError(res,404,'Cuenta no encontrada.','USER_NOT_FOUND'); users[i].passwordHash=hp.hash;users[i].passwordSalt=hp.salt;saveJsonFile(USERS_FILE,users);delete t[tokenHash(token)];saveJsonFile(RESET_TOKENS_FILE,t);revokeAllSessions(entry.userId);} return send(res,200,{ok:true});}catch(e){return jsonError(res,400,e.message,'RESET_FAILED');} }
  if (req.method === 'POST' && p === '/api/auth/change-password') {
    try { const user=requireUser(req,res); if(!user)return true; const body=await readJson(req); const current=String(body.currentPassword||''); const next=String(body.newPassword||''); if(next.length<PASSWORD_MIN||next.length>128)return jsonError(res,400,`La nueva contraseña debe tener entre ${PASSWORD_MIN} y 128 caracteres.`,'INVALID_PASSWORD'); if(!verifyPassword(current,user))return jsonError(res,401,'La contraseña actual no es correcta.','INVALID_CREDENTIALS'); const hp=hashPassword(next); if(authRepo){await authRepo.updateUser(user.id,{passwordHash:hp.hash,passwordSalt:hp.salt,authVersion:Number(user.authVersion||1)+1}); await authRepo.revokeAllSessions(user.id);} else {const users=loadJsonFile(USERS_FILE,[]); const i=users.findIndex(u=>u.id===user.id); if(i<0)return jsonError(res,404,'Cuenta no encontrada.','USER_NOT_FOUND'); users[i].passwordHash=hp.hash; users[i].passwordSalt=hp.salt; saveJsonFile(USERS_FILE,users); revokeAllSessions(user.id);} return send(res,200,{ok:true,message:'Contraseña actualizada. Inicia sesión nuevamente.'}); } catch(e){return jsonError(res,400,e.message,'PASSWORD_CHANGE_FAILED');}
  }
  if (req.method === 'GET' && p === '/api/auth/sessions') {
    const user=requireUser(req,res); if(!user)return true; const se=sessionEntry(req); const out=authRepo ? (await authRepo.listSessions(user.id)).map(v=>({id:v.sessionId,createdAt:v.createdAt,lastSeenAt:v.lastSeenAt||v.createdAt,expiresAt:v.expiresAt,current:v.sessionId===se?.entry?.sessionId,userAgent:v.userAgent||''})) : Object.values(loadJsonFile(SESSIONS_FILE,{})).filter(v=>v?.userId===user.id).map(v=>({id:v.sessionId,createdAt:v.createdAt,lastSeenAt:v.lastSeenAt||v.createdAt,expiresAt:v.expiresAt,current:v.sessionId===se?.entry?.sessionId,userAgent:v.userAgent||''})); return send(res,200,{ok:true,sessions:out});
  }

  if (req.method === 'POST' && p === '/api/auth/delete-account') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const body=await readJson(req);
      const result=await ctx.services.privacy.deleteAccount({user,currentPassword:String(body.currentPassword||''),confirmation:String(body.confirmation||'')});
      clearSession(req,res);
      return send(res,200,result);
    } catch(e) {
      return jsonError(res,e.status||400,e.message,e.code||'ACCOUNT_DELETE_FAILED');
    }
  }
  if (req.method === 'POST' && p === '/api/auth/logout-all') {
    const user=requireUser(req,res); if(!user)return true; if(authRepo) await authRepo.revokeAllSessions(user.id); else revokeAllSessions(user.id); return send(res,200,{ok:true,message:'Todas las sesiones fueron revocadas.'});
  }
  if (req.method === 'POST' && p === '/api/auth/logout') {
    if(authRepo){ const token=parseCookies(req).puntia_session; if(token) await authRepo.deleteSession(tokenHash(token)); }
    else clearSession(req,res);
    const secure=(process.env.NODE_ENV==='production'||/^https:\/\//i.test(PUBLIC_URL))?'; Secure':'';
    res.setHeader('Set-Cookie',`puntia_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure}`);
    return send(res,200,{ok:true});
  }

  return false;
};
