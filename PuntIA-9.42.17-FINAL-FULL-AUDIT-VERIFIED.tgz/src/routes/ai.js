// PuntIA 9.5 route controller: ai
'use strict';

module.exports = async function handleAi(ctx) {
  const { req, res, url, p, deps, services } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, confirmUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'GET' && p === '/api/puntia/memory') {
    try {
      const user = currentUser(req);
      if (!user) return send(res, 200, { ok:true, enabled:false, message:'Inicia sesión para activar la memoria personal de PuntIA.', memory:{ recentTurns:[], generatedPatterns:[] } });
      const memory = await services.memory.recent(user, { conversationId:url.searchParams.get('conversationId') || null, limit:12 });
      return send(res, 200, { ok:true, enabled:true, conversationId:memory.conversation?.id || null, turns:memory.turns, patterns:memory.patterns });
    } catch (error) { return jsonError(res, error.status || 500, error.message, error.code || 'MEMORY_READ_FAILED'); }
  }

  if (req.method === 'DELETE' && p === '/api/puntia/memory') {
    try {
      const user = requireUser(req,res); if(!user) return true;
      const removed = await services.memory.forgetUser(user.id);
      return send(res,200,{ok:true,removed});
    } catch(error) { return jsonError(res,error.status||500,error.message,error.code||'MEMORY_DELETE_FAILED'); }
  }


  if (req.method === 'POST' && p === '/api/puntia/chat/stream') {
    let usageReservation=null;
    let aiUser=null;
    try {
      const body = await readJson(req);
      aiUser = requireAiAccess(req,res); if (REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      const message = String(body.message || '').trim();
      if (!message) return jsonError(res, 400, 'Falta el mensaje.', 'MISSING_MESSAGE');
      if (message.length > 12000) return jsonError(res, 413, 'El mensaje es demasiado largo.', 'MESSAGE_TOO_LONG');
      const quota=await reserveUsage(aiUser,'chat'); usageReservation=quota.allowed?quota:null; if(!quota.allowed) return jsonError(res,429,`Límite mensual de chat alcanzado (${quota.limit}). Actualiza tu plan para continuar.`,'USAGE_LIMIT');
      const context = body.context && typeof body.context === 'object' ? body.context : {};
      const memory = aiUser ? await services.memory.contextForChat(aiUser, { conversationId:body.conversationId || null, limit:12 }) : { conversationId:null, recentTurns:[], generatedPatterns:[] };
      const memoryText = memory.recentTurns.length ? memory.recentTurns.map(t => `${t.role}: ${t.text}`).join('\n').slice(0, 9000) : 'Sin conversación previa.';
      const patternText = memory.generatedPatterns.length ? memory.generatedPatterns.map(p => `${p.name} (${p.patternHash.slice(0,12)})`).join(', ') : 'Sin patrones previos registrados.';
      const instructions = `${SYSTEM}\nEres un tutor persistente. Usa la memoria como contexto, pero nunca inventes recuerdos.\nConversación previa reciente:\n${memoryText}\nPatrones generados anteriormente: ${patternText}\nPaso actual: ${String(context.teacherStep || '').slice(0, 100)}. Lección: ${String(context.lesson || '').slice(0, 300)}. Puntada: ${String(context.stitch || '').slice(0, 100)}.`;
      const data = await openaiPost('responses', {
        model: runtime.textModel,
        instructions,
        input: [{ role: 'user', content: message }]
      });
      const text = outputText(data) || '';
      if (aiUser) {
        const c = await services.memory.appendTurn(aiUser, { conversationId:memory.conversationId, role:'user', text:message, context });
        await services.memory.appendTurn(aiUser, { conversationId:c.id, role:'assistant', text, context });
      }
      res.statusCode = 200;
      res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      for (const chunk of text.match(/.{1,48}/gs) || []) res.write(`data: ${JSON.stringify({ type: 'delta', text: chunk })}\n\n`);
      if (usageReservation?.reservationId) await confirmUsage(aiUser,'chat',usageReservation.reservationId);
      res.write(`data: ${JSON.stringify({ type: 'meta', conversationId: aiUser ? (await services.memory.recent(aiUser, { conversationId:body.conversationId || null, limit:1 })).conversation?.id || null : null })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    } catch (error) {
      if (usageReservation && aiUser) await releaseUsage(aiUser,'chat',usageReservation?.reservationId);
      if (!res.headersSent) return jsonError(res, error?.status === 429 ? 429 : 502, error.message, 'CHAT_FAILED');
      res.write(`data: ${JSON.stringify({ type: 'error', error: error.message })}\n\n`);
      res.write('data: [DONE]\n\n');
      return res.end();
    }
  }

  if (req.method === 'POST' && p === '/api/puntia/teacher/lesson') {
    try {
      const body = await readJson(req);
      if (!body.pattern) return jsonError(res, 400, 'pattern es obligatorio para una lección contextual.', 'TUTOR_PATTERN_REQUIRED');
      const tutorial = services.tutorials.create(body.pattern, { level: body.level || 'Principiante' });
      const requested = Number(body.step || 1);
      const step = Number.isFinite(requested) ? Math.min(tutorial.steps.length, Math.max(1, Math.trunc(requested))) : 1;
      const lesson = tutorial.steps[step - 1];
      const actionText = lesson.actions.length ? lesson.actions.join(' · ') : 'Sigue las instrucciones de esta vuelta.';
      const messages = [
        `Prepara ${lesson.inputStitches} puntos.`,
        `Ejecuta: ${actionText}.`,
        `Comprueba que termines con ${lesson.expectedStitches} puntos.`,
        'Si no coincide, no avances: puedo ayudarte a localizar el error.'
      ];
      return send(res, 200, { ok: true, step, total: tutorial.steps.length, lesson: [lesson.title, messages.join(' ')], detail: lesson, tutor: tutorial.tutor, state: 'explaining' });
    } catch (error) {
      return jsonError(res, error.status || 422, error.message, error.code || 'LESSON_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/puntia/edit-pattern') {
    try {
      const body = await readJson(req);
      const aiUser = requireAiAccess(req,res);
      if (REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      if (!body.pattern || typeof body.pattern !== 'object') return jsonError(res,400,'pattern es obligatorio y debe ser un objeto.','EDITOR_PATTERN_REQUIRED');
      const result = services.patternEditor.edit({
        pattern: body.pattern,
        changes: body.changes && typeof body.changes === 'object' ? body.changes : {},
        concept: body.concept && typeof body.concept === 'object' ? body.concept : null
      });
      return send(res,200,result);
    } catch(error) {
      return jsonError(res,error?.status || 422,error.message,error.code || 'PATTERN_EDIT_FAILED');
    }
  }

  if (req.method === 'POST' && ['/api/puntia/chat', '/api/puntia/generate-pattern'].includes(p)) {
    let usageReservation = null;
    let aiUser = null;
    try {
      const body = await readJson(req);
      aiUser = requireAiAccess(req,res);
      if (REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      if (p.endsWith('/chat')) {
        const message = String(body.message || '').trim();
        if (!message) return jsonError(res, 400, 'Falta el mensaje.', 'MISSING_MESSAGE');
        if (message.length > 12000) return jsonError(res, 413, 'El mensaje es demasiado largo.', 'MESSAGE_TOO_LONG');
        const quota=await reserveUsage(aiUser,'chat'); usageReservation=quota.allowed?quota:null;
        if(!quota.allowed) return jsonError(res,429,`Límite mensual de chat alcanzado (${quota.limit}). Actualiza tu plan para continuar.`,'USAGE_LIMIT');
        const memory = aiUser ? await services.memory.contextForChat(aiUser, { conversationId:body.conversationId || null, limit:12 }) : { conversationId:null, recentTurns:[], generatedPatterns:[] };
        const memoryText = memory.recentTurns.map(t => `${t.role}: ${t.text}`).join('\n').slice(0, 9000) || 'Sin conversación previa.';
        const patternText = memory.generatedPatterns.map(p => `${p.name} (${p.patternHash.slice(0,12)})`).join(', ') || 'Sin patrones previos registrados.';
        const instructions = `${SYSTEM}\nMemoria persistente reciente:\n${memoryText}\nPatrones previos: ${patternText}\nNo inventes recuerdos y prioriza los datos actuales del usuario.`;
        const data = await openaiPost('responses', { model: runtime.chatModel || runtime.textModel, instructions, input: [{ role: 'user', content: message }] });
        const reply = outputText(data) || '';
        const c = await services.memory.appendTurn(aiUser, { conversationId:memory.conversationId, role:'user', text:message, context:body.context||{} });
        await services.memory.appendTurn(aiUser, { conversationId:c.id, role:'assistant', text:reply, context:body.context||{} });
        services.costAccounting?.recordProviderUsage({model:runtime.chatModel||runtime.textModel,kind:'chat',response:data,userId:aiUser?.id||null,requestId:requestId(req),metadata:{route:'chat'}});
        if (usageReservation?.reservationId) await confirmUsage(aiUser,'chat',usageReservation.reservationId);
        return send(res, 200, { reply, conversationId:c.id, memoryEnabled:Boolean(aiUser) });
      }

      const correlationId = requestId(req);
      const result = await services.patternPipeline.generate({ user: aiUser, input: body, persist: false, correlationId });
      return send(res, 200, result);
    } catch (error) {
      if (usageReservation && aiUser) await releaseUsage(aiUser,'chat',usageReservation.reservationId);
      return jsonError(res, error?.status === 429 ? 429 : (error?.status === 422 ? 422 : 502), error.message, error.code || 'AI_REQUEST_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/puntia/validate-pattern-visual') {
    try {
      const body = await readJson(req);
      const aiUser = requireAiAccess(req,res);
      if (REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      if (!body.pattern) return jsonError(res,400,'pattern es obligatorio.','PATTERN_REQUIRED');
      if (!body.image && !body.assetKey) return jsonError(res,400,'image o assetKey es obligatorio.','VISUAL_IMAGE_REQUIRED');
      const correlationId = requestId(req);
      const result = await services.patternVisualValidation.validate({ user: aiUser, pattern: body.pattern, image: body.image || '', assetKey: body.assetKey || null, patternHash: body.patternHash || null, projectId: body.projectId || null, assetId: body.assetId || null, expectedVersion: body.expectedVersion ?? null, correlationId });
      return send(res,200,result);
    } catch(error) {
      return jsonError(res,error?.status===429?429:(error?.status===422?422:(error?.status===409?409:(error?.status===403?403:(error?.status===404?404:502)))),error.message,error.code||'PATTERN_VISUAL_VALIDATION_FAILED');
    }
  }

  if (req.method === 'POST' && p === '/api/puntia/generate-pattern-visual') {
    try {
      const body=await readJson(req);
      const aiUser=requireAiAccess(req,res); if(REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      if(!body.pattern) return jsonError(res,400,'pattern es obligatorio.','PATTERN_REQUIRED');
      const correlationId=requestId(req);
      const result=await services.patternVisual.generate({user:aiUser,pattern:body.pattern,prompt:body.prompt||'',persist:true,projectId:body.projectId||null,correlationId});
      return send(res,200,result);
    } catch(error) { return jsonError(res,error?.status===429?429:(error?.status===422?422:502),error.message,error.code||'PATTERN_VISUAL_FAILED'); }
  }

  if (req.method === 'POST' && (p === '/api/puntia/diagnose' || p === '/api/puntia/generate-image')) {
    let usageReservation=null;
    let usageKindForRelease=null;
    let aiUser=null;
    try {
      const raw = await readBody(req, LIMIT_IMAGE + LIMIT_BODY);
      const { fields, file } = parseMultipart(raw, req.headers['content-type']);
      aiUser = requireAiAccess(req,res); if (REQUIRE_ACCOUNT_FOR_AI && !aiUser) return;
      const usageKind=p.endsWith('/diagnose')?'vision':'image'; usageKindForRelease=usageKind; const quota=await reserveUsage(aiUser,usageKind); usageReservation=quota.allowed?quota:null; if(!quota.allowed) return jsonError(res,429,`Límite mensual de ${usageKind==='vision'?'análisis visual':'imágenes'} alcanzado (${quota.limit}). Actualiza tu plan para continuar.`,'USAGE_LIMIT');

      if (p.endsWith('/diagnose')) {
        if (!file) return jsonError(res, 400, 'Falta la imagen.', 'MISSING_IMAGE');
        const dataUrl = `data:${file.type};base64,${file.data.toString('base64')}`;
        const routed = await openaiPostModelFallback('responses', {
          instructions: `${SYSTEM} Analiza la fotografía de crochet. Describe lo visible, identifica posibles errores y explica cómo corregirlos. Separa observaciones de hipótesis y expresa un nivel de confianza cuando no haya certeza visual.`,
          input: [{ role: 'user', content: [
            { type: 'input_text', text: String(fields.question || 'Analiza esta muestra y dime qué está mal y cómo corregirlo.').slice(0, 4000) },
            { type: 'input_image', image_url: dataUrl, detail: 'high' }
          ] }]
        }, runtime.visionModel || VISION_MODEL_DEFAULT, runtime.textModel || CHAT_MODEL);
        if (routed.fallback) runtime.visionModel = routed.model;
        services.costAccounting?.recordProviderUsage({model:routed.model,kind:usageKind,response:routed.data,userId:aiUser?.id||null,requestId:requestId(req),metadata:{route:'diagnose',fallback:Boolean(routed.fallback)}});
        if (usageReservation?.reservationId) await confirmUsage(aiUser,usageKind,usageReservation.reservationId);
        return send(res, 200, { analysis: outputText(routed.data) || 'No pude obtener un diagnóstico.', model: routed.model, fallback: routed.fallback });
      }

      const userPrompt = String(fields.prompt || 'Crea una referencia visual de crochet/amigurumi, limpia y didáctica.').trim();
      const prompt = `Diseño de crochet/amigurumi para PuntIA. Prioriza formas físicamente tejibles, volúmenes claros, textura de hilo visible, puntadas legibles, proporciones coherentes, iluminación de estudio suave, fondo limpio y composición centrada. Evita texto, marcas de agua, manos deformes y detalles imposibles de tejer. ${userPrompt}`;
      if (!prompt) return jsonError(res, 400, 'Describe primero la imagen.', 'MISSING_IMAGE_PROMPT');
      let imageResult;
      let providerResponse;
      try {
        if (fields.mode === 'recreate' && file) {
          const data = await services.ai.imageEdit({
            model: runtime.imageModel,
            prompt,
            size: IMAGE_SIZE,
            quality: 'high',
            outputFormat: 'png',
            image: file.data,
            filename: file.filename || 'reference.png',
            mimeType: file.type
          });
          imageResult = data?.data?.[0]?.b64_json;
          providerResponse = data;
        } else {
          const data = await openaiPost('images/generations', {
            model: runtime.imageModel,
            prompt: prompt.slice(0, 4000),
            size: IMAGE_SIZE,
            quality: 'high',
            output_format: 'png'
          });
          imageResult = data?.data?.[0]?.b64_json;
          providerResponse = data;
        }
      } catch (error) {
        throw error;
      }
      if (!imageResult) throw new Error('OpenAI no devolvió una imagen.');
      services.costAccounting?.recordProviderUsage({model:runtime.imageModel,kind:usageKind,response:providerResponse,userId:aiUser?.id||null,requestId:requestId(req),metadata:{route:'image',mode:fields.mode==='recreate'&&file?'edit':'generate'}});
      let assetKey = null;
      if (deps.objectStorage) {
        assetKey = `users/${aiUser?.id || 'guest'}/images/${crypto.randomUUID()}.png`;
        await deps.objectStorage.put(assetKey, Buffer.from(imageResult, 'base64'));
      }
      if (usageReservation?.reservationId) await confirmUsage(aiUser,usageKind,usageReservation.reservationId);
      return send(res, 200, {
        image: `data:image/png;base64,${imageResult}`,
        assetKey,
        model: runtime.imageModel,
        mode: fields.mode === 'recreate' && file ? 'edit' : 'generate'
      });
    } catch (error) {
      if (usageReservation && aiUser && usageKindForRelease) await releaseUsage(aiUser,usageKindForRelease,usageReservation?.reservationId);
      return jsonError(res, error?.status === 429 ? 429 : 502, error.message, 'IMAGE_REQUEST_FAILED');
    }
  }

  return false;
};
