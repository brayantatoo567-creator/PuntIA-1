'use strict';
module.exports = async function handleSync(ctx) {
  const { req, res, deps, services, p } = ctx;
  const { readJson, send, jsonError } = deps;
  if (!p.startsWith('/api/sync/projects')) return false;
  const user = deps.REQUIRE_ACCOUNT_FOR_PROJECTS ? deps.requireUser(req,res) : deps.currentUser(req);
  if (deps.REQUIRE_ACCOUNT_FOR_PROJECTS && !user) return true;
  try {
    const repo = deps.cloud?.projectRepo || null;
    if (req.method === 'GET' && p === '/api/sync/projects') {
      const result = await services.sync.pull({user, repo, tombstones:services.syncTombstones, cursor:ctx.url.searchParams.get('cursor') || '', limit:ctx.url.searchParams.get('limit') || 100});
      return send(res,200,{ok:true,...result});
    }
    if (req.method === 'POST' && p === '/api/sync/projects') {
      const body=await readJson(req);
      const result=await services.sync.push({user,items:body.projects || body.items || [],repo,projectService:services.projects,tombstones:services.syncTombstones});
      const conflicts=result.results.filter(x=>x.status==='conflict');
      return send(res,conflicts.length?409:200,{ok:conflicts.length===0,...result});
    }
    return false;
  } catch(error) { return jsonError(res,error.status||400,error.message,error.code||'SYNC_FAILED'); }
};
