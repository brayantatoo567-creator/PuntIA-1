// PuntIA 9.5 route controller: admin
'use strict';

module.exports = async function handleAdmin(ctx) {
  const { req, res, url, p } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE, SUBSCRIPTIONS_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey, getStripeConfig,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'GET' && p === '/api/admin/users') {
    if(!requireAdmin(req,res)) return; const users=authRepo ? await authRepo.list() : loadJsonFile(USERS_FILE,[]); return send(res,200,{ok:true,users:users.map(u=>({id:u.id,email:u.email,name:u.name,plan:publicPlan(u.plan),role:u.role==='admin'?'admin':'user',createdAt:u.createdAt,stripeCustomerId:u.stripeCustomerId||null,stripeSubscriptionId:u.stripeSubscriptionId||null}))});
  }
  if(req.method==='GET'&&p==='/api/admin/costs'){if(!requireAdmin(req,res))return;return send(res,200,{ok:true,ledger:costLedger()});}
  if(req.method==='GET'&&p==='/api/admin/audit'){if(!requireAdmin(req,res))return;const limit=Math.min(500,Math.max(1,Number(url.searchParams.get('limit')||100)));const events=await ctx.services.audit.list(limit);return send(res,200,{ok:true,events});}
  if(req.method==='GET'&&p==='/api/admin/audit/verify'){if(!requireAdmin(req,res))return;const result=await ctx.services.audit.verify();return send(res,result.ok?200:500,{ok:result.ok,audit:result});}
  if(req.method==='GET'&&p==='/api/admin/observability'){if(!requireAdmin(req,res))return;return send(res,200,{ok:true,observability:ctx.services.observability?.snapshot?.()||null});}
  if(req.method==='GET'&&p==='/api/admin/privacy/retention'){if(!requireAdmin(req,res))return;return send(res,200,{ok:true,policy:ctx.services.privacy?.retentionPolicy?.()||null});}
  if(req.method==='POST'&&p==='/api/admin/privacy/prune'){if(!requireAdmin(req,res))return;return send(res,200,{ok:true,result:ctx.services.privacy?.pruneRetention?.()||null});}

  if(req.method==='POST'&&p==='/api/admin/observability/reset'){if(!requireAdmin(req,res))return;const name=String(url.searchParams.get('provider')||'');if(!name)return send(res,400,{ok:false,error:'Falta provider.'});ctx.services.observability?.reset?.(name);return send(res,200,{ok:true,provider:name});}
  if (req.method === 'GET' && p === '/api/admin/events') {
    if(!requireAdmin(req,res)) return; let events=[]; try{events=fs.readFileSync(EVENTS_FILE,'utf8').split('\n').filter(Boolean).slice(-200).map(x=>JSON.parse(x)).reverse()}catch{} return send(res,200,{ok:true,events});
  }

  if (req.method === 'GET' && p === '/api/admin/billing/overview') {
    if(!requireAdmin(req,res)) return;
    if (ctx.deps.cloud?.billingRepo?.metrics) {
      const metrics=await ctx.deps.cloud.billingRepo.metrics();
      const list=await ctx.deps.cloud.billingRepo.listForAdmin(Math.min(200,Math.max(1,Number(url.searchParams.get('limit')||100))));
      const users=authRepo ? await authRepo.list() : loadJsonFile(USERS_FILE,[]);
      return send(res,200,{ok:true,metrics,subscriptions:list.map(x=>({...x,email:users.find(u=>String(u.id)===String(x.userId))?.email||null,name:users.find(u=>String(u.id)===String(x.userId))?.name||null}))});
    }
    const rows=Object.entries(loadJsonFile(SUBSCRIPTIONS_FILE,{})).map(([userId,v])=>({userId,...v}));
    const active=rows.filter(x=>['active','trialing','past_due'].includes(String(x.status||'')) && ['premium','pro'].includes(String(x.plan||'')));
    const users=loadJsonFile(USERS_FILE,[]);
    const metrics={premium:active.filter(x=>x.plan==='premium').length,pro:active.filter(x=>x.plan==='pro').length,pastDue:rows.filter(x=>x.status==='past_due').length,canceled:rows.filter(x=>x.status==='canceled').length};
    return send(res,200,{ok:true,metrics,subscriptions:rows.slice(-200).reverse().map(x=>({...x,email:users.find(u=>String(u.id)===String(x.userId))?.email||null,name:users.find(u=>String(u.id)===String(x.userId))?.name||null}))});
  }

  if (req.method === 'GET' && p === '/api/admin/overview') {
    if(!requireAdmin(req,res)) return;
    const users=authRepo ? await authRepo.list() : loadJsonFile(USERS_FILE,[]);
    const usage=loadJsonFile(USAGE_FILE,{}); const projects=projectStore();
    const activeUsage=Object.values(usage).reduce((a,v)=>{for(const k of Object.keys(v||{})){if(k!=='period')a[k]=(a[k]||0)+(Number(v[k])||0)}return a},{});
    let eventCount=0; try{eventCount=fs.readFileSync(EVENTS_FILE,'utf8').split('\n').filter(Boolean).length}catch{}
    const billingMetrics=ctx.deps.cloud?.billingRepo?.metrics ? await ctx.deps.cloud.billingRepo.metrics() : null;
    return send(res,200,{ok:true,version:VERSION,users:users.length,premium:billingMetrics?.premium ?? users.filter(u=>u.plan==='premium').length,pro:billingMetrics?.pro ?? users.filter(u=>u.plan==='pro').length,projects:projects.length,usage:activeUsage,eventCount,stripeConfigured:Boolean(getStripeConfig().secretKey&&getStripeConfig().prices.plus&&getStripeConfig().prices.pro)});
  }

  if (req.method === 'GET' && p === '/api/diagnostics') {
    if(!requireAdmin(req,res)) return;
    return send(res, 200, {
      ok: true,
      server: 'PuntIA',
      version: VERSION,
      node: process.version,
      host: HOST,
      port: PORT,
      aiConfigured: Boolean(runtime.apiKey),
      textModel: runtime.textModel,
      visionModel: runtime.visionModel,
      imageModel: runtime.imageModel,
      chatModel: runtime.chatModel,
      patternModel: runtime.patternModel,
      visionModel: runtime.visionModel,
      imageSize: IMAGE_SIZE,
      persisted: persisted(),
      assets: {
        mascot: fs.existsSync(path.join(PUBLIC_DIR, 'assets/mascot/puntia-mascot.svg'))
      }
    });
  }
  return false;
};
