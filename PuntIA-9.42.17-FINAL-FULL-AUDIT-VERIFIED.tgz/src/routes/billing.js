'use strict';

module.exports = async function handleBilling(ctx) {
  const { req, res, p, deps, services } = ctx;
  const {
    USERS_FILE, SUBSCRIPTIONS_FILE, STRIPE_EVENTS_FILE, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES,
    PUBLIC_URL, BILLING_GRACE_DAYS, send, jsonError, readBody, readJson, requireUser, requireAdmin,
    currentUser, publicUser, usagePayload, validatePlan, planFromStripeObject, billingEffectiveLocal, saveLocalBillingState,
    loadJsonFile, saveJsonFile, trackEvent, stripeRequest, stripeSignatureValid, requestId, safeText, getStripeConfig
  } = deps;
  const stripe=()=>typeof getStripeConfig==='function'?getStripeConfig():{secretKey:STRIPE_SECRET_KEY||'',webhookSecret:STRIPE_WEBHOOK_SECRET||'',prices:STRIPE_PRICES||{plus:'',pro:''}};

  function updateLocalUserPlan(userId, plan, billing = {}) {
    const users = loadJsonFile(USERS_FILE, []); const idx = users.findIndex(u => String(u.id) === String(userId));
    if (idx < 0) return null;
    users[idx].plan = validatePlan(plan);
    if (billing.customerId) users[idx].stripeCustomerId = billing.customerId;
    if (billing.subscriptionId) users[idx].stripeSubscriptionId = billing.subscriptionId;
    saveJsonFile(USERS_FILE, users);
    return users[idx];
  }

  async function applySubscription({ userId, status, plan='free', customerId=null, subscriptionId=null, priceId=null, currentPeriodEnd=null, cancelAtPeriodEnd=false, eventCreated=0, metadata={} } = {}) {
    if (!userId) return { plan:'free', status:'unmapped', access:false };
    const input = { userId, status, plan, customerId, subscriptionId, priceId, currentPeriodEnd, cancelAtPeriodEnd, eventCreated, metadata };
    const entitlement = deps.cloud?.billingRepo
      ? await deps.cloud.billingRepo.upsertSubscription(input)
      : saveLocalBillingState(userId, input);
    const user = deps.cloud?.authRepo
      ? await deps.cloud.authRepo.updateUser(userId, { plan: entitlement.plan })
      : updateLocalUserPlan(userId, entitlement.plan, {customerId, subscriptionId});
    await services.audit?.record({ action:'billing.entitlement.updated', resourceType:'subscription', resourceId:subscriptionId || customerId || userId, actorId:userId, correlationId:`billing:${subscriptionId || userId}`, status:'success', metadata:{ plan:entitlement.plan, status:entitlement.status, access:entitlement.access, eventCreated } });
    return { entitlement, user };
  }

  function userIdFromEvent(obj) {
    return obj?.metadata?.userId || obj?.metadata?.user_id || obj?.client_reference_id || null;
  }

  async function processWebhookEvent(event) {
    const obj = event?.data?.object || {};
    let userId = userIdFromEvent(obj);
    if (!userId && obj.customer) userId = deps.cloud?.billingRepo?.findUserIdByCustomer ? await deps.cloud.billingRepo.findUserIdByCustomer(obj.customer) : (loadJsonFile(USERS_FILE, []).find(u => u.stripeCustomerId === obj.customer)?.id || null);
    const enrichedEvent = { ...event, userId: userId || null };
    if (deps.cloud?.billingRepo && event.id && await deps.cloud.billingRepo.hasEvent(event.id)) return { received:true, idempotent:true, userId };
    if (!deps.cloud?.billingRepo) { const processed=loadJsonFile(STRIPE_EVENTS_FILE,{}); if(event.id && processed[event.id]) return {received:true,idempotent:true,userId}; }

    const type=String(event.type||'');
    if (type === 'checkout.session.completed') {
      const plan = validatePlan(obj.metadata?.plan || 'premium');
      if (userId) { services.funnel?.event('checkout_completed',userId,{plan,eventType:type}); await applySubscription({ userId, status:'incomplete', plan, customerId:obj.customer, subscriptionId:obj.subscription, eventCreated:event.created, metadata:obj.metadata || {} }); }
    } else if (type === 'customer.subscription.created' || type === 'customer.subscription.updated' || type === 'customer.subscription.deleted' || type === 'customer.subscription.paused' || type === 'customer.subscription.resumed') {
      const status = type === 'customer.subscription.deleted' ? 'canceled' : String(obj.status || (type.endsWith('paused') ? 'paused' : 'active'));
      const plan = planFromStripeObject(obj);
      if (userId) await applySubscription({ userId, status, plan, customerId:obj.customer, subscriptionId:obj.id, priceId:obj.items?.data?.[0]?.price?.id, currentPeriodEnd:obj.current_period_end, cancelAtPeriodEnd:obj.cancel_at_period_end, eventCreated:event.created, metadata:obj.metadata || {} });
    } else if (type === 'invoice.paid') {
      if (userId) {
        const existing = deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(userId) : billingEffectiveLocal(userId);
        if (existing.status === 'active' || existing.status === 'trialing') {
          await applySubscription({ userId, status:existing.status, plan:existing.plan, customerId:obj.customer, subscriptionId:obj.subscription, eventCreated:event.created, metadata:{ source:'invoice.paid' } });
        }
      }
    } else if (type === 'invoice.payment_failed') {
      if (userId) {
        const existing = deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(userId) : billingEffectiveLocal(userId);
        await applySubscription({ userId, status:'past_due', plan:existing.plan, customerId:obj.customer, subscriptionId:obj.subscription || existing.subscriptionId, eventCreated:event.created, currentPeriodEnd:existing.currentPeriodEnd ? Math.floor(Date.parse(existing.currentPeriodEnd)/1000) : null, metadata:{ source:'invoice.payment_failed' } });
      }
    } else if (type === 'entitlements.active_entitlement_summary.updated') {
      // Stripe entitlements are advisory here; PuntIA's server-side plan remains authoritative.
      await services.audit?.record({ action:'billing.stripe.entitlements.received', resourceType:'subscription', resourceId:obj.customer || null, actorId:userId, status:'success', metadata:{ignoredAsAuthority:true} });
    } else if (['charge.refunded','charge.dispute.created','radar.early_fraud_warning.created'].includes(type)) {
      await services.audit?.record({ action:`billing.risk.${type}`, resourceType:'payment', resourceId:obj.id || null, actorId:userId, status:'warning', metadata:{ customer:obj.customer || null } });
    }
    if (deps.cloud?.billingRepo && event.id) await deps.cloud.billingRepo.recordEvent(enrichedEvent);
    else if (event.id) { const processed=loadJsonFile(STRIPE_EVENTS_FILE,{}); processed[event.id]={at:new Date().toISOString(),type:event.type,userId:userId||null}; const ids=Object.keys(processed); for(const k of ids.slice(0,Math.max(0,ids.length-5000))) delete processed[k]; saveJsonFile(STRIPE_EVENTS_FILE,processed); }
    return { received:true, id:event.id || null, userId };
  }

  if (req.method === 'GET' && p === '/api/usage') {
    const user=currentUser(req); return send(res,200,{ok:true,user:publicUser(user),usage:deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usagePayload(user),subscription:user?.id?(deps.cloud?.billingRepo?await deps.cloud.billingRepo.entitlement(user.id):billingEffectiveLocal(user.id)):null});
  }

  if (req.method === 'GET' && p === '/api/marketing/plans') {
    return send(res,200,{ok:true,currency:'MXN',plans:Object.values(services.billing.plans()).map(p=>({id:p.id,name:p.label,price:p.price,interval:p.interval,features:p.features}))});
  }

  if (req.method === 'GET' && p === '/api/billing/status') {
    const user=requireUser(req,res); if(!user)return true;
    const entitlement=deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(user.id) : billingEffectiveLocal(user.id);
    const usage=deps.cloudUsageSnapshot ? await deps.cloudUsageSnapshot(user) : usagePayload(user);
    return send(res,200,{ok:true,subscription:entitlement,plan:entitlement.plan,usage});
  }

  if (req.method === 'GET' && p === '/api/billing/plans') {
    return send(res,200,{ok:true,plans:services.billing.plans()});
  }

  if (req.method === 'GET' && p === '/api/billing/invoices') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const entitlement=deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(user.id) : billingEffectiveLocal(user.id);
      if(!entitlement.customerId) return send(res,200,{ok:true,invoices:[]});
      if(!stripe().secretKey) return send(res,200,{ok:true,invoices:[],configured:false});
      const data=await stripeRequest('invoices',{customer:entitlement.customerId,limit:'20'},{method:'GET'});
      const invoices=(data.data||[]).map(inv=>({id:inv.id,status:inv.status,amount:inv.amount_paid ?? inv.amount_due ?? 0,currency:inv.currency,created:inv.created,periodStart:inv.period_start,periodEnd:inv.period_end,hostedInvoiceUrl:inv.hosted_invoice_url||null,pdf:inv.invoice_pdf||null}));
      return send(res,200,{ok:true,invoices,hasMore:Boolean(data.has_more)});
    } catch(e) { return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_HISTORY_FAILED'); }
  }

  if (req.method === 'POST' && p === '/api/billing/cancel') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const entitlement=deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(user.id) : billingEffectiveLocal(user.id);
      if(!entitlement.subscriptionId) return jsonError(res,409,'No existe una suscripción activa.','SUBSCRIPTION_REQUIRED');
      if(!stripe().secretKey) return jsonError(res,501,'Stripe no está configurado.','BILLING_NOT_CONFIGURED');
      const sub=await stripeRequest(`subscriptions/${encodeURIComponent(entitlement.subscriptionId)}`,{cancel_at_period_end:'true'},{idempotencyKey:safeText(req.headers['idempotency-key']||requestId(req),255)});
      return send(res,200,{ok:true,cancelAtPeriodEnd:Boolean(sub.cancel_at_period_end),currentPeriodEnd:sub.current_period_end});
    } catch(e){return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_CANCEL_FAILED');}
  }

  if (req.method === 'POST' && p === '/api/billing/resume') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const entitlement=deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(user.id) : billingEffectiveLocal(user.id);
      if(!entitlement.subscriptionId) return jsonError(res,409,'No existe una suscripción activa.','SUBSCRIPTION_REQUIRED');
      if(!stripe().secretKey) return jsonError(res,501,'Stripe no está configurado.','BILLING_NOT_CONFIGURED');
      const sub=await stripeRequest(`subscriptions/${encodeURIComponent(entitlement.subscriptionId)}`,{cancel_at_period_end:'false'},{idempotencyKey:safeText(req.headers['idempotency-key']||requestId(req),255)});
      return send(res,200,{ok:true,cancelAtPeriodEnd:Boolean(sub.cancel_at_period_end),currentPeriodEnd:sub.current_period_end});
    } catch(e){return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_RESUME_FAILED');}
  }

  if (req.method === 'POST' && p === '/api/billing/change-plan') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const body=await readJson(req); const plan=validatePlan(body.plan); if(plan==='free') return jsonError(res,400,'Para pasar a Free utiliza cancelar al final del periodo.','INVALID_PLAN');
      const entitlement=deps.cloud?.billingRepo ? await deps.cloud.billingRepo.entitlement(user.id) : billingEffectiveLocal(user.id);
      if(!entitlement.subscriptionId) return jsonError(res,409,'No existe una suscripción activa.','SUBSCRIPTION_REQUIRED');
      const price=plan==='premium'?stripe().prices.plus:stripe().prices.pro; if(!stripe().secretKey||!price) return jsonError(res,501,'Stripe no está configurado.','BILLING_NOT_CONFIGURED');
      const sub=await stripeRequest(`subscriptions/${encodeURIComponent(entitlement.subscriptionId)}`,{'items[0][price]':price,proration_behavior:'create_prorations',cancel_at_period_end:'false'},{idempotencyKey:safeText(req.headers['idempotency-key']||requestId(req),255)});
      return send(res,200,{ok:true,plan,subscriptionId:sub.id,status:sub.status,cancelAtPeriodEnd:Boolean(sub.cancel_at_period_end)});
    } catch(e){return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_CHANGE_PLAN_FAILED');}
  }

  if (req.method === 'POST' && p === '/api/billing/checkout') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const body=await readJson(req); const plan=validatePlan(body.plan);
      if(plan==='free') return jsonError(res,400,'Elige un plan de pago.','INVALID_PLAN');
      const current=deps.cloud?.billingRepo?await deps.cloud.billingRepo.entitlement(user.id):billingEffectiveLocal(user.id);
      if(current.access && ['active','trialing','past_due'].includes(current.status)) return jsonError(res,409,'Ya existe una suscripción de pago activa o en recuperación. Administra el plan desde el portal de facturación.','ACTIVE_SUBSCRIPTION');
      const price=plan==='premium'?stripe().prices.plus:stripe().prices.pro;
      if(!stripe().secretKey||!price) return jsonError(res,501,'Stripe aún no está configurado. Define STRIPE_SECRET_KEY y los precios de los planes.','BILLING_NOT_CONFIGURED');
      const idem=safeText(req.headers['idempotency-key'] || body.idempotencyKey || requestId(req),255);
      if(idem.length<8) return jsonError(res,400,'Idempotency-Key inválida.','INVALID_IDEMPOTENCY_KEY');
      const session=await stripeRequest('checkout/sessions',{
        mode:'subscription','line_items[0][price]':price,'line_items[0][quantity]':'1',
        success_url:`${PUBLIC_URL}/?billing=success`,cancel_url:`${PUBLIC_URL}/?billing=cancel`,
        client_reference_id:user.id, ...(user.stripeCustomerId?{customer:user.stripeCustomerId}:{customer_email:user.email}), 'metadata[userId]':user.id,'metadata[plan]':plan
      },{idempotencyKey:idem});
      services.funnel?.event('checkout_started',user.id,{plan});
      await services.audit?.record({action:'billing.checkout.created',resourceType:'checkout',resourceId:session.id,actorId:user.id,status:'success',metadata:{plan}});
      return send(res,200,{ok:true,url:session.url,sessionId:session.id,plan});
    } catch(e){return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_CHECKOUT_FAILED');}
  }

  if (req.method === 'POST' && p === '/api/billing/portal') {
    try {
      const user=requireUser(req,res); if(!user)return true;
      const entitlement=deps.cloud?.billingRepo?await deps.cloud.billingRepo.entitlement(user.id):billingEffectiveLocal(user.id);
      if(!entitlement.customerId) return jsonError(res,409,'No existe un cliente de Stripe asociado.','STRIPE_CUSTOMER_REQUIRED');
      if(!stripe().secretKey) return jsonError(res,501,'Stripe no está configurado.','BILLING_NOT_CONFIGURED');
      const portal=await stripeRequest('billing_portal/sessions',{customer:entitlement.customerId,return_url:PUBLIC_URL},{idempotencyKey:safeText(req.headers['idempotency-key']||requestId(req),255)});
      return send(res,200,{ok:true,url:portal.url});
    }catch(e){return jsonError(res,e.status===429?429:502,e.message,e.code||'BILLING_PORTAL_FAILED');}
  }

  if (req.method === 'POST' && p === '/api/billing/webhook') {
    try {
      const raw=(await readBody(req,Math.min(deps.LIMIT_BODY,1024*1024))).toString('utf8');
      if(!stripe().webhookSecret||!stripeSignatureValid(raw,req.headers['stripe-signature'])) return jsonError(res,400,'Webhook inválido.','INVALID_WEBHOOK');
      let event; try { event=JSON.parse(raw); } catch { return jsonError(res,400,'Webhook JSON inválido.','INVALID_WEBHOOK_JSON'); }
      const result=await processWebhookEvent(event);
      return send(res,200,result);
    }catch(e){return jsonError(res,400,e.message,'WEBHOOK_FAILED');}
  }
  return false;
};
