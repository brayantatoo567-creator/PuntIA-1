// PuntIA 9.5 route controller: health
'use strict';

module.exports = async function handleHealth(ctx) {
  const { req, res, url, p } = ctx;
  const {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, JOB_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    cloud, normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost,
    estimateCost, createJob, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage,
    openaiRequest, openaiGet, openaiPost, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  } = ctx.deps;
  if (req.method === 'GET' && p === '/api/live') {
    return send(res, 200, { ok: true, status: 'live', uptime: process.uptime(), version: VERSION });
  }
  if (req.method === 'GET' && p === '/api/ready') {
    const cloudHealth = cloud?.health ? await cloud.health() : { ok: true, database: true, redis: true };
    const ready = cloudHealth.ok;
    return send(res, ready ? 200 : 503, { ok: ready, status: ready ? 'ready' : 'not_ready', version: VERSION, cloud: Boolean(cloud), checks: cloudHealth });
  }
  if (req.method === 'GET' && p === '/api/health') {
    const observability = ctx.services?.observability?.health ? ctx.services.observability.health() : { ok: true };
    const cloudHealth = cloud?.health ? await cloud.health() : { ok: true };
    const ready = Boolean(cloudHealth.ok);
    return send(res, ready && observability.ok ? 200 : 503, {
      ok: ready && observability.ok,
      status: ready && observability.ok ? 'healthy' : 'degraded',
      uptime: process.uptime(),
      version: VERSION,
      ready,
      observability: { ok: Boolean(observability.ok), openCircuits: Number(observability.openCircuits || 0) }
    });
  }
  return false;
};
