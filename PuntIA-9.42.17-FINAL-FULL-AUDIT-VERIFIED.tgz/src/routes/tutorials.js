'use strict';

module.exports = async function handleTutorials(ctx) {
  const { req, res, p, services, deps } = ctx;
  if (req.method !== 'POST' || p !== '/api/puntia/tutorial') return false;
  try {
    const body = await deps.readJson(req);
    const tutorial = services.tutorials.create(body.pattern || body, { level: body.level });
    return deps.send(res, 200, { ok: true, tutorial });
  } catch (error) {
    return deps.jsonError(res, error.status || 422, error.message, error.code || 'TUTORIAL_CREATE_FAILED');
  }
};
