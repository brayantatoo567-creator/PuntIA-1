'use strict';
const { FUNNEL_EVENTS } = require('../application/funnel-service');
module.exports = async function handleFunnel(ctx) {
  const { req, res, p } = ctx;
  const { currentUser, requireUser, requireAdmin, readJson, send, jsonError, safeText } = ctx.deps;
  if (req.method === 'GET' && p === '/api/onboarding/status') {
    const user = currentUser(req);
    if (!user) return send(res, 200, { ok:true, authenticated:false, state:null });
    return send(res, 200, { ok:true, authenticated:true, state:ctx.services.funnel.userState(user.id) });
  }
  if (req.method === 'POST' && p === '/api/onboarding/event') {
    try {
      const user = requireUser(req,res); if(!user) return true;
      const body = await readJson(req);
      const name = safeText(body.name,80);
      if (!FUNNEL_EVENTS.includes(name)) return jsonError(res,400,'Evento de onboarding no permitido.','INVALID_FUNNEL_EVENT');
      ctx.services.funnel.event(name,user.id,{source:safeText(body.source,60),step:safeText(body.step,60)});
      return send(res,204,'');
    } catch(e) { return jsonError(res,e.status||400,e.message,e.code||'ONBOARDING_FAILED'); }
  }
  if (req.method === 'GET' && p === '/api/admin/funnel') {
    const admin = requireAdmin(req,res); if(!admin) return true;
    return send(res,200,{ok:true,...ctx.services.funnel.overview()});
  }
  return false;
};
