'use strict';
const routes = [
  require('./health'), require('./auth'), require('./billing'), require('./analytics'), require('./funnel'), require('./feedback'),
  require('./admin'), require('./config'), require('./sync'), require('./projects'), require('./tutorials'), require('./ai')
];
module.exports = async function route(ctx) {
  for (const handle of routes) if (await handle(ctx)) return true;
  return false;
};
