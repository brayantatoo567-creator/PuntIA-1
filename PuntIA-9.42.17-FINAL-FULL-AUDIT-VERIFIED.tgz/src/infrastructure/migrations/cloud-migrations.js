'use strict';

/**
 * Migrations idempotentes para el runtime cloud. Se ejecutan antes de abrir
 * los adaptadores de aplicación para que el arranque sea determinista.
 */
const MIGRATIONS = [
  {
    id: '007-auth-identity',
    sql: [
      `CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, name TEXT NOT NULL DEFAULT '', password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, auth_version INTEGER NOT NULL DEFAULT 1, plan TEXT NOT NULL DEFAULT 'free', role TEXT NOT NULL DEFAULT 'user', created_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
      `CREATE INDEX IF NOT EXISTS users_created_idx ON users(created_at ASC)`,
      `CREATE TABLE IF NOT EXISTS auth_sessions (token_hash TEXT PRIMARY KEY, session_id TEXT NOT NULL UNIQUE, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, auth_version INTEGER NOT NULL, csrf TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL, last_seen_at TIMESTAMPTZ NOT NULL, expires_at TIMESTAMPTZ NOT NULL, user_agent TEXT NOT NULL DEFAULT '')`,
      `CREATE INDEX IF NOT EXISTS auth_sessions_user_idx ON auth_sessions(user_id, created_at DESC)`,
      `CREATE INDEX IF NOT EXISTS auth_sessions_expiry_idx ON auth_sessions(expires_at)`,
      `CREATE TABLE IF NOT EXISTS auth_reset_tokens (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at TIMESTAMPTZ NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
      `CREATE INDEX IF NOT EXISTS auth_reset_expiry_idx ON auth_reset_tokens(expires_at)`
    ]
  },
  {
    id: '001-cloud-core',
    sql: [
      `CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'idea', progress INTEGER NOT NULL DEFAULT 0, pattern JSONB, image_url TEXT, data JSONB NOT NULL DEFAULT '{}'::jsonb, version INTEGER NOT NULL DEFAULT 1, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
      `CREATE INDEX IF NOT EXISTS projects_user_updated_idx ON projects(user_id, updated_at DESC)`,
      `CREATE TABLE IF NOT EXISTS project_versions (project_id TEXT NOT NULL, version INTEGER NOT NULL, snapshot JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(project_id, version))`,
      `CREATE TABLE IF NOT EXISTS usage_monthly (user_id TEXT NOT NULL, month DATE NOT NULL, pattern INTEGER NOT NULL DEFAULT 0, chat INTEGER NOT NULL DEFAULT 0, image INTEGER NOT NULL DEFAULT 0, vision INTEGER NOT NULL DEFAULT 0, pdf INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id, month))`,
      `CREATE TABLE IF NOT EXISTS usage_reservations (reservation_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, kind TEXT NOT NULL, month DATE NOT NULL, state TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), confirmed_at TIMESTAMPTZ, released_at TIMESTAMPTZ)`,
      `CREATE INDEX IF NOT EXISTS usage_reservations_user_idx ON usage_reservations(user_id, month)`,
      `CREATE TABLE IF NOT EXISTS puntia_jobs (id TEXT PRIMARY KEY, kind TEXT NOT NULL, owner_id TEXT NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, attempts INTEGER NOT NULL DEFAULT 0, max_attempts INTEGER NOT NULL DEFAULT 3, idempotency_key TEXT, payload JSONB NOT NULL DEFAULT '{}'::jsonb, result JSONB, error TEXT, error_code TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), worker_id TEXT, heartbeat_at TIMESTAMPTZ, lease_until TIMESTAMPTZ, UNIQUE(owner_id,kind,idempotency_key))`,
      `CREATE INDEX IF NOT EXISTS puntia_jobs_status_lease_idx ON puntia_jobs(status, lease_until)`,
      `CREATE TABLE IF NOT EXISTS audit_events (event_id TEXT PRIMARY KEY, occurred_at TIMESTAMPTZ NOT NULL, action TEXT NOT NULL, resource_type TEXT NOT NULL, resource_id TEXT, actor_id TEXT, correlation_id TEXT, status TEXT NOT NULL, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, previous_hash TEXT NOT NULL DEFAULT '', hash TEXT NOT NULL)`,
      `CREATE INDEX IF NOT EXISTS audit_events_occurred_idx ON audit_events(occurred_at DESC, event_id DESC)`
    ]
  },
  {
    id: '003-billing-subscriptions',
    sql: [
      `CREATE TABLE IF NOT EXISTS billing_subscriptions (user_id TEXT PRIMARY KEY, plan TEXT NOT NULL DEFAULT 'free', status TEXT NOT NULL DEFAULT 'none', stripe_customer_id TEXT, stripe_subscription_id TEXT UNIQUE, price_id TEXT, current_period_end TIMESTAMPTZ, cancel_at_period_end BOOLEAN NOT NULL DEFAULT false, grace_until TIMESTAMPTZ, last_event_created BIGINT NOT NULL DEFAULT 0, metadata JSONB NOT NULL DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
      `CREATE INDEX IF NOT EXISTS billing_subscriptions_customer_idx ON billing_subscriptions(stripe_customer_id)`,
      `CREATE INDEX IF NOT EXISTS billing_subscriptions_status_idx ON billing_subscriptions(status, grace_until)`,
      `CREATE TABLE IF NOT EXISTS billing_events (event_id TEXT PRIMARY KEY, event_type TEXT NOT NULL, event_created BIGINT NOT NULL DEFAULT 0, user_id TEXT, payload JSONB NOT NULL DEFAULT '{}'::jsonb, received_at TIMESTAMPTZ NOT NULL DEFAULT now())`
    ]
  },
  {
    id: '005-project-tombstones',
    sql: [
      `CREATE TABLE IF NOT EXISTS project_tombstones (owner_id TEXT NOT NULL, id TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, deleted_at TIMESTAMPTZ NOT NULL DEFAULT now(), PRIMARY KEY(owner_id,id))`,
      `CREATE INDEX IF NOT EXISTS project_tombstones_owner_deleted_idx ON project_tombstones(owner_id, deleted_at ASC, id ASC)`
    ]
  },
  {
    id: '004-feedback-quality',
    sql: [
      `CREATE TABLE IF NOT EXISTS feedback_events (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, result_type TEXT NOT NULL, result_id TEXT NOT NULL, project_id TEXT, pattern_hash TEXT, rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5), categories JSONB NOT NULL DEFAULT '[]'::jsonb, comment TEXT NOT NULL DEFAULT '', created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(user_id,result_type,result_id))`,
      `CREATE INDEX IF NOT EXISTS feedback_events_type_rating_idx ON feedback_events(result_type,rating)`,
      `CREATE INDEX IF NOT EXISTS feedback_events_user_idx ON feedback_events(user_id,updated_at DESC)`
    ]
  },
  {
    id: '006-assistant-memory',
    sql: [
      `CREATE TABLE IF NOT EXISTS assistant_conversations (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, title TEXT NOT NULL DEFAULT '', turns JSONB NOT NULL DEFAULT '[]'::jsonb, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now())`,
      `CREATE INDEX IF NOT EXISTS assistant_conversations_user_updated_idx ON assistant_conversations(user_id, updated_at DESC)`,
      `CREATE TABLE IF NOT EXISTS assistant_patterns (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', pattern JSONB NOT NULL, pattern_hash TEXT NOT NULL, model TEXT NOT NULL DEFAULT '', project_id TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(user_id, pattern_hash))`,
      `CREATE INDEX IF NOT EXISTS assistant_patterns_user_created_idx ON assistant_patterns(user_id, created_at DESC)`
    ]
  },
  {
    id: '002-worker-leases',
    sql: [
      `ALTER TABLE puntia_jobs ADD COLUMN IF NOT EXISTS worker_id TEXT`,
      `ALTER TABLE puntia_jobs ADD COLUMN IF NOT EXISTS heartbeat_at TIMESTAMPTZ`,
      `ALTER TABLE puntia_jobs ADD COLUMN IF NOT EXISTS lease_until TIMESTAMPTZ`,
      `CREATE INDEX IF NOT EXISTS puntia_jobs_worker_lease_idx ON puntia_jobs(worker_id, lease_until)`
    ]
  }
];

async function runCloudMigrations({ databaseUrl, pool: injectedPool } = {}) {
  if (!databaseUrl && !injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool = injectedPool;
  let owned = false;
  if (!pool) {
    const pg = require('pg');
    pool = new pg.Pool({ connectionString: databaseUrl, max: 4 });
    owned = true;
  }
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations (id TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
    for (const migration of MIGRATIONS) {
      const exists = await pool.query('SELECT 1 FROM schema_migrations WHERE id=$1', [migration.id]);
      if (exists.rowCount) continue;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        for (const statement of migration.sql) await client.query(statement);
        await client.query('INSERT INTO schema_migrations(id) VALUES($1)', [migration.id]);
        await client.query('COMMIT');
      } catch (error) {
        try { await client.query('ROLLBACK'); } catch {}
        throw new Error(`Migración ${migration.id} falló: ${error.message}`);
      } finally { client.release(); }
    }
    const rows = await pool.query('SELECT id, applied_at FROM schema_migrations ORDER BY id');
    return { ok: true, applied: rows.rows.map(row => ({ id: row.id, appliedAt: row.applied_at })) };
  } finally {
    if (owned) await pool.end();
  }
}

module.exports = { MIGRATIONS, runCloudMigrations };
