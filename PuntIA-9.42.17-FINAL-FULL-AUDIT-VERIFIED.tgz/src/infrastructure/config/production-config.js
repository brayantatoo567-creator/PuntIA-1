'use strict';

function validMasterKey(value) {
  const text = String(value || '').trim();
  if (!text) return false;
  if (/^[0-9a-f]{64}$/i.test(text)) return true;
  try { return Buffer.from(text, 'base64').length === 32; } catch { return false; }
}

function validateProductionConfig(env = process.env) {
  const errors = [];
  const production = String(env.NODE_ENV || '').toLowerCase() === 'production';
  const cloud = String(env.PUNTIA_CLOUD_MODE || '').toLowerCase() === 'true';
  if (!production) return { ok: true, production: false, cloud, errors: [] };
  if (!cloud) errors.push('PUNTIA_CLOUD_MODE=true es obligatorio en producción.');
  for (const name of ['DATABASE_URL', 'REDIS_URL', 'PUNTIA_STORAGE_BUCKET']) {
    if (!String(env[name] || '').trim()) errors.push(`${name} es obligatorio.`);
  }
  const publicUrl = String(env.PUNTIA_PUBLIC_URL || '').trim();
  if (!/^https:\/\//i.test(publicUrl)) errors.push('PUNTIA_PUBLIC_URL debe usar HTTPS en producción.');
  if (!String(env.PUNTIA_ADMIN_EMAIL || '').trim()) errors.push('PUNTIA_ADMIN_EMAIL es obligatorio.');
  if (!String(env.PUNTIA_ADMIN_PASSWORD || '').trim() || String(env.PUNTIA_ADMIN_PASSWORD).length < 12) errors.push('PUNTIA_ADMIN_PASSWORD debe tener al menos 12 caracteres.');
  if (!String(env.PUNTIA_PERSISTENT_DIR || '').trim()) errors.push('PUNTIA_PERSISTENT_DIR es obligatorio en producción para conservar configuración y datos locales persistentes.');
  // The server must be able to boot before an administrator enters the OpenAI key
  // through the protected configuration UI. A master key is therefore an accepted
  // bootstrap credential and is required when OPENAI_API_KEY is not supplied.
  if (!String(env.OPENAI_API_KEY || '').trim() && !validMasterKey(env.PUNTIA_CONFIG_MASTER_KEY)) {
    errors.push('OPENAI_API_KEY o PUNTIA_CONFIG_MASTER_KEY válido es obligatorio en producción.');
  }
  if (String(env.PUNTIA_ALLOW_LOCAL_CONFIG || '').toLowerCase() === 'true') errors.push('PUNTIA_ALLOW_LOCAL_CONFIG debe estar desactivado en producción.');
  return { ok: errors.length === 0, production, cloud, errors };
}

module.exports = { validateProductionConfig, validMasterKey };
