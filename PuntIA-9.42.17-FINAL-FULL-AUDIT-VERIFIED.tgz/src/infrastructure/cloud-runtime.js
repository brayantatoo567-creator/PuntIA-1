'use strict';
const { runCloudMigrations } = require('./migrations/cloud-migrations');
let promise=null;
async function createCloudRuntime(env=process.env){
  if(String(env.PUNTIA_CLOUD_MODE||'').toLowerCase()!=='true') return null;
  if(!env.DATABASE_URL||!env.REDIS_URL||!env.PUNTIA_STORAGE_BUCKET) throw new Error('Modo cloud requiere DATABASE_URL, REDIS_URL y PUNTIA_STORAGE_BUCKET.');
  let createPostgresAuthRepository, createPostgresRepository, createPostgresUsageLedger, createRedisQueue, createS3ObjectStorage, createPostgresAuditSink, createPostgresJobRepository, createPostgresPrivacyRepository, createPostgresBillingRepository, createPostgresFeedbackRepository, createPostgresTombstoneRepository, createPostgresMemoryRepository;
  try {
    ({createPostgresAuthRepository}=require('../adapters/postgres-auth-repository'));
    ({createPostgresRepository}=require('../adapters/postgres-repository'));
    ({createPostgresUsageLedger}=require('../adapters/postgres-usage-ledger'));
    ({createRedisQueue}=require('../adapters/redis-queue'));
    ({createS3ObjectStorage}=require('../adapters/s3-object-storage'));
    ({createPostgresAuditSink}=require('../adapters/postgres-audit-sink'));
    ({createPostgresJobRepository}=require('../adapters/postgres-job-repository'));
    ({createPostgresPrivacyRepository}=require('../adapters/postgres-privacy-repository'));
    ({createPostgresBillingRepository}=require('../adapters/postgres-billing-repository'));
    ({createPostgresFeedbackRepository}=require('../adapters/postgres-feedback-repository'));
    ({createPostgresTombstoneRepository}=require('../adapters/postgres-tombstone-repository'));
    ({createPostgresMemoryRepository}=require('../adapters/postgres-memory-repository'));
  } catch (e) { throw new Error(`Dependencias cloud ausentes: ${e.message}`); }
  const common={databaseUrl:env.DATABASE_URL};
  const migration = await runCloudMigrations(common);
  const authRepo=await createPostgresAuthRepository(common);
  if(env.PUNTIA_ADMIN_EMAIL && env.PUNTIA_ADMIN_PASSWORD){
    const crypto=require('crypto');
    const hashPassword=(password)=>{const salt=crypto.randomBytes(16).toString('hex');const hash=crypto.pbkdf2Sync(String(password),salt,210000,32,'sha256').toString('hex');return {salt,hash};};
    await authRepo.ensureAdmin({email:env.PUNTIA_ADMIN_EMAIL,password:env.PUNTIA_ADMIN_PASSWORD,hashPassword});
  }
  const projectRepo=await createPostgresRepository(common);
  const jobRepo=await createPostgresJobRepository(common);
  const usageLedger=createPostgresUsageLedger(common);
  const queue=await createRedisQueue(env.REDIS_URL);
  const objectStorage=createS3ObjectStorage({bucket:env.PUNTIA_STORAGE_BUCKET,region:env.PUNTIA_STORAGE_REGION||env.AWS_REGION||'auto',endpoint:env.PUNTIA_STORAGE_ENDPOINT||env.AWS_ENDPOINT_URL||'',accessKeyId:env.PUNTIA_STORAGE_ACCESS_KEY_ID||env.AWS_ACCESS_KEY_ID,secretAccessKey:env.PUNTIA_STORAGE_SECRET_ACCESS_KEY||env.AWS_SECRET_ACCESS_KEY});
  const auditSink=await createPostgresAuditSink(common);
  const privacyRepo=await createPostgresPrivacyRepository(common);
  const billingRepo=await createPostgresBillingRepository({ ...common, graceDays: env.PUNTIA_BILLING_GRACE_DAYS || 3 });
  const feedbackRepo=await createPostgresFeedbackRepository(common);
  const tombstoneRepo=await createPostgresTombstoneRepository(common);
  const memoryRepo=await createPostgresMemoryRepository(common);
  async function health(){
    const checks = await Promise.allSettled([jobRepo.health?.() || true, queue.health?.() || true]);
    const database = checks[0].status === 'fulfilled' && checks[0].value === true;
    const redis = checks[1].status === 'fulfilled' && checks[1].value === true;
    return { ok: database && redis, database, redis, migrations: migration };
  }
  async function close(){
    const closers=[authRepo?.close?.(), auditSink?.close?.(), privacyRepo?.close?.(), billingRepo?.close?.(), feedbackRepo?.close?.(), tombstoneRepo?.close?.(), memoryRepo?.close?.(), queue?.close?.(), usageLedger?.close?.(), jobRepo?.close?.(), projectRepo?.close?.()];
    for(const close of closers){ if(close && typeof close.then==='function') await close; }
  }
  return {authRepo,projectRepo,jobRepo,privacyRepo,billingRepo,feedbackRepo,tombstoneRepo,memoryRepo,usageLedger,queue,objectStorage,auditSink,distributedLock:queue.distributedLock,mode:'cloud',migration,health,close};
}
async function getCloudRuntime(){if(!promise) promise=createCloudRuntime().catch(e=>{promise=null;throw e;});return promise;}
async function closeCloudRuntime(){ if(!promise) return; try { const runtime=await promise; await runtime?.close?.(); } finally { promise=null; } }
module.exports={getCloudRuntime,closeCloudRuntime};
