const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { validatePattern, extractFirstJsonObject } = require('../../core/pattern-engine');
const { normalizeProjectInput, assertProject } = require('../../core/contracts');
const productConfig = require('../../core/config');
const route = require('../../routes/router');
const { createApplicationServices } = require('../../application');
const { createHttpSecurity } = require('./middleware/security');
const { readBody, readJson } = require('./transport/body');
const { staticFileFor, serveStatic } = require('./transport/static-files');
const { createOpenAIClient } = require('./openai/client');
const { getCloudRuntime, closeCloudRuntime } = require('../cloud-runtime');
const { validateProductionConfig } = require('../config/production-config');
const { createFileAuditSink } = require('../../adapters/file-audit-sink');
const { createDistributedWorker } = require('../../application/distributed-worker');
const { createCostAccountingService } = require('../../application/cost-accounting-service');

const VERSION = productConfig.app.version;
const ROOT = path.resolve(__dirname, '../../..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const INDEX_FILE = path.join(ROOT, 'index.html');
const HOST = String(process.env.PUNTIA_HOST || productConfig.app.host || '127.0.0.1').trim() || '127.0.0.1';
const PORT = Number.parseInt(process.env.PORT || String(productConfig.app.port || 8080), 10) || 8080;
const MAX_BODY = Number(process.env.MAX_BODY_SIZE_BYTES || 2 * 1024 * 1024);
const MAX_IMAGE = Number(process.env.MAX_IMAGE_BYTES || 8 * 1024 * 1024);
const OPENAI_TIMEOUT_MS = Number(process.env.OPENAI_TIMEOUT_MS || 180000);
const OPENAI_RETRIES = Math.min(3, Math.max(0, Number(process.env.OPENAI_RETRIES || 2)));
const CHAT_MODEL = normalizeModel(process.env.PUNTIA_CHAT_MODEL || process.env.OPENAI_MODEL, 'gpt-6-luna');
const PATTERN_MODEL = normalizeModel(process.env.PUNTIA_PATTERN_MODEL || process.env.OPENAI_PATTERN_MODEL, 'gpt-6-sol');
const VISION_MODEL_DEFAULT = normalizeModel(process.env.PUNTIA_VISION_MODEL || process.env.OPENAI_VISION_MODEL, 'gpt-6-sol');
const IMAGE_MODEL_DEFAULT = normalizeModel(process.env.PUNTIA_IMAGE_MODEL || process.env.OPENAI_IMAGE_MODEL, 'gpt-image-2');
const IMAGE_SIZE = ['1024x1024','1024x1536','1536x1024','auto'].includes(String(process.env.PUNTIA_IMAGE_SIZE || '1536x1024')) ? String(process.env.PUNTIA_IMAGE_SIZE || '1536x1024') : '1536x1024';
const OPENAI_BASE_URL = String(process.env.OPENAI_API_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
const STRIPE_BASE_URL = String(process.env.PUNTIA_STRIPE_BASE_URL || 'https://api.stripe.com/v1').replace(/\/$/, '');
const PERSISTENT_DIR = path.resolve(String(process.env.PUNTIA_PERSISTENT_DIR || ROOT).trim() || ROOT);
const DATA_DIR = path.resolve(String(process.env.PUNTIA_DATA_DIR || path.join(PERSISTENT_DIR, '.puntia-data')).trim() || path.join(PERSISTENT_DIR, '.puntia-data'));
const CONFIG_FILE = path.join(PERSISTENT_DIR, '.puntia-config.json');
const CONFIG_KEY_FILE = path.join(PERSISTENT_DIR, '.puntia-config.key');
const STRIPE_CONFIG_FILE = path.join(PERSISTENT_DIR, '.puntia-stripe-config.json');
const PROJECTS_FILE = path.join(DATA_DIR, 'projects.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const USAGE_FILE = path.join(DATA_DIR, 'usage.json');
const EVENTS_FILE = path.join(DATA_DIR, 'events.jsonl');
const FEEDBACK_FILE = path.join(DATA_DIR, 'feedback.json');
const STRIPE_EVENTS_FILE = path.join(DATA_DIR, 'stripe-events.json');
const RESET_TOKENS_FILE = path.join(DATA_DIR, 'reset-tokens.json');
const COST_FILE = path.join(DATA_DIR, 'cost-ledger.json');
const RESERVATIONS_FILE = path.join(DATA_DIR, 'usage-reservations.json');
const SUBSCRIPTIONS_FILE = path.join(DATA_DIR, 'billing-subscriptions.json');
const JOB_FILE = path.join(DATA_DIR, 'jobs.json');
const SYNC_TOMBSTONES_FILE = path.join(DATA_DIR, 'sync-tombstones.json');
const MEMORY_FILE = path.join(DATA_DIR, 'assistant-memory.json');
const AUDIT_FILE = path.join(DATA_DIR, 'audit-events.jsonl');
const MAX_JOB_AGE_MS = 1000 * 60 * 60;
const JOB_CONCURRENCY = Math.max(1, Math.min(4, Number(process.env.PUNTIA_JOB_CONCURRENCY || 2)));
const REQUIRE_CSRF = String(process.env.PUNTIA_REQUIRE_CSRF || (process.env.NODE_ENV === 'production' ? 'true' : 'false')).toLowerCase() === 'true';
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30;
const FREE_LIMITS = { pattern: 5, chat: 40, image: 3, vision: 3, pdf: 3 };
const PREMIUM_LIMITS = { pattern: 80, chat: 800, image: 40, vision: 40, pdf: 40 };
const PRO_LIMITS = { pattern: 250, chat: 2500, image: 120, vision: 120, pdf: 120 };
const ADMIN_EMAIL = String(process.env.PUNTIA_ADMIN_EMAIL || '').trim().toLowerCase();
const ADMIN_PASSWORD = String(process.env.PUNTIA_ADMIN_PASSWORD || '');
const PUBLIC_URL = String(process.env.PUNTIA_PUBLIC_URL || `http://127.0.0.1:${PORT}`).replace(/\/$/, '');
const ALLOWED_ORIGINS = new Set(String(process.env.PUNTIA_ALLOWED_ORIGINS || '').split(',').map(x=>x.trim()).filter(Boolean));
ALLOWED_ORIGINS.add(PUBLIC_URL);
ALLOWED_ORIGINS.add(`http://127.0.0.1:${PORT}`);
ALLOWED_ORIGINS.add(`http://localhost:${PORT}`);
const STRIPE_SECRET_KEY = String(process.env.STRIPE_SECRET_KEY || '');
const STRIPE_WEBHOOK_SECRET = String(process.env.STRIPE_WEBHOOK_SECRET || '');
const STRIPE_PRICES = { plus: String(process.env.STRIPE_PRICE_PLUS || ''), pro: String(process.env.STRIPE_PRICE_PRO || '') };
const BILLING_GRACE_DAYS = Math.max(0, Math.min(30, Number(process.env.PUNTIA_BILLING_GRACE_DAYS || 3)));
const STRIPE_WEBHOOK_TOLERANCE_SEC = Math.max(30, Math.min(900, Number(process.env.STRIPE_WEBHOOK_TOLERANCE_SEC || 300)));
const BILLING_PRICE_TO_PLAN = Object.freeze({ [STRIPE_PRICES.plus]: 'premium', [STRIPE_PRICES.pro]: 'pro' });
const RATE_LIMIT_WINDOW_MS = finitePositive(Number(process.env.RATE_LIMIT_WINDOW_MS || 60_000), 60_000);
const RATE_LIMIT_MAX = Math.max(1, Math.min(10000, Number.isFinite(Number(process.env.RATE_LIMIT_MAX || 120)) ? Number(process.env.RATE_LIMIT_MAX || 120) : 120));
const MAX_RATE_BUCKETS = Math.max(100, Math.min(200000, Number.isFinite(Number(process.env.MAX_RATE_BUCKETS || 20000)) ? Number(process.env.MAX_RATE_BUCKETS || 20000) : 20000));
const MAX_URL_LENGTH = Math.min(16384, Math.max(1024, Number(process.env.PUNTIA_MAX_URL_LENGTH || 8192)));
const MAX_HEADER_BYTES = Math.min(128 * 1024, Math.max(8192, Number(process.env.PUNTIA_MAX_HEADER_BYTES || 64 * 1024)));
const PASSWORD_MIN = 12;
const REQUIRE_ORIGIN_ON_MUTATIONS = String(process.env.PUNTIA_REQUIRE_ORIGIN || (process.env.NODE_ENV === 'production' ? 'true' : 'false')).toLowerCase() === 'true';
const REQUIRE_ACCOUNT_FOR_AI = String(process.env.PUNTIA_REQUIRE_ACCOUNT_FOR_AI || (process.env.NODE_ENV === 'production' ? 'true' : 'false')).toLowerCase() === 'true';
const REQUIRE_ACCOUNT_FOR_PROJECTS = String(process.env.PUNTIA_REQUIRE_ACCOUNT_FOR_PROJECTS || (process.env.NODE_ENV === 'production' ? 'true' : 'false')).toLowerCase() === 'true';
const TRUST_PROXY = String(process.env.PUNTIA_TRUST_PROXY || 'false').toLowerCase() === 'true';
const ALLOW_LOCAL_CONFIG = String(process.env.PUNTIA_ALLOW_LOCAL_CONFIG || (process.env.NODE_ENV === 'production' ? 'false' : 'true')).toLowerCase() === 'true';
const rateBuckets = new Map();
let distributedWorkerStarted = false;
let distributedWorkerInstance = null;
let shuttingDown = false;
const MAX_PROJECTS = Number(process.env.PUNTIA_MAX_PROJECTS || 500);
const MAX_PROJECTS_TOTAL = Number(process.env.PUNTIA_MAX_PROJECTS_TOTAL || 10000);
const JOB_RECOVERY_ON_START = String(process.env.PUNTIA_JOB_RECOVERY_ON_START || 'true').toLowerCase() === 'true';
try { fs.mkdirSync(PERSISTENT_DIR, { recursive: true, mode: 0o700 }); } catch {}
try { if (fs.existsSync(PERSISTENT_DIR)) fs.chmodSync(PERSISTENT_DIR, 0o700); } catch {}
try { fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 }); } catch {}
try { if (fs.existsSync(DATA_DIR)) fs.chmodSync(DATA_DIR, 0o700); } catch {}
const localAuditSink = createFileAuditSink(AUDIT_FILE);
const SYSTEM = 'Eres PuntIA, una maestra experta en crochet y amigurumi. Responde en español claro, didáctico y preciso. Cuando enseñes una puntada, explica movimiento del gancho, hebra, bucles, tensión y conteo. No inventes abreviaturas.';

function finitePositive(n, fallback) {
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

const LIMIT_BODY = finitePositive(MAX_BODY, 2 * 1024 * 1024);
const LIMIT_IMAGE = Math.min(finitePositive(MAX_IMAGE, 8 * 1024 * 1024), LIMIT_BODY * 8);
const TIMEOUT = finitePositive(OPENAI_TIMEOUT_MS, 180000);

function normalizeModel(value, fallback) {
  const v = String(value ?? '').trim();
  return v || fallback;
}

function validKeyFormat(value) {
  if (typeof value !== 'string') return false;
  const key = value.trim();
  return key.length >= 20 && key.length <= 512 && /^sk-[A-Za-z0-9_.-]+$/.test(key);
}

function loadOrCreateConfigKey() {
  const configured = String(process.env.PUNTIA_CONFIG_MASTER_KEY || '').trim();
  if (configured) {
    const raw = /^[0-9a-f]{64}$/i.test(configured) ? Buffer.from(configured, 'hex') : Buffer.from(configured, 'base64');
    if (raw.length !== 32) throw new Error('PUNTIA_CONFIG_MASTER_KEY debe representar exactamente 32 bytes.');
    return raw;
  }
  if (fs.existsSync(CONFIG_KEY_FILE)) {
    const raw = fs.readFileSync(CONFIG_KEY_FILE);
    if (raw.length !== 32) throw new Error('La clave local de configuración está dañada.');
    return raw;
  }
  const raw = crypto.randomBytes(32);
  const fd = fs.openSync(CONFIG_KEY_FILE, 'wx', 0o600);
  try { fs.writeFileSync(fd, raw); try { fs.fsyncSync(fd); } catch {} } finally { fs.closeSync(fd); }
  try { fs.chmodSync(CONFIG_KEY_FILE, 0o600); } catch {}
  return raw;
}

function encryptSecret(value) {
  const key = loadOrCreateConfigKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(String(value), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString('base64url')}:${tag.toString('base64url')}:${ciphertext.toString('base64url')}`;
}

function decryptSecret(value) {
  const text = String(value || '');
  const parts = text.split(':');
  if (parts.length !== 4 || parts[0] !== 'v1') return '';
  try {
    const key = loadOrCreateConfigKey();
    const iv = Buffer.from(parts[1], 'base64url');
    const tag = Buffer.from(parts[2], 'base64url');
    const ciphertext = Buffer.from(parts[3], 'base64url');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
  } catch { return ''; }
}

function safeSavedConfig(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const encryptedKey = typeof raw.apiKeyEncrypted === 'string' ? decryptSecret(raw.apiKeyEncrypted) : '';
  const legacyKey = typeof raw.apiKey === 'string' ? raw.apiKey.trim() : '';
  const apiKey = validKeyFormat(encryptedKey) ? encryptedKey : (validKeyFormat(legacyKey) ? legacyKey : '');
  return {
    apiKey,
    textModel: normalizeModel(raw.textModel, 'gpt-6-luna'),
    visionModel: normalizeModel(raw.visionModel, 'gpt-6-sol'),
    imageModel: normalizeModel(raw.imageModel, 'gpt-image-2'),
    savedAt: typeof raw.savedAt === 'string' ? raw.savedAt : ''
  };
}

function loadSavedConfig() {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return {};
    const raw = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    const cfg = safeSavedConfig(raw);
    // Migrate legacy plaintext keys on first read so backward compatibility does not
    // leave a secret sitting unencrypted on disk.
    if (typeof raw.apiKey === 'string' && cfg.apiKey) {
      try { saveConfig(cfg); } catch (migrationError) { console.warn('PuntIA: no se pudo migrar la clave OpenAI heredada:', migrationError.message); }
    }
    return cfg;
  } catch (error) {
    console.warn('PuntIA: configuración guardada inválida; se ignorará:', error.message);
    return {};
  }
}

function saveConfig(config) {
  const apiKey = String(config.apiKey || '').trim();
  if (!validKeyFormat(apiKey)) throw new Error('No se puede guardar una clave con formato inválido.');
  const payload = {
    apiKeyEncrypted: encryptSecret(apiKey),
    textModel: normalizeModel(config.textModel, CHAT_MODEL),
    visionModel: normalizeModel(config.visionModel, VISION_MODEL_DEFAULT),
    imageModel: normalizeModel(config.imageModel, IMAGE_MODEL_DEFAULT),
    savedAt: new Date().toISOString()
  };
  const tmp = `${CONFIG_FILE}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  const fd = fs.openSync(tmp, 'w', 0o600);
  try {
    fs.writeFileSync(fd, JSON.stringify(payload, null, 2), 'utf8');
    try { fs.fsyncSync(fd); } catch {}
  } finally {
    fs.closeSync(fd);
  }
  try { fs.chmodSync(tmp, 0o600); } catch {}
  fs.renameSync(tmp, CONFIG_FILE);
  try { fs.chmodSync(CONFIG_FILE, 0o600); } catch {}
}

function deleteSavedConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) fs.unlinkSync(CONFIG_FILE);
  } catch (error) {
    throw new Error(`No se pudo eliminar la configuración guardada: ${error.message}`);
  }
}

function safeStripeConfig(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
  const secretKey = String(raw.secretKeyEncrypted ? decryptSecret(raw.secretKeyEncrypted) : raw.secretKey || '').trim();
  const webhookSecret = String(raw.webhookSecretEncrypted ? decryptSecret(raw.webhookSecretEncrypted) : raw.webhookSecret || '').trim();
  const plusPrice = String(raw.plusPrice || '').trim();
  const proPrice = String(raw.proPrice || '').trim();
  return { secretKey, webhookSecret, plusPrice, proPrice, savedAt: typeof raw.savedAt === 'string' ? raw.savedAt : '' };
}
function loadSavedStripeConfig() {
  try {
    if (!fs.existsSync(STRIPE_CONFIG_FILE)) return {};
    const raw = JSON.parse(fs.readFileSync(STRIPE_CONFIG_FILE,'utf8'));
    const cfg = safeStripeConfig(raw);
    if ((typeof raw.secretKey === 'string' || typeof raw.webhookSecret === 'string') && cfg.secretKey) {
      try { saveStripeConfig(cfg); } catch (migrationError) { console.warn('PuntIA: no se pudo migrar la configuración Stripe heredada:', migrationError.message); }
    }
    return cfg;
  } catch (error) { console.warn('PuntIA: configuración Stripe inválida; se ignorará:', error.message); return {}; }
}
function saveStripeConfig(config) {
  const secretKey=String(config.secretKey||'').trim(), webhookSecret=String(config.webhookSecret||'').trim();
  if (!/^sk_(test|live)_[A-Za-z0-9]+$/.test(secretKey)) throw new Error('La clave secreta de Stripe no tiene un formato válido.');
  if (webhookSecret && !/^whsec_[A-Za-z0-9]+$/.test(webhookSecret)) throw new Error('El secreto de webhook de Stripe no tiene un formato válido.');
  const payload={secretKeyEncrypted:encryptSecret(secretKey),webhookSecretEncrypted:webhookSecret?encryptSecret(webhookSecret):'',plusPrice:String(config.plusPrice||'').trim(),proPrice:String(config.proPrice||'').trim(),savedAt:new Date().toISOString()};
  const tmp=`${STRIPE_CONFIG_FILE}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`; const fd=fs.openSync(tmp,'w',0o600);
  try { fs.writeFileSync(fd,JSON.stringify(payload,null,2),'utf8'); try{fs.fsyncSync(fd)}catch{} } finally { fs.closeSync(fd); }
  try{fs.chmodSync(tmp,0o600)}catch{} fs.renameSync(tmp,STRIPE_CONFIG_FILE); try{fs.chmodSync(STRIPE_CONFIG_FILE,0o600)}catch{}
}
function deleteSavedStripeConfig() { try { if(fs.existsSync(STRIPE_CONFIG_FILE)) fs.unlinkSync(STRIPE_CONFIG_FILE); } catch(error) { throw new Error(`No se pudo eliminar la configuración de Stripe: ${error.message}`); } }
const savedStripeConfig=loadSavedStripeConfig();
const runtimeStripe={
  secretKey:String(process.env.STRIPE_SECRET_KEY||savedStripeConfig.secretKey||''),
  webhookSecret:String(process.env.STRIPE_WEBHOOK_SECRET||savedStripeConfig.webhookSecret||''),
  prices:{plus:String(process.env.STRIPE_PRICE_PLUS||savedStripeConfig.plusPrice||''),pro:String(process.env.STRIPE_PRICE_PRO||savedStripeConfig.proPrice||'')}
};
function getStripeConfig(){ return runtimeStripe; }
function stripeConfigured(){ return Boolean(runtimeStripe.secretKey && runtimeStripe.prices.plus && runtimeStripe.prices.pro); }
function stripeKeyLabel(){ return runtimeStripe.secretKey ? `${runtimeStripe.secretKey.slice(0,7)}…${runtimeStripe.secretKey.slice(-4)}` : 'sin clave'; }

const savedConfig = loadSavedConfig();
let runtime = {
  apiKey: validKeyFormat(process.env.OPENAI_API_KEY) ? process.env.OPENAI_API_KEY.trim() : savedConfig.apiKey,
  textModel: normalizeModel(process.env.OPENAI_MODEL, savedConfig.textModel || CHAT_MODEL),
  chatModel: normalizeModel(process.env.PUNTIA_CHAT_MODEL || process.env.OPENAI_MODEL, CHAT_MODEL),
  patternModel: normalizeModel(process.env.PUNTIA_PATTERN_MODEL || process.env.OPENAI_PATTERN_MODEL, PATTERN_MODEL),
  visionModel: normalizeModel(process.env.PUNTIA_VISION_MODEL || process.env.OPENAI_VISION_MODEL, savedConfig.visionModel || VISION_MODEL_DEFAULT),
  imageModel: normalizeModel(process.env.PUNTIA_IMAGE_MODEL || process.env.OPENAI_IMAGE_MODEL, savedConfig.imageModel || IMAGE_MODEL_DEFAULT)
};

function hasEnvironmentKey() {
  return validKeyFormat(process.env.OPENAI_API_KEY);
}

function configSource() {
  if (!runtime.apiKey) return 'none';
  if (hasEnvironmentKey() && runtime.apiKey === process.env.OPENAI_API_KEY.trim()) return 'environment';
  if (savedConfig.apiKey && runtime.apiKey === savedConfig.apiKey) return 'saved';
  return 'runtime';
}

function persisted() {
  return Boolean(savedConfig.apiKey || hasEnvironmentKey());
}

function keyLabel() {
  if (!runtime.apiKey) return 'sin clave';
  return `${runtime.apiKey.slice(0, 7)}…${runtime.apiKey.slice(-4)}`;
}

function send(res, status, data, type = 'application/json; charset=utf-8') {
  const body = type.startsWith('application/json') ? JSON.stringify(data) : data;
  res.statusCode = status;
  res.setHeader('Content-Type', type);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
  if (process.env.NODE_ENV === 'production' && /^https:\/\//i.test(PUBLIC_URL)) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.end(body);
}

function jsonError(res, status, error, code = 'REQUEST_ERROR') {
  return send(res, status, { ok: false, error: String(error), code });
}

function cors(req, res) {
  const origin = req.headers.origin;
  const allowed = !origin || ALLOWED_ORIGINS.has(origin);
  if (allowed && origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept, X-CSRF-Token, X-Request-ID');
    res.setHeader('Access-Control-Allow-Private-Network', 'true');
  }
  return allowed;
}


function safeText(value, max = 5000) { return String(value ?? '').trim().slice(0, max); }
function loadJsonFile(file, fallback) {
  try { if (!fs.existsSync(file)) return fallback; const v = JSON.parse(fs.readFileSync(file, 'utf8')); return v ?? fallback; }
  catch (error) { console.warn(`PuntIA: datos inválidos en ${path.basename(file)}; se ignorarán:`, error.message); return fallback; }
}
function saveJsonFile(file, value) {
  const tmp = `${file}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  const fd = fs.openSync(tmp, 'w', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2), 'utf8'); try { fs.fsyncSync(fd); } catch {} }
  finally { fs.closeSync(fd); }
  try { fs.chmodSync(tmp, 0o600); } catch {}
  fs.renameSync(tmp, file); try { fs.chmodSync(file, 0o600); } catch {}
}
adminBootstrap();
recoverInterruptedJobs();

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(String(password), salt, 210000, 32, 'sha256').toString('hex');
  return { salt, hash };
}
function verifyPassword(password, user) {
  if (!user?.passwordHash || !user?.passwordSalt) return false;
  const hash = crypto.pbkdf2Sync(String(password), user.passwordSalt, 210000, 32, 'sha256').toString('hex');
  const a = Buffer.from(hash, 'hex'); const b = Buffer.from(String(user.passwordHash), 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function tokenHash(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function parseCookies(req) { const out = {}; for (const part of String(req.headers.cookie || '').split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0,i).trim()] = decodeURIComponent(part.slice(i+1).trim()); } return out; }
function currentUser(req) {
  if (req && req.__puntiaUser) return req.__puntiaUser;
  const se=sessionEntry(req); if(!se) return null;
  const users=loadJsonFile(USERS_FILE,[]); const user=users.find(u=>u.id===se.entry.userId)||null;
  if(!user) return null;
  const version=Number(user.authVersion||1);
  if(Number(se.entry.authVersion||1)!==version) return null;
  return user;
}

function publicUser(user) { return user ? { id:user.id, email:user.email, name:user.name, plan:publicPlan(user.plan), role:user.role === 'admin' ? 'admin' : 'user', createdAt:user.createdAt } : null; }
function setSession(res, userId, requestMeta = {}) {
  const token = crypto.randomBytes(32).toString('base64url'); const sessions = loadJsonFile(SESSIONS_FILE, {});
  const users=loadJsonFile(USERS_FILE,[]); const user=users.find(u=>u.id===userId); const now=new Date().toISOString();
  sessions[tokenHash(token)] = { sessionId:crypto.randomUUID(), userId, authVersion:Number(user?.authVersion||1), csrf: crypto.randomBytes(24).toString('base64url'), createdAt:now, lastSeenAt:now, expiresAt:new Date(Date.now()+SESSION_TTL_MS).toISOString(), userAgent:safeText(requestMeta.userAgent,300) };

  saveJsonFile(SESSIONS_FILE, sessions);
  const secure = (process.env.NODE_ENV === 'production' || /^https:\//i.test(PUBLIC_URL)) ? '; Secure' : '';
  const requestedSameSite = String(process.env.PUNTIA_COOKIE_SAMESITE || 'Lax');
  const sameSite = ['Strict','Lax','None'].includes(requestedSameSite) ? requestedSameSite : 'Lax';
  const sameSiteSecure = sameSite === 'None' && !secure ? '; Secure' : '';
  res.setHeader('Set-Cookie', `puntia_session=${encodeURIComponent(token)}; HttpOnly; SameSite=${sameSite}; Path=/; Max-Age=${Math.floor(SESSION_TTL_MS/1000)}${secure}${sameSiteSecure}`);
}
function revokeAllSessions(userId) {
  if(!userId) return 0;
  const users=loadJsonFile(USERS_FILE,[]); const i=users.findIndex(u=>u.id===userId);
  if(i>=0){ users[i].authVersion=Number(users[i].authVersion||1)+1; saveJsonFile(USERS_FILE,users); }
  const sessions=loadJsonFile(SESSIONS_FILE,{}); let count=0;
  for(const [k,v] of Object.entries(sessions)){ if(v?.userId===userId){ delete sessions[k]; count++; } }
  saveJsonFile(SESSIONS_FILE,sessions); return count;
}
function clearSession(req, res) { const token=parseCookies(req).puntia_session; if(token){const sessions=loadJsonFile(SESSIONS_FILE,{}); delete sessions[tokenHash(token)]; saveJsonFile(SESSIONS_FILE,sessions);} const secure = (process.env.NODE_ENV === 'production' || /^https:\/\//i.test(PUBLIC_URL)) ? '; Secure' : '';
  res.setHeader('Set-Cookie',`puntia_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure}`); }
function sessionEntry(req) {
  if (req && req.__puntiaSession) return { tokenHash: String(req.__puntiaSessionTokenHash || ''), entry:req.__puntiaSession };
  const token=parseCookies(req).puntia_session; if(!token) return null;
  const sessions=loadJsonFile(SESSIONS_FILE,{}); const entry=sessions[tokenHash(token)];
  if(!entry || Date.parse(entry.expiresAt)<=Date.now()) return null; return {tokenHash:tokenHash(token),entry};
}
function csrfToken(req){ return sessionEntry(req)?.entry?.csrf || ''; }
function requireCsrf(req,res){
  if(!REQUIRE_CSRF || !['POST','PUT','PATCH','DELETE'].includes(req.method)) return true;
  const csrfPath=new URL(req.url, 'http://127.0.0.1').pathname; if(/^\/api\/auth\/(register|login|request-reset|reset-password)$/.test(csrfPath)) return true; if(csrfPath==='/api/puntia/validate-pattern' || csrfPath==='/api/puntia/teacher/lesson') return true;
  const supplied=String(req.headers['x-csrf-token']||''); const expected=csrfToken(req);
  // CSRF protege sesiones autenticadas. Una solicitud sin sesión debe llegar a la propia ruta
  // para recibir su respuesta de autorización (401/403); no se le asigna una sesión implícita.
  if(!expected) return true;
  if(supplied.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(expected))) return jsonError(res,403,'Token CSRF inválido o ausente.','CSRF_FAILED');
  return true;
}
function cleanExpiredSessions(){ const sessions=loadJsonFile(SESSIONS_FILE,{}); let changed=false; for(const [k,v] of Object.entries(sessions)){if(!v||Date.parse(v.expiresAt)<=Date.now()){delete sessions[k];changed=true;}} if(changed)saveJsonFile(SESSIONS_FILE,sessions); }
function costLedger(){return loadJsonFile(COST_FILE,{pricingVersion:null,totalUsd:0,knownUsd:0,unknownCount:0,records:[],byModel:{},byKind:{},byUser:{}});}
function recordCostEvent(event={}){const l=costLedger();l.byModel=l.byModel&&typeof l.byModel==='object'?l.byModel:{};l.byKind=l.byKind&&typeof l.byKind==='object'?l.byKind:{};l.byUser=l.byUser&&typeof l.byUser==='object'?l.byUser:{};l.records=Array.isArray(l.records)?l.records:[];const known=Boolean(event.known&&Number.isFinite(Number(event.usd)));const usd=known?Number(event.usd):0;l.pricingVersion=event.pricingVersion||l.pricingVersion||null;l.totalUsd=Number(l.totalUsd||0)+usd;l.knownUsd=Number(l.knownUsd||0)+usd;if(!known)l.unknownCount=Number(l.unknownCount||0)+1;const model=String(event.model||'unknown');const kind=String(event.kind||'unknown');l.byModel[model]=Number(l.byModel[model]||0)+usd;l.byKind[kind]=Number(l.byKind[kind]||0)+usd;if(event.userId)l.byUser[event.userId]=Number(l.byUser[event.userId]||0)+usd;const record={id:crypto.randomUUID(),at:new Date().toISOString(),model,kind,userId:event.userId||null,requestId:event.requestId||null,known,usd:known?usd:null,reason:event.reason||null,pricingVersion:event.pricingVersion||null,usage:event.usage||null,metadata:event.metadata||{}};l.records=l.records.slice(-4999);l.records.push(record);saveJsonFile(COST_FILE,l);return record;}
function recordCost(model,kind,usd,meta={}){const n=Number(usd);if(!Number.isFinite(n)||n<0)return null;return recordCostEvent({model,kind,usd:n,known:true,...meta});}
function estimateCost(){return null;}
const costAccounting = createCostAccountingService({recordCostEvent});
function createJob(kind, ownerId, meta = {}) {
  const jobs = loadJsonFile(JOB_FILE, {});
  const idem = meta?.idempotencyKey ? String(meta.idempotencyKey) : null;
  if (idem) {
    const existing = Object.values(jobs).find(j => j && j.ownerId === ownerId && j.kind === kind && j.meta?.idempotencyKey === idem && ['queued','running','completed'].includes(j.status));
    if (existing) return existing;
  }
  const id = crypto.randomUUID();
  jobs[id] = {
    id, kind, ownerId, status: 'queued', progress: 0, attempts: 0,
    maxAttempts: Number(meta?.maxAttempts || 3), idempotencyKey: idem,
    progressMessage: 'En cola', usageReserved: Boolean(meta?.usageReserved),
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(), meta
  };
  saveJsonFile(JOB_FILE, jobs);
  return jobs[id];
}
const localJobQueue = [];
let localJobRunning = 0;
function enqueueLocalJob(job, runner, options = {}) {
  const current = getJob(job.id, job.ownerId);
  if (!current || ['completed','cancelled'].includes(current.status)) return current;
  localJobQueue.push({ job: current, runner, options });
  pumpLocalJobs();
  return current;
}
function pumpLocalJobs() {
  while (localJobRunning < JOB_CONCURRENCY && localJobQueue.length) {
    const item = localJobQueue.shift();
    const latest = getJob(item.job.id, item.job.ownerId);
    if (!latest || ['completed','cancelled'].includes(latest.status)) continue;
    localJobRunning++;
    const attempt = Number(latest.attempts || 0) + 1;
    updateJob(latest.id, { status: 'running', progress: 5, attempts: attempt, progressMessage: `Ejecutando intento ${attempt}` });
    Promise.resolve()
      .then(() => item.runner({ job: getJob(latest.id, latest.ownerId), attempt }))
      .then(result => updateJob(latest.id, { status: 'completed', progress: 100, progressMessage: 'Completado', result, usageReserved: false }))
      .catch(error => {
        const current = getJob(latest.id, latest.ownerId);
        if (!current || current.status === 'cancelled') return current;
        const max = Number(current.maxAttempts || 3);
        const retryable = new Set(['RATE_LIMIT','TIMEOUT','UPSTREAM_5XX','NETWORK']).has(String(error?.code || ''));
        if (retryable && attempt < max) {
          const delay = Math.min(30000, 500 * Math.pow(2, attempt - 1));
          updateJob(latest.id, {
            status: 'queued', progress: Math.max(5, Number(current.progress || 0)),
            progressMessage: `Reintentando en ${delay} ms`,
            lastError: String(error?.message || error), errorCode: String(error?.code || 'JOB_RETRY')
          });
          setTimeout(() => {
            localJobQueue.push({ job: getJob(latest.id, latest.ownerId), runner: item.runner, options: item.options });
            pumpLocalJobs();
          }, delay);
          return current;
        }
        if (current.usageReserved) {
          const users = loadJsonFile(USERS_FILE, []);
          const user = users.find(u => u.id === latest.ownerId);
          if (user) releaseUsage(user, latest.kind, current.meta?.reservationId);
        }
        return updateJob(latest.id, {
          status: 'failed', progress: 100, progressMessage: 'Falló',
          error: String(error?.message || error), errorCode: String(error?.code || 'JOB_FAILED'), usageReserved: false
        });
      })
      .finally(() => { localJobRunning--; pumpLocalJobs(); });
  }
}
function updateJob(id, patch) {
  const jobs = loadJsonFile(JOB_FILE, {});
  if (!jobs[id]) return null;
  const next = { ...jobs[id], ...patch, updatedAt: new Date().toISOString() };
  if (next.status === 'cancelled') { next.progress = 100; next.progressMessage = 'Cancelado'; }
  jobs[id] = next;
  saveJsonFile(JOB_FILE, jobs);
  return jobs[id];
}
function cancelJob(id, ownerId) {
  const job = getJob(id, ownerId);
  if (!job || ['completed','failed','cancelled'].includes(job.status)) return job;
  if (job.usageReserved) {
    const users = loadJsonFile(USERS_FILE, []);
    const user = users.find(u => u.id === ownerId);
    if (user) releaseUsage(user, job.kind, job.meta?.reservationId);
  }
  return updateJob(id, { status: 'cancelled', usageReserved: false, errorCode: 'JOB_CANCELLED' });
}
function findJobByIdempotency(kind, ownerId, idempotencyKey) {
  const key=String(idempotencyKey||'').trim(); if(!key) return null;
  const jobs=loadJsonFile(JOB_FILE,{});
  return Object.values(jobs).find(j => j && j.ownerId===ownerId && j.kind===kind && String(j.idempotencyKey||j.meta?.idempotencyKey||'')===key && ['queued','running','completed'].includes(j.status)) || null;
}
function getJob(id, ownerId) { const j = loadJsonFile(JOB_FILE, {})[id]; return j && j.ownerId === ownerId ? j : null; }
function pruneJobs(){const jobs=loadJsonFile(JOB_FILE,{}),cut=Date.now()-MAX_JOB_AGE_MS;let changed=false;for(const [id,j] of Object.entries(jobs)){if(Date.parse(j.updatedAt||j.createdAt||0)<cut){delete jobs[id];changed=true;}}if(changed)saveJsonFile(JOB_FILE,jobs);}
function recoverInterruptedJobs(){
  if(!JOB_RECOVERY_ON_START) return;
  const jobs=loadJsonFile(JOB_FILE,{}); let changed=false;
  for(const job of Object.values(jobs)){
    if(!job || !['queued','running'].includes(job.status)) continue;
    job.status='failed';
    job.progress=100;
    job.error='El servidor se reinició antes de completar este trabajo.';
    job.errorCode='JOB_INTERRUPTED_BY_RESTART';
    job.updatedAt=new Date().toISOString();
    changed=true;
    if(job.usageReserved){
      const users=loadJsonFile(USERS_FILE,[]);
      const user=users.find(u=>u.id===job.ownerId);
      if(user) releaseUsage(user,job.kind,job.meta?.reservationId);
      job.usageReserved=false;
    }
  }
  if(changed) saveJsonFile(JOB_FILE,jobs);
}
function usagePeriod() { const d=new Date(); return `${d.getUTCFullYear()}-${String(d.getUTCMonth()+1).padStart(2,'0')}`; }
function usageFor(userId) { const all=loadJsonFile(USAGE_FILE,{}); const key=`${userId}:${usagePeriod()}`; return all[key] || {pattern:0,chat:0,image:0,vision:0,pdf:0}; }
function checkUsage(user, kind) {
  if (!user) return {allowed:true, used:0, limit:Infinity};
  const effective = user?.id ? billingEffectiveLocal(user.id) : {plan:user?.plan||'free'};
  const limits=effective.plan==='pro'?PRO_LIMITS:effective.plan==='premium'?PREMIUM_LIMITS:FREE_LIMITS;
  const limit=limits[kind] ?? 0; const row=usageFor(user.id);
  return {allowed:(row[kind]||0) < limit, used:row[kind]||0, limit};
}
function consumeUsage(user, kind) {
  const reservation = reserveUsage(user, kind);
  return reservation.allowed ? { allowed:true, used:reservation.used, limit:reservation.limit } : reservation;
}
function reserveUsage(user, kind, reservationId = crypto.randomUUID()) {
  if(!user) return {allowed:true, used:0, limit:Infinity, reservationId:null};
  const effective = user?.id ? billingEffectiveLocal(user.id) : {plan:user?.plan||'free'}; const limits=effective.plan==='pro'?PRO_LIMITS:effective.plan==='premium'?PREMIUM_LIMITS:FREE_LIMITS; const limit=limits[kind] ?? 0;
  const all=loadJsonFile(USAGE_FILE,{}); const key=`${user.id}:${usagePeriod()}`; const row=all[key] || {pattern:0,chat:0,image:0,vision:0,pdf:0};
  const reservations=loadJsonFile(RESERVATIONS_FILE,{}); const existing=reservations[reservationId];
  if(existing) {
    if(existing.userId!==user.id || existing.kind!==kind) throw Object.assign(new Error('Reserva de uso inválida.'),{code:'USAGE_RESERVATION_MISMATCH',status:409});
    return {allowed:true,used:Number(row[kind]||0),limit,reservationId,state:existing.state};
  }
  if((row[kind]||0)>=limit) return {allowed:false, used:row[kind]||0, limit, reservationId};
  row[kind]=(row[kind]||0)+1; all[key]=row;
  reservations[reservationId]={userId:user.id,kind,period:usagePeriod(),state:'reserved',createdAt:new Date().toISOString()};
  saveJsonFile(USAGE_FILE,all); saveJsonFile(RESERVATIONS_FILE,reservations);
  return {allowed:true, used:row[kind], limit, reservationId, state:'reserved'};
}
function releaseUsage(user, kind, reservationId=null) {
  if(!user) return {ok:true};
  const reservations=loadJsonFile(RESERVATIONS_FILE,{});
  if(reservationId) {
    const r=reservations[reservationId];
    if(!r) return {ok:false,code:'USAGE_RESERVATION_NOT_FOUND'};
    if(r.userId!==user.id || r.kind!==kind) return {ok:false,code:'USAGE_RESERVATION_MISMATCH'};
    if(r.state==='released') return {ok:true,state:'released',idempotent:true};
    if(r.state==='confirmed') return {ok:false,code:'USAGE_ALREADY_CONFIRMED'};
    const all=loadJsonFile(USAGE_FILE,{}); const key=`${r.userId}:${r.period}`; const row=all[key];
    if(row) { row[kind]=Math.max(0,(Number(row[kind])||0)-1); all[key]=row; saveJsonFile(USAGE_FILE,all); }
    r.state='released'; r.releasedAt=new Date().toISOString(); reservations[reservationId]=r; saveJsonFile(RESERVATIONS_FILE,reservations);
    return {ok:true,state:'released'};
  }
  return {ok:false,code:'USAGE_RESERVATION_REQUIRED'};
}
function confirmUsage(user, kind, reservationId) {
  if(!user || !reservationId) return {ok:true,state:'confirmed'};
  const reservations=loadJsonFile(RESERVATIONS_FILE,{}); const r=reservations[reservationId];
  if(!r) return {ok:false,code:'USAGE_RESERVATION_NOT_FOUND'};
  if(r.userId!==user.id || r.kind!==kind) return {ok:false,code:'USAGE_RESERVATION_MISMATCH'};
  if(r.state==='confirmed') return {ok:true,state:'confirmed',idempotent:true};
  if(r.state==='released') return {ok:false,code:'USAGE_ALREADY_RELEASED'};
  r.state='confirmed'; r.confirmedAt=new Date().toISOString(); reservations[reservationId]=r; saveJsonFile(RESERVATIONS_FILE,reservations); return {ok:true,state:'confirmed'};
}
function requireUser(req,res) { const user=currentUser(req); if(!user){jsonError(res,401,'Inicia sesión para continuar.','AUTH_REQUIRED'); return null;} return user; }
function requireAdmin(req,res) { const user=currentUser(req); if(!isAdmin(user)){jsonError(res,403,'Acceso administrativo no autorizado.','ADMIN_REQUIRED'); return null;} return user; }
function requireAiAccess(req,res) { const user=currentUser(req); if (REQUIRE_ACCOUNT_FOR_AI && !user) { jsonError(res,401,'Crea una cuenta o inicia sesión para usar la IA.','AUTH_REQUIRED'); return null; } return user; }
function isLoopbackRequest(req) { const ip=String(req.socket.remoteAddress||''); return ip==='127.0.0.1' || ip==='::1' || ip==='::ffff:127.0.0.1'; }
function requireConfigAccess(req,res) { if (ALLOW_LOCAL_CONFIG && isLoopbackRequest(req)) return true; if (isAdmin(currentUser(req))) return true; jsonError(res,403,'La configuración de OpenAI solo puede administrarse desde el servidor local o una cuenta administradora.','CONFIG_ACCESS_DENIED'); return false; }
function usagePayload(user) { const used=usageFor(user?.id); const effective=user?.id?billingEffectiveLocal(user.id):{plan:user?.plan||'guest'}; const limits=effective.plan==='pro'?PRO_LIMITS:effective.plan==='premium'?PREMIUM_LIMITS:FREE_LIMITS; return {period:usagePeriod(), plan:effective.plan, used, limits, subscription:user?.id?effective:null}; }
function loadProjects() {
  try {
    if (!fs.existsSync(PROJECTS_FILE)) return [];
    const value = JSON.parse(fs.readFileSync(PROJECTS_FILE, 'utf8'));
    return Array.isArray(value) ? value.filter(x => x && typeof x === 'object').slice(0, MAX_PROJECTS_TOTAL) : [];
  } catch (error) { console.warn('PuntIA: proyectos inválidos; se ignorarán:', error.message); return []; }
}
function saveProjects(projects) {
  const clean = Array.isArray(projects) ? projects.filter(x => x && typeof x === 'object').slice(0, MAX_PROJECTS_TOTAL) : [];
  const tmp = `${PROJECTS_FILE}.${process.pid}.${crypto.randomBytes(6).toString('hex')}.tmp`;
  const fd = fs.openSync(tmp, 'w', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(clean, null, 2), 'utf8'); try { fs.fsyncSync(fd); } catch {} }
  finally { fs.closeSync(fd); }
  try { fs.chmodSync(tmp, 0o600); } catch {}
  fs.renameSync(tmp, PROJECTS_FILE);
  try { fs.chmodSync(PROJECTS_FILE, 0o600); } catch {}
  return clean;
}
function projectId() { return crypto.randomUUID(); }
function normalizeProject(input, existing = {}, ownerId = existing.ownerId || 'local') {
  return assertProject(normalizeProjectInput(input, existing, ownerId));
}

function projectStore() { return loadProjects(); }

function clientIp(req) {
  if (TRUST_PROXY) {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return forwarded;
  }
  return req.socket.remoteAddress || 'unknown';
}
function rateLimit(req, res) {
  const pathname = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`).pathname;
  const ip = clientIp(req);
  const family = pathname.startsWith('/api/auth/') ? '/api/auth' : pathname.startsWith('/api/admin/') ? '/api/admin' : pathname.startsWith('/api/puntia/') ? '/api/puntia' : pathname.startsWith('/api/projects') ? '/api/projects' : pathname.startsWith('/api/sync/') ? '/api/sync' : pathname.startsWith('/api/billing/') ? '/api/billing' : pathname;
  const key = `${ip}:${req.method}:${family}`;
  const now = Date.now();
  let max = RATE_LIMIT_MAX;
  if (pathname.startsWith('/api/auth/')) max = Math.min(RATE_LIMIT_MAX, 12);
  else if (pathname === '/api/billing/webhook') max = Math.min(RATE_LIMIT_MAX, 30);
  else if (pathname.startsWith('/api/admin/')) max = Math.min(RATE_LIMIT_MAX, 60);
  else if (pathname.includes('generate-pattern') || pathname.includes('generate-pattern-visual') || pathname.includes('validate-pattern-visual')) max = Math.min(RATE_LIMIT_MAX, 30);
  else if (pathname.startsWith('/api/puntia/')) max = Math.min(RATE_LIMIT_MAX, 60);
  if (!rateBuckets.has(key) && rateBuckets.size >= MAX_RATE_BUCKETS) {
    for (const [k, v] of rateBuckets) { if (now - v.startedAt >= RATE_LIMIT_WINDOW_MS) rateBuckets.delete(k); }
    while (rateBuckets.size >= MAX_RATE_BUCKETS) {
      let oldestKey = null; let oldestAt = Infinity;
      for (const [k, v] of rateBuckets) { if (v.startedAt < oldestAt) { oldestAt = v.startedAt; oldestKey = k; } }
      if (oldestKey === null) break;
      rateBuckets.delete(oldestKey);
    }
  }
  const row = rateBuckets.get(key);
  if (!row || now - row.startedAt >= RATE_LIMIT_WINDOW_MS) { rateBuckets.set(key, { startedAt: now, count: 1 }); return true; }
  row.count += 1;
  if (row.count > max) {
    const retry = Math.max(1, Math.ceil((RATE_LIMIT_WINDOW_MS - (now - row.startedAt)) / 1000));
    res.setHeader('Retry-After', String(retry));
    jsonError(res, 429, 'Demasiadas solicitudes. Intenta de nuevo en unos segundos.', 'RATE_LIMITED');
    return false;
  }
  return true;
}
function trackEvent(name, userId = null, properties = {}) {
  const event = { id: crypto.randomUUID(), name: safeText(name, 80), userId: userId || null, properties: properties && typeof properties === 'object' ? properties : {}, at: new Date().toISOString() };
  try { fs.appendFileSync(EVENTS_FILE, JSON.stringify(event) + '\n', { mode: 0o600 }); } catch (error) { console.warn('PuntIA analytics:', error.message); }
}
function validatePlan(plan) { return ['free','premium','pro'].includes(plan) ? plan : 'free'; }
function planFromStripeObject(obj = {}) {
  const metadataPlan = validatePlan(obj?.metadata?.plan);
  if (metadataPlan !== 'free') return metadataPlan;
  const priceId = obj?.items?.data?.[0]?.price?.id || obj?.price?.id || '';
  const prices=runtimeStripe.prices; return (priceId===prices.plus?'premium':priceId===prices.pro?'pro':'free');
}
function billingEffectiveLocal(userId) {
  const all=loadJsonFile(SUBSCRIPTIONS_FILE,{}); const row=all[String(userId)] || null;
  if(!row) return {plan:'free',status:'none',access:false,graceUntil:null};
  const status=String(row.status||'none');
  if(status==='active'||status==='trialing') return {plan:validatePlan(row.plan),status,access:true,graceUntil:row.graceUntil||null,subscriptionId:row.subscriptionId||null,customerId:row.customerId||null,currentPeriodEnd:row.currentPeriodEnd||null,cancelAtPeriodEnd:Boolean(row.cancelAtPeriodEnd)};
  if(status==='past_due'&&row.graceUntil&&Date.parse(row.graceUntil)>Date.now()) return {plan:validatePlan(row.plan),status,access:true,graceUntil:row.graceUntil,subscriptionId:row.subscriptionId||null,customerId:row.customerId||null,currentPeriodEnd:row.currentPeriodEnd||null,cancelAtPeriodEnd:Boolean(row.cancelAtPeriodEnd)};
  return {plan:'free',status,access:false,graceUntil:row.graceUntil||null,subscriptionId:row.subscriptionId||null,customerId:row.customerId||null,currentPeriodEnd:row.currentPeriodEnd||null,cancelAtPeriodEnd:Boolean(row.cancelAtPeriodEnd)};
}
function saveLocalBillingState(userId, input={}) {
  const all=loadJsonFile(SUBSCRIPTIONS_FILE,{}); const id=String(userId||''); if(!id) return billingEffectiveLocal(id);
  const current=all[id]||{}; const created=Number(input.eventCreated||0); if(Number(current.lastEventCreated||0)>created) return billingEffectiveLocal(id);
  const status=String(input.status||'none'); const currentPeriodEnd=input.currentPeriodEnd?new Date(Number(input.currentPeriodEnd)*1000).toISOString():(input.keepPeriodEnd?current.currentPeriodEnd:null);
  let plan=validatePlan(input.plan); let graceUntil=null;
  if(status==='past_due'){const base=currentPeriodEnd?Math.max(Date.now(),Date.parse(currentPeriodEnd)):Date.now();graceUntil=new Date(base+BILLING_GRACE_DAYS*86400000).toISOString();}
  if(['canceled','unpaid','paused','incomplete','incomplete_expired'].includes(status)) plan='free';
  all[id]={...current,plan,status,customerId:input.customerId||current.customerId||null,subscriptionId:input.subscriptionId||current.subscriptionId||null,priceId:input.priceId||current.priceId||null,currentPeriodEnd,cancelAtPeriodEnd:Boolean(input.cancelAtPeriodEnd),graceUntil,lastEventCreated:created,metadata:input.metadata||current.metadata||{},updatedAt:new Date().toISOString()};
  saveJsonFile(SUBSCRIPTIONS_FILE,all);
  return billingEffectiveLocal(id);
}
function publicPlan(plan) { return plan === 'premium' || plan === 'pro' ? plan : 'free'; }
function adminBootstrap() {
  if (!ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12) return;
  const users = loadJsonFile(USERS_FILE, []);
  const idx = users.findIndex(u => u.email === ADMIN_EMAIL);
  const hp = hashPassword(ADMIN_PASSWORD);
  if (idx < 0) {
    users.push({ id: crypto.randomUUID(), email: ADMIN_EMAIL, name: 'PuntIA Admin', passwordHash: hp.hash, passwordSalt: hp.salt, plan: 'pro', role: 'admin', createdAt: new Date().toISOString() });
  } else {
    users[idx].role = 'admin'; users[idx].plan = 'pro'; users[idx].name = users[idx].name || 'PuntIA Admin';
    if (process.env.PUNTIA_ADMIN_SYNC_PASSWORD === 'true') { users[idx].passwordHash = hp.hash; users[idx].passwordSalt = hp.salt; }
  }
  saveJsonFile(USERS_FILE, users);
}
function isAdmin(user) { return Boolean(user && user.role === 'admin'); }
function stripeForm(params) { return new URLSearchParams(params).toString(); }
async function stripeRequest(pathname, body = {}, options = {}) {
  const secretKey=String(options.secretKey||runtimeStripe.secretKey||'');
  if (!secretKey) throw Object.assign(new Error('Stripe no está configurado.'), { code: 'BILLING_NOT_CONFIGURED' });
  const method = String(options.method || 'POST').toUpperCase();
  const headers = { Authorization: `Bearer ${secretKey}`, ...(options.idempotencyKey && method !== 'GET' ? {'Idempotency-Key': String(options.idempotencyKey).slice(0,255)} : {}) };
  let url = `${STRIPE_BASE_URL}/${pathname}`;
  const params = stripeForm(body);
  const init = { method, headers };
  if (method === 'GET') { if (params) url += `?${params}`; }
  else { headers['Content-Type'] = 'application/x-www-form-urlencoded'; init.body = params; }
  const r = await fetch(url, init);
  const text = await r.text(); let data = {}; try { data = JSON.parse(text); } catch {}
  if (!r.ok) throw Object.assign(new Error(data?.error?.message || `Stripe HTTP ${r.status}`), { status: r.status });
  return data;
}
function stripeSignatureValid(raw, header) {
  if (!runtimeStripe.webhookSecret || !header) return false;
  const values = String(header).split(',').map(x=>x.trim().split('=')).reduce((acc,[k,v])=>{ if(k&&v) (acc[k] ||= []).push(v); return acc; },{});
  const timestamp = Number(values.t?.[0]);
  if (!timestamp || Math.abs(Date.now()/1000 - timestamp) > STRIPE_WEBHOOK_TOLERANCE_SEC) return false;
  const expected = crypto.createHmac('sha256', runtimeStripe.webhookSecret).update(`${timestamp}.${raw}`).digest('hex');
  return (values.v1 || []).some(signature => { try { const a=Buffer.from(expected,'hex'); const b=Buffer.from(signature,'hex'); return a.length===b.length && crypto.timingSafeEqual(a,b); } catch { return false; } });
}

function requestId(req) {
  const supplied = String(req.headers['x-request-id'] || '').trim();
  return /^[A-Za-z0-9_-]{1,80}$/.test(supplied) ? supplied : crypto.randomUUID();
}

function apiErrorMessage(data, fallback) {
  return data?.error?.message || data?.message || fallback;
}

const openaiClient = createOpenAIClient({
  getRuntime: () => runtime,
  getConfig: () => ({ OPENAI_BASE_URL, TIMEOUT, OPENAI_RETRIES, CHAT_MODEL, PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT }),
  normalizeModel,
  validKeyFormat,
});
const { openaiRequest, openaiGet, openaiPost, openaiImageEdit, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey } = openaiClient;
function validImageSignature(buffer, mime) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 12) return false;
  const type = String(mime || '').toLowerCase();
  if (type === 'image/png') return buffer.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));
  if (type === 'image/jpeg') return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  if (type === 'image/webp') return buffer.subarray(0,4).toString('ascii') === 'RIFF' && buffer.subarray(8,12).toString('ascii') === 'WEBP';
  return false;
}

function parseMultipart(buffer, contentType) {
  const match = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || '');
  if (!match) throw new Error('Multipart inválido.');
  const rawBoundary = match[1] || match[2];
  if (!rawBoundary || rawBoundary.length > 200) throw new Error('Boundary multipart inválido.');
  const boundary = Buffer.from(`--${rawBoundary}`);
  const parts = [];
  let pos = 0;

  while ((pos = buffer.indexOf(boundary, pos)) !== -1) {
    pos += boundary.length;
    if (buffer[pos] === 45 && buffer[pos + 1] === 45) break;
    if (buffer[pos] === 13 && buffer[pos + 1] === 10) pos += 2;
    const next = buffer.indexOf(boundary, pos);
    if (next < 0) break;
    const end = Math.max(pos, next - 2);
    const part = buffer.subarray(pos, end);
    const separator = part.indexOf(Buffer.from('\r\n\r\n'));
    if (separator < 0) continue;
    const headers = part.subarray(0, separator).toString('utf8');
    const body = part.subarray(separator + 4);
    const nameMatch = /name="([^"]*)"/i.exec(headers);
    const fileMatch = /filename="([^"]*)"/i.exec(headers);
    const typeMatch = /content-type:\s*([^\r\n]+)/i.exec(headers);
    parts.push({
      name: nameMatch?.[1] || '',
      filename: fileMatch?.[1] || '',
      type: typeMatch?.[1]?.trim().toLowerCase() || '',
      data: body
    });
    pos = next;
  }

  const fields = Object.create(null);
  let file = null;
  for (const part of parts) {
    if (!part.name) continue;
    if (part.filename) {
      if (part.data.length > LIMIT_IMAGE) throw new Error('Imagen demasiado grande.');
      if (!/^image\/(jpeg|png|webp)$/i.test(part.type)) throw new Error('Formato de imagen no permitido.');
      if (!validImageSignature(part.data, part.type)) throw new Error('La imagen no coincide con su formato declarado.');
      if (file) throw new Error('Solo se permite una imagen de referencia.');
      file = part;
    } else {
      fields[part.name] = part.data.toString('utf8');
    }
  }
  return { fields, file };
}

function pSafeOrigin(req) {
  const origin = String(req.headers.origin || '').trim();
  if (!origin) return true;
  return ALLOWED_ORIGINS.has(origin);
}

const httpSecurity = createHttpSecurity({
  requestId, cors, rateLimit, requireCsrf, pSafeOrigin, requireOriginOnMutations: REQUIRE_ORIGIN_ON_MUTATIONS, maxUrlLength: MAX_URL_LENGTH,
  allowedOrigins: ALLOWED_ORIGINS
});

async function handle(req, res, servicesOverride = null) {
  if (shuttingDown) return jsonError(res, 503, 'Servidor en cierre.', 'SERVER_SHUTTING_DOWN');
  if (!(await httpSecurity.before(req, res))) return;
  if (req.method === 'OPTIONS') return send(res, 204, '');
  pruneJobs(); cleanExpiredSessions();
  const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
  const p = url.pathname;
  const productionConfig = validateProductionConfig(process.env);
  if (!productionConfig.ok) {
    if (p === '/api/health' || p === '/api/live') return jsonError(res, 503, 'Configuración de producción incompleta.', 'PRODUCTION_CONFIG_INVALID', { errors: productionConfig.errors });
    return jsonError(res, 503, 'Configuración de producción incompleta.', 'PRODUCTION_CONFIG_INVALID');
  }
  let cloud = null;
  if (String(process.env.PUNTIA_CLOUD_MODE || '').toLowerCase() === 'true') {
    try { cloud = await getCloudRuntime(); }
    catch (error) {
      if (p !== '/api/health') return jsonError(res, 503, `Infraestructura cloud no disponible: ${error.message}`, 'CLOUD_NOT_READY');
    }
  }
  const deps = {
    http, fs, path, crypto, productConfig, VERSION, ROOT, PUBLIC_DIR,
    INDEX_FILE, HOST, PORT, MAX_BODY, MAX_IMAGE, OPENAI_TIMEOUT_MS, OPENAI_RETRIES, CHAT_MODEL,
    PATTERN_MODEL, VISION_MODEL_DEFAULT, IMAGE_MODEL_DEFAULT, IMAGE_SIZE, OPENAI_BASE_URL, STRIPE_BASE_URL, CONFIG_FILE, DATA_DIR, PROJECTS_FILE, SYNC_TOMBSTONES_FILE, MEMORY_FILE,
    USERS_FILE, SESSIONS_FILE, USAGE_FILE, EVENTS_FILE, FEEDBACK_FILE, STRIPE_EVENTS_FILE, RESET_TOKENS_FILE, COST_FILE, RESERVATIONS_FILE, JOB_FILE, SUBSCRIPTIONS_FILE,
    MAX_JOB_AGE_MS, JOB_CONCURRENCY, REQUIRE_CSRF, SESSION_TTL_MS, FREE_LIMITS, PREMIUM_LIMITS, PRO_LIMITS, ADMIN_EMAIL,
    ADMIN_PASSWORD, PUBLIC_URL, ALLOWED_ORIGINS, STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, STRIPE_PRICES, BILLING_GRACE_DAYS, STRIPE_WEBHOOK_TOLERANCE_SEC, BILLING_PRICE_TO_PLAN, RATE_LIMIT_WINDOW_MS, RATE_LIMIT_MAX,
    MAX_RATE_BUCKETS, PASSWORD_MIN, REQUIRE_ORIGIN_ON_MUTATIONS, REQUIRE_ACCOUNT_FOR_AI, REQUIRE_ACCOUNT_FOR_PROJECTS, TRUST_PROXY, ALLOW_LOCAL_CONFIG, rateBuckets,
    MAX_PROJECTS, MAX_PROJECTS_TOTAL, JOB_RECOVERY_ON_START, SYSTEM, finitePositive, LIMIT_BODY, LIMIT_IMAGE, TIMEOUT,
    cloud, auditSink: localAuditSink, normalizeModel, validKeyFormat, safeSavedConfig, loadSavedConfig, saveConfig, deleteSavedConfig, savedConfig, runtime, loadSavedStripeConfig, saveStripeConfig, deleteSavedStripeConfig, savedStripeConfig, getStripeConfig, stripeConfigured, stripeKeyLabel,
    hasEnvironmentKey, configSource, persisted, keyLabel, send, jsonError, cors, safeText,
    loadJsonFile, saveJsonFile, hashPassword, verifyPassword, tokenHash, parseCookies, currentUser, publicUser,
    setSession, clearSession, sessionEntry, csrfToken, requireCsrf, cleanExpiredSessions, costLedger, recordCost, recordCostEvent,
    estimateCost, costAccounting, createJob, findJobByIdempotency, localJobQueue, enqueueLocalJob, pumpLocalJobs, updateJob, getJob, pruneJobs,
    recoverInterruptedJobs, cancelJob, revokeAllSessions, usagePeriod, usageFor, checkUsage, consumeUsage, reserveUsage, releaseUsage, confirmUsage, requireUser,
    requireAdmin, requireAiAccess, isLoopbackRequest, requireConfigAccess, usagePayload, loadProjects, saveProjects, projectId,
    normalizeProject, projectStore, clientIp, rateLimit, trackEvent, validatePlan, publicPlan, adminBootstrap,
    isAdmin, stripeForm, stripeRequest, stripeSignatureValid, requestId, readBody, readJson, apiErrorMessage, planFromStripeObject, billingEffectiveLocal, saveLocalBillingState,
    openaiRequest, openaiGet, openaiPost, openaiImageEdit, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey,
    validImageSignature, parseMultipart, staticFileFor, serveStatic, pSafeOrigin, handle, validatePattern, extractFirstJsonObject
  };
  if (cloud) {
    deps.currentUser = (req) => req?.__puntiaUser || null;
    deps.requireUser = (req,res) => { const user=deps.currentUser(req); if(!user){jsonError(res,401,'Inicia sesión para continuar.','AUTH_REQUIRED'); return null;} return user; };
    deps.requireAdmin = (req,res) => { const user=deps.currentUser(req); if(!isAdmin(user)){jsonError(res,403,'Acceso administrativo no autorizado.','ADMIN_REQUIRED'); return null;} return user; };
    deps.requireAiAccess = (req,res) => { const user=deps.currentUser(req); if(REQUIRE_ACCOUNT_FOR_AI&&!user){jsonError(res,401,'Crea una cuenta o inicia sesión para usar la IA.','AUTH_REQUIRED');return null;} return user; };
    deps.authRepo = cloud.authRepo;
    deps.reserveUsage = async (user, kind) => { const entitlement = user?.id && cloud.billingRepo ? await cloud.billingRepo.entitlement(user.id) : null; const effectivePlan = entitlement?.plan || user?.plan || 'free'; const limits=effectivePlan==='pro'?PRO_LIMITS:effectivePlan==='premium'?PREMIUM_LIMITS:FREE_LIMITS; return cloud.usageLedger.reserve(user?.id || 'guest', kind, limits[kind] ?? 0); };
    deps.releaseUsage = async (user, kind, reservationId) => cloud.usageLedger.release(user?.id || 'guest', kind, reservationId);
    deps.confirmUsage = async (user, kind, reservationId) => cloud.usageLedger.confirm(reservationId);
    deps.cloudUsageSnapshot = async (user) => { const used=await cloud.usageLedger.snapshot(user?.id || 'guest'); const entitlement=user?.id&&cloud.billingRepo?await cloud.billingRepo.entitlement(user.id):null; const effectivePlan=entitlement?.plan||user?.plan||'free'; const limits=effectivePlan==='pro'?PRO_LIMITS:effectivePlan==='premium'?PREMIUM_LIMITS:FREE_LIMITS; return {period:usagePeriod(),plan:effectivePlan,used,limits,subscription:entitlement||null}; };
    deps.cloudQueue = cloud.queue;
    deps.distributedLock = cloud.distributedLock;
    deps.findJobByIdempotency = (kind, owner, key) => cloud.jobRepo.findByIdempotency(kind, owner, key);
    deps.createJob = (kind, owner, meta) => cloud.jobRepo.create(kind, owner, meta);
    deps.getJob = (id, owner) => cloud.jobRepo.get(id, owner);
    deps.updateJob = (id, patch) => cloud.jobRepo.update(id, patch.ownerId || '', patch);
    deps.cancelJob = (id, owner) => cloud.jobRepo.cancel(id, owner);
    deps.objectStorage = cloud.objectStorage;
    deps.billingRepo = cloud.billingRepo;
    deps.feedbackRepo = cloud.feedbackRepo;
    deps.syncTombstoneRepo = cloud.tombstoneRepo;
    deps.memoryRepo = cloud.memoryRepo;
    if (cloud.auditSink) deps.auditSink = cloud.auditSink;
  }
  deps.services = servicesOverride || createApplicationServices(deps);
  if (cloud && !distributedWorkerStarted) {
    distributedWorkerStarted = true;
    try {
      distributedWorkerInstance = createDistributedWorker({
        queue: cloud.queue,
        jobRepo: cloud.jobRepo,
        services: deps.services,
        resolveUser: async (ownerId, embedded) => embedded && embedded.id === ownerId ? embedded : ({ id: ownerId, plan: embedded?.plan || 'free' }),
        pollMs: Number(process.env.PUNTIA_WORKER_POLL_MS || 500),
        leaseMs: Number(process.env.PUNTIA_WORKER_LEASE_MS || 30000),
        heartbeatMs: Number(process.env.PUNTIA_WORKER_HEARTBEAT_MS || 10000)
      });
      distributedWorkerInstance.start().catch(error => { distributedWorkerStarted = false; console.error('PuntIA distributed worker stopped:', error.message); });
    } catch (error) {
      distributedWorkerStarted = false;
      console.error('PuntIA distributed worker unavailable:', error.message);
    }
  }
  if (cloud?.authRepo) {
    const token = parseCookies(req).puntia_session;
    if (token) {
      try {
        const session = await cloud.authRepo.getSession(tokenHash(token));
        if (session?.user && Number(session.authVersion || 1) === Number(session.user.authVersion || 1)) { req.__puntiaSession=session; req.__puntiaSessionTokenHash=tokenHash(token); req.__puntiaUser=session.user; }
      } catch (error) {
        if (p.startsWith('/api/auth')) console.warn(`PuntIA auth lookup failed: ${error.message}`);
      }
    }
  }
  const handled = await route({ req, res, url, p, deps, services: deps.services });
  if (handled || res.writableEnded) return;
  return serveStatic(req, res, p, { root: ROOT, publicDir: PUBLIC_DIR, indexFile: INDEX_FILE }, jsonError);
}


function createServer(overrides = {}) {
  const server = http.createServer({ maxHeaderSize: MAX_HEADER_BYTES }, (req, res) => {
    handle(req, res, overrides.services || null).catch(error => {
      console.error('PuntIA request error:', error.message);
      if (!res.headersSent) jsonError(res, 500, 'Error interno del servidor.', 'INTERNAL_ERROR');
      else res.destroy();
    });
  });

  server.on('error', error => {
    if (error.code === 'EADDRINUSE') {
      console.error(`PuntIA no pudo usar ${HOST}:${PORT}: el puerto ya está ocupado.`);
    } else {
      console.error('PuntIA server error:', error);
    }
  });

  server.requestTimeout = TIMEOUT + 15000;
  server.headersTimeout = Math.max(10000, Math.min(server.requestTimeout, TIMEOUT + 5000));
  server.keepAliveTimeout = 5000;
  server.__puntiaPort = PORT;
  server.__puntiaHost = HOST;
  server.__puntiaVersion = VERSION;
  server.__puntiaWarmup = async () => {
    if (String(process.env.PUNTIA_CLOUD_MODE || '').toLowerCase() === 'true') await getCloudRuntime();
    return true;
  };

  let shutdownPromise = null;
  async function shutdown(signal) {
    if (shutdownPromise) return shutdownPromise;
    shuttingDown = true;
    console.log(`PuntIA: cierre solicitado (${signal}).`);
    shutdownPromise = (async () => {
      try { if (distributedWorkerInstance) await distributedWorkerInstance.stop(); } catch (error) { console.error('PuntIA worker shutdown error:', error.message); }
      await new Promise(resolve => server.close(resolve));
      try { await closeCloudRuntime(); } catch (error) { console.error('PuntIA cloud shutdown error:', error.message); }
      process.exit(0);
    })();
    setTimeout(() => process.exit(1), 15000).unref();
    return shutdownPromise;
  }
  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT', () => shutdown('SIGINT'));
  return server;
}

module.exports = { createHttpRuntime: createServer };
