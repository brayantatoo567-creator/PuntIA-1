'use strict';

function createHttpSecurity({ requestId, cors, rateLimit, requireCsrf, pSafeOrigin, requireOriginOnMutations, maxUrlLength = 8192 }) {
  return {
    async before(req, res) {
      const rawUrl = String(req.url || '');
      if (rawUrl.length > maxUrlLength) {
        jsonErrorLocal(res, 414, 'URL demasiado larga.', 'URI_TOO_LONG');
        return false;
      }
      const allowedMethods = new Set(['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS']);
      if (!allowedMethods.has(String(req.method || '').toUpperCase())) {
        res.setHeader('Allow', Array.from(allowedMethods).join(', '));
        jsonErrorLocal(res, 405, 'Método HTTP no permitido.', 'METHOD_NOT_ALLOWED');
        return false;
      }
      const id = requestId(req);
      res.setHeader('X-Request-ID', id);
      if (!cors(req, res)) {
        jsonErrorLocal(res, 403, 'Origen no permitido.', 'CORS_ORIGIN_DENIED');
        return false;
      }
      if (requireOriginOnMutations && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !pSafeOrigin(req)) {
        jsonErrorLocal(res, 403, 'Origen de solicitud no permitido.', 'ORIGIN_DENIED');
        return false;
      }
      if (!rateLimit(req, res)) return false;
      if (!requireCsrf(req, res)) return false;
      return true;
    }
  };
}

function jsonErrorLocal(res, status, message, code) {
  if (res.writableEnded) return;
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify({ ok: false, error: message, code }));
}

module.exports = { createHttpSecurity };
