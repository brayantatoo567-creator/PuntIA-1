'use strict';
const fs = require('fs');
const path = require('path');

function staticFileFor(pathname, { root, publicDir, indexFile }) {
  if (pathname === '/') return indexFile;
  if (pathname === '/manifest.webmanifest') return path.join(root, 'manifest.webmanifest');
  if (pathname === '/sw.js') return path.join(root, 'sw.js');
  if (pathname === '/offline-sync.js') return path.join(publicDir, 'offline-sync.js');
  let relative = null;
  if (pathname === '/css/app.css') relative = 'app.css';
  else if (pathname === '/js/app.js') relative = 'app.js';
  else if (pathname.startsWith('/assets/')) relative = path.join('assets', pathname.slice('/assets/'.length));
  else if (pathname.startsWith('/public/assets/')) relative = pathname.slice('/public/'.length);
  if (relative === null) return null;
  const candidate = path.resolve(publicDir, relative);
  const publicRoot = path.resolve(publicDir);
  if (!candidate.startsWith(`${publicRoot}${path.sep}`)) return null;
  return candidate;
}

function serveStatic(req, res, pathname, options, jsonError) {
  const filePath = staticFileFor(pathname, options);
  if (!filePath) return jsonError(res, 404, 'Recurso no encontrado.', 'NOT_FOUND');
  let stat;
  try { stat = fs.statSync(filePath); } catch { return jsonError(res, 404, 'Recurso no encontrado.', 'NOT_FOUND'); }
  if (!stat.isFile()) return jsonError(res, 404, 'Recurso no encontrado.', 'NOT_FOUND');
  const ext = path.extname(filePath).toLowerCase();
  const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.svg':'image/svg+xml', '.webmanifest':'application/manifest+json; charset=utf-8' };
  res.statusCode = 200;
  res.setHeader('Content-Type', types[ext] || 'application/octet-stream');
  res.setHeader('Cache-Control', ext === '.html' ? 'no-store' : 'public, max-age=3600');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  fs.createReadStream(filePath).on('error', () => {
    if (!res.headersSent) jsonError(res, 500, 'No se pudo leer el recurso.', 'STATIC_ERROR');
    else res.destroy();
  }).pipe(res);
}

module.exports = { staticFileFor, serveStatic };
