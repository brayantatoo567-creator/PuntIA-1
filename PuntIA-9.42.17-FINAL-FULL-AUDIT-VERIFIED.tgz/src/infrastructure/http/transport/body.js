'use strict';

async function readBody(req, limit) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > limit) throw new Error('Payload demasiado grande.');
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > limit) throw new Error('Payload demasiado grande.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

async function readJson(req, limit) {
  const body = await readBody(req, limit);
  if (!body.length) return {};
  try { return JSON.parse(body.toString('utf8')); }
  catch { throw new Error('JSON inválido.'); }
}

module.exports = { readBody, readJson };
