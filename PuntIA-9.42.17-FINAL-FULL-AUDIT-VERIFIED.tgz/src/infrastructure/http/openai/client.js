'use strict';

function createOpenAIClient({ getRuntime, getConfig, normalizeModel, validKeyFormat }) {
  function apiErrorMessage(data, fallback) { return data?.error?.message || data?.message || fallback; }
  async function openaiRequest(method, pathname, payload, key = getRuntime().apiKey, extraHeaders = {}) {
    const { OPENAI_BASE_URL, TIMEOUT } = getConfig();
    if (!key) throw new Error('OPENAI_API_KEY no está configurada. Abre Ajustes y pulsa Validar y conectar.');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT);
    try {
      const options = { method, headers: { Authorization: `Bearer ${key}`, ...extraHeaders }, signal: controller.signal };
      if (payload !== undefined && payload !== null) { options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(payload); }
      const response = await fetch(`${OPENAI_BASE_URL}/${pathname}`, options);
      const text = await response.text();
      let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { error: { message: text || `OpenAI HTTP ${response.status}` } }; }
      if (!response.ok) { const err = new Error(apiErrorMessage(data, `OpenAI HTTP ${response.status}`)); err.status = response.status; throw err; }
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error(`OpenAI tardó más de ${Math.round(TIMEOUT / 1000)} segundos en responder.`);
      throw error;
    } finally { clearTimeout(timer); }
  }
  function openaiGet(pathname, key = getRuntime().apiKey) { return openaiRequest('GET', pathname, undefined, key, { Accept: 'application/json' }); }
  async function openaiPost(pathname, payload, key = getRuntime().apiKey) {
    const { OPENAI_RETRIES } = getConfig(); let lastError;
    for (let attempt=0; attempt<=OPENAI_RETRIES; attempt++) {
      try { return await openaiRequest('POST', pathname, payload, key); }
      catch (error) {
        lastError=error;
        const retryable = error?.status===408 || error?.status===409 || error?.status===429 || (error?.status>=500);
        if (!retryable || attempt===OPENAI_RETRIES) break;
        await new Promise(r=>setTimeout(r, Math.min(4000, 300*Math.pow(2,attempt))));
      }
    }
    throw lastError;
  }
  function outputText(data) { return data?.output_text || (Array.isArray(data?.output) ? data.output.flatMap(x=>x?.content||[]).filter(x=>x?.type==='output_text').map(x=>x.text||'').join('') : ''); }
  function apiTestPayload(model) { return { model, input: [{ role:'user', content:[{ type:'input_text', text:'Responde exactamente PUNTIA_API_OK' }] }], max_output_tokens:16 }; }
  function modelAvailable(models, model) { return models.some(x=>x?.id===model); }
  async function verifyOpenAIKey(candidate) {
    if (!validKeyFormat(candidate.apiKey)) throw new Error('La clave de OpenAI no tiene un formato válido.');
    const models = await openaiGet('models', candidate.apiKey);
    const ids = Array.isArray(models?.data) ? models.data : [];
    if (!modelAvailable(ids, candidate.textModel)) throw new Error(`El modelo “${candidate.textModel}” no aparece disponible para esta clave.`);
    const test = await openaiPost('responses', apiTestPayload(candidate.textModel), candidate.apiKey);
    const reply = outputText(test).trim();
    if (reply !== 'PUNTIA_API_OK') throw new Error(`OpenAI respondió, pero la prueba determinística no coincidió (respuesta: ${reply.slice(0,120)||'vacía'}).`);
    return { reply };
  }
  async function openaiImageEdit({ model, prompt, size='1024x1024', quality='high', outputFormat='png', image, filename='reference.png', mimeType='image/png' }) {
    const { OPENAI_BASE_URL, TIMEOUT } = getConfig();
    if (!getRuntime().apiKey) throw new Error('OPENAI_API_KEY no está configurada.');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT);
    try {
      const form = new FormData();
      form.append('model', model);
      form.append('prompt', String(prompt || '').slice(0, 4000));
      form.append('size', size);
      form.append('quality', quality);
      form.append('output_format', outputFormat);
      form.append('image', new Blob([image], { type: mimeType }), filename);
      const response = await fetch(`${OPENAI_BASE_URL}/images/edits`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${getRuntime().apiKey}` },
        body: form,
        signal: controller.signal
      });
      const text = await response.text();
      let data; try { data = text ? JSON.parse(text) : {}; } catch { data = { error: { message: text } }; }
      if (!response.ok) { const error = new Error(apiErrorMessage(data, `OpenAI HTTP ${response.status}`)); error.status = response.status; throw error; }
      return data;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error(`OpenAI tardó más de ${Math.round(TIMEOUT / 1000)} segundos en editar la imagen.`);
      throw error;
    } finally { clearTimeout(timer); }
  }

  async function openaiPostModelFallback(pathname, payload, primary, fallback) {
    try { return { data: await openaiPost(pathname, { ...payload, model: primary }), model: primary, fallback: false }; }
    catch (error) { if (!fallback || fallback===primary) throw error; return { data: await openaiPost(pathname, { ...payload, model: fallback }), model: fallback, fallback: true }; }
  }
  return { openaiRequest, openaiGet, openaiPost, openaiImageEdit, openaiPostModelFallback, modelAvailable, outputText, apiTestPayload, verifyOpenAIKey };
}
module.exports = { createOpenAIClient };
