'use strict';

function safeOwner(ownerId){const v=String(ownerId||'').trim();if(!v)throw new Error('ownerId requerido');return v;}
async function createPostgresTombstoneRepository({databaseUrl,pool:injectedPool}={}){
  if(!databaseUrl&&!injectedPool)throw new Error('DATABASE_URL no configurada');
  let pool=injectedPool;let owned=false;
  if(!pool){const pg=require('pg');pool=new pg.Pool({connectionString:databaseUrl,max:5});owned=true;}
  return {
    async list(ownerId){const r=await pool.query('SELECT owner_id,id,version,deleted_at FROM project_tombstones WHERE owner_id=$1 ORDER BY deleted_at ASC,id ASC',[safeOwner(ownerId)]);return r.rows.map(x=>({ownerId:x.owner_id,id:x.id,version:Number(x.version),deletedAt:x.deleted_at}));},
    async get(ownerId,id){const r=await pool.query('SELECT owner_id,id,version,deleted_at FROM project_tombstones WHERE owner_id=$1 AND id=$2',[safeOwner(ownerId),String(id)]);const x=r.rows[0];return x?{ownerId:x.owner_id,id:x.id,version:Number(x.version),deletedAt:x.deleted_at}:null;},
    async put(ownerId,id,version,deletedAt=new Date().toISOString()){const owner=safeOwner(ownerId);const vid=Number(version||1);const r=await pool.query(`INSERT INTO project_tombstones(owner_id,id,version,deleted_at) VALUES($1,$2,$3,$4) ON CONFLICT(owner_id,id) DO UPDATE SET version=GREATEST(project_tombstones.version,EXCLUDED.version),deleted_at=CASE WHEN EXCLUDED.version>=project_tombstones.version THEN EXCLUDED.deleted_at ELSE project_tombstones.deleted_at END RETURNING owner_id,id,version,deleted_at`,[owner,String(id),vid,String(deletedAt)]);const x=r.rows[0];return{ownerId:x.owner_id,id:x.id,version:Number(x.version),deletedAt:x.deleted_at};},
    async remove(ownerId,id){await pool.query('DELETE FROM project_tombstones WHERE owner_id=$1 AND id=$2',[safeOwner(ownerId),String(id)]);return true;},
    async close(){if(owned)await pool.end();}
  };
}
module.exports={createPostgresTombstoneRepository};
