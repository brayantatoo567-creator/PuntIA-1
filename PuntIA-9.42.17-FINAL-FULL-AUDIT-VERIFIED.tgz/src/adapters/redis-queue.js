'use strict';
/** Redis queue adapter. Requires `ioredis` in the deployment image. */
const { assertQueueResult }=require('../core/contracts');
const { createRedisDistributedLock }=require('./redis-distributed-lock');
async function createRedisQueue(redisUrl,{client:injectedClient,blockingClient:injectedBlockingClient}={}) {
  if(!redisUrl && !injectedClient) throw new Error('REDIS_URL no configurada');
  let Redis, client=injectedClient, blocking=injectedBlockingClient;
  if(!client){try{Redis=require('ioredis')}catch{throw new Error('El adaptador Redis requiere ioredis en el entorno de despliegue.')} client=new Redis(redisUrl,{maxRetriesPerRequest:null});}
  if(!blocking){try{Redis=require('ioredis')}catch{throw new Error('El adaptador Redis requiere ioredis en el entorno de despliegue.')} blocking=new Redis(redisUrl,{maxRetriesPerRequest:null});}
  const key=q=>`puntia:queue:${String(q)}`;
  const lock=createRedisDistributedLock({client});
  const processing=q=>`puntia:processing:${String(q)}`;
  const jobs='puntia:jobs';
  const normalize=(job)=>job?assertQueueResult(job):null;
  return {
    async enqueue(queue,payload){const id=String(payload.id||'');if(!id)throw new Error('job.id requerido');const job={...payload,status:'queued',updatedAt:new Date().toISOString()};await client.hset(jobs,id,JSON.stringify(job));await client.lpush(key(queue),id);return id;},
    async get(queue,id){const raw=await client.hget(jobs,String(id));return raw?normalize(JSON.parse(raw)):null;},
    async claim(queue,timeoutSeconds=1){const result=await blocking.brpoplpush(key(queue),processing(queue),timeoutSeconds);if(!result)return null;const raw=await client.hget(jobs,result);if(!raw){await client.lrem(processing(queue),0,String(result));return null;}const job=JSON.parse(raw);if(job.status!=='queued'){await client.lrem(processing(queue),0,String(result));return normalize(job);}job.status='running';job.updatedAt=new Date().toISOString();await client.hset(jobs,result,JSON.stringify(job));return normalize(job);},
    async ack(queue,id){ await client.lrem(processing(queue),0,String(id)); return true; },
    async deadLetter(queue,id){ const raw=await client.hget(jobs,String(id)); if(raw) await client.lpush(`puntia:dlq:${String(queue)}`,raw); await client.lrem(processing(queue),0,String(id)); return true; },
    async complete(queue,id,result){const raw=await client.hget(jobs,String(id));if(!raw)return null;const job=JSON.parse(raw);if(job.status==='completed')return normalize(job);if(job.status==='failed')return normalize(job);job.status='completed';job.progress=100;job.result=result;job.updatedAt=new Date().toISOString();await client.hset(jobs,String(id),JSON.stringify(job));await client.lrem(processing(queue),0,String(id));return normalize(job);},
    async fail(queue,id,error){const raw=await client.hget(jobs,String(id));if(!raw)return null;const job=JSON.parse(raw);if(job.status==='failed')return normalize(job);if(job.status==='completed')return normalize(job);job.status='failed';job.progress=100;job.error=String(error?.message||error||'Error');job.errorCode=String(error?.code||'JOB_FAILED');job.updatedAt=new Date().toISOString();await client.hset(jobs,String(id),JSON.stringify(job));await client.lrem(processing(queue),0,String(id));return normalize(job);},
    distributedLock:lock,
    async recover(queue, ids=[]){ for(const id of ids) await client.lpush(key(queue),String(id)); return ids.length; },
    async health(){ try { return (await client.ping()) === 'PONG'; } catch { return false; } },
    async close(){if(blocking?.quit)await blocking.quit();if(client!==blocking&&client?.quit)await client.quit();}
  };
}
module.exports={createRedisQueue};
