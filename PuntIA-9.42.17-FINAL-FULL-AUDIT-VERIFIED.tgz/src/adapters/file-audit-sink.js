'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function canonical(event) { return JSON.stringify(event); }
function createFileAuditSink(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  try { fs.chmodSync(file, 0o600); } catch {}
  let previousHash = '';
  try {
    const lines = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean);
    const last = lines.at(-1); if (last) previousHash = JSON.parse(last).hash || '';
  } catch {}
  return {
    record(event) {
      const body = { ...event, previousHash };
      const hash = crypto.createHash('sha256').update(canonical(body)).digest('hex');
      const row = { ...body, hash };
      fs.appendFileSync(file, JSON.stringify(row) + '\n', { mode: 0o600 });
      previousHash = hash;
      return row;
    },
    list(limit = 100) {
      try { return fs.readFileSync(file,'utf8').split('\n').filter(Boolean).slice(-limit).map(JSON.parse).reverse(); } catch { return []; }
    },
    pruneBefore(cutoff) {
      const limit=Date.parse(cutoff); if(!Number.isFinite(limit)) throw new Error('cutoff inválido');
      let rows=[]; try{rows=fs.readFileSync(file,'utf8').split('\n').filter(Boolean).map(JSON.parse);}catch{return 0;}
      const kept=rows.filter(r=>Date.parse(r.occurredAt||0)>=limit);
      const removed=rows.length-kept.length;
      if(!removed)return 0;
      let previous='';
      for(const row of kept){row.previousHash=previous;const {hash,...body}=row;row.hash=crypto.createHash('sha256').update(canonical(body)).digest('hex');previous=row.hash;}
      const tmp=`${file}.${process.pid}.${crypto.randomBytes(5).toString('hex')}.tmp`;
      fs.writeFileSync(tmp,kept.map(r=>JSON.stringify(r)).join('\n')+(kept.length?'\n':''),{mode:0o600});fs.renameSync(tmp,file);previousHash=previous;return removed;
    },
    redactActor({ actorId, resourceIds = [] } = {}) {
      const ids = new Set((resourceIds || []).map(String));
      let rows = [];
      try { rows = fs.readFileSync(file,'utf8').split('\n').filter(Boolean).map(JSON.parse); } catch { return 0; }
      let changed = 0;
      let previous = '';
      for (const row of rows) {
        if (String(row.actorId || '') === String(actorId) || ids.has(String(row.resourceId || ''))) {
          row.actorId = null;
          row.resourceId = null;
          row.correlationId = null;
          row.metadata = { privacyRedacted: true };
          changed++;
        }
        row.previousHash = previous;
        const { hash, ...body } = row;
        row.hash = crypto.createHash('sha256').update(canonical(body)).digest('hex');
        previous = row.hash;
      }
      if (changed) {
        const tmp = `${file}.${process.pid}.${crypto.randomBytes(5).toString('hex')}.tmp`;
        fs.writeFileSync(tmp, rows.map(r => JSON.stringify(r)).join('\n') + (rows.length ? '\n' : ''), { mode:0o600 });
        fs.renameSync(tmp, file);
        previousHash = rows.at(-1)?.hash || '';
      }
      return changed;
    },
    verify() {
      let previous = '';
      let count = 0;
      try {
        for (const line of fs.readFileSync(file,'utf8').split('\n').filter(Boolean)) {
          const row = JSON.parse(line); const { hash, ...body } = row;
          if (body.previousHash !== previous) return { ok:false, count, error:'AUDIT_CHAIN_BROKEN' };
          const expected = crypto.createHash('sha256').update(canonical(body)).digest('hex');
          if (hash !== expected) return { ok:false, count, error:'AUDIT_HASH_MISMATCH' };
          previous = hash; count++;
        }
        return { ok:true, count };
      } catch (error) { return { ok:false, count, error:error.message }; }
    }
  };
}
module.exports = { createFileAuditSink };
