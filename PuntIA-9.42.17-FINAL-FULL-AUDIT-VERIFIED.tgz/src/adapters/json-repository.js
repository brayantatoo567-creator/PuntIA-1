'use strict';
const fs=require('fs');const path=require('path');
function atomicWrite(file,value){fs.mkdirSync(path.dirname(file),{recursive:true,mode:0o700});const tmp=`${file}.${process.pid}.${Date.now()}.${Math.random().toString(16).slice(2)}.tmp`;fs.writeFileSync(tmp,JSON.stringify(value,null,2),{encoding:'utf8',mode:0o600});fs.renameSync(tmp,file);}
function createJsonRepository(file){
  let chain=Promise.resolve();
  const run=fn=>{const next=chain.then(fn,fn);chain=next.catch(()=>{});return next;};
  const read=()=>{try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch(e){if(e.code==='ENOENT')return [];throw e}};
  return {
    list:async()=>run(()=>read()),
    get:async id=>run(()=>read().find(x=>x.id===id)||null),
    create:async item=>run(()=>{const a=read();if(a.some(x=>x.id===item.id))throw Object.assign(new Error('Registro duplicado'),{code:'DUPLICATE_ID'});a.unshift(item);atomicWrite(file,a);return item}),
    update:async(id,next)=>run(()=>{const a=read(),i=a.findIndex(x=>x.id===id);if(i<0)return null;a[i]=next;atomicWrite(file,a);return next}),
    remove:async id=>run(()=>{const a=read(),n=a.filter(x=>x.id!==id);if(n.length===a.length)return false;atomicWrite(file,n);return true}),
    close:async()=>{}
  };
}
module.exports={createJsonRepository};
