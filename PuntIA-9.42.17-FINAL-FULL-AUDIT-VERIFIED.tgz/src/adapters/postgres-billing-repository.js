'use strict';

function createPostgresBillingRepository({ databaseUrl, pool: injectedPool, graceDays = 3 } = {}) {
  if (!databaseUrl && !injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool = injectedPool;
  async function db() {
    if (pool) return pool;
    const pg = require('pg');
    pool = new pg.Pool({ connectionString: databaseUrl, max: 8 });
    return pool;
  }
  async function close() { if (pool?.end && !injectedPool) await pool.end(); }
  const graceMs = Math.max(0, Number(graceDays) || 0) * 86400000;
  function safeUser(id) { const v = String(id || '').trim(); if (!v) throw new Error('userId requerido'); return v; }
  function safePlan(plan) { return ['free','premium','pro'].includes(plan) ? plan : 'free'; }
  function effective(row) {
    if (!row) return { plan:'free', status:'none', access:false, graceUntil:null };
    const status = String(row.status || 'none');
    if (status === 'active' || status === 'trialing') return { plan:safePlan(row.plan), status, access:true, graceUntil:row.grace_until || null, subscriptionId:row.stripe_subscription_id || null, customerId:row.stripe_customer_id || null, currentPeriodEnd:row.current_period_end || null, cancelAtPeriodEnd:Boolean(row.cancel_at_period_end) };
    if (status === 'past_due' && row.grace_until && Date.parse(row.grace_until) > Date.now()) return { plan:safePlan(row.plan), status, access:true, graceUntil:row.grace_until, subscriptionId:row.stripe_subscription_id || null, customerId:row.stripe_customer_id || null, currentPeriodEnd:row.current_period_end || null, cancelAtPeriodEnd:Boolean(row.cancel_at_period_end) };
    return { plan:'free', status, access:false, graceUntil:row.grace_until || null, subscriptionId:row.stripe_subscription_id || null, customerId:row.stripe_customer_id || null, currentPeriodEnd:row.current_period_end || null, cancelAtPeriodEnd:Boolean(row.cancel_at_period_end) };
  }
  async function entitlement(userId) {
    const p = await db(); const r = await p.query('SELECT * FROM billing_subscriptions WHERE user_id=$1',[safeUser(userId)]);
    return effective(r.rows[0]);
  }
  async function hasEvent(eventId) { const p=await db(); const r=await p.query('SELECT 1 FROM billing_events WHERE event_id=$1',[String(eventId||'')]); return r.rowCount>0; }
  async function recordEvent(event) {
    const p = await db(); const id = String(event?.id || '').trim(); if (!id) return { processed:false };
    const r = await p.query(`INSERT INTO billing_events(event_id,event_type,event_created,user_id,payload) VALUES($1,$2,$3,$4,$5::jsonb) ON CONFLICT(event_id) DO NOTHING RETURNING event_id`, [id, String(event.type || 'unknown'), Number(event.created || 0), event.userId ? String(event.userId) : null, JSON.stringify(event)]);
    return { processed:r.rowCount === 1, id };
  }
  async function findUserIdByCustomer(customerId) { const p=await db(); const r=await p.query('SELECT user_id FROM billing_subscriptions WHERE stripe_customer_id=$1',[String(customerId||'')]); return r.rows[0]?.user_id || null; }
  async function upsertSubscription(input = {}) {
    const userId = safeUser(input.userId); const status = String(input.status || 'none');
    const eventCreated = Number(input.eventCreated || 0);
    const p = await db(); const client = await p.connect();
    try {
      await client.query('BEGIN');
      const current = await client.query('SELECT * FROM billing_subscriptions WHERE user_id=$1 FOR UPDATE',[userId]);
      if (current.rowCount && Number(current.rows[0].last_event_created || 0) > eventCreated) { await client.query('COMMIT'); return effective(current.rows[0]); }
      let plan = safePlan(input.plan);
      const currentPeriodEnd = input.currentPeriodEnd ? new Date(Number(input.currentPeriodEnd) * 1000).toISOString() : null;
      let graceUntil = null;
      if (status === 'past_due') {
        const base = currentPeriodEnd ? Math.max(Date.now(), Date.parse(currentPeriodEnd)) : Date.now();
        graceUntil = new Date(base + graceMs).toISOString();
      }
      if (status === 'canceled' || status === 'unpaid' || status === 'paused' || status === 'incomplete' || status === 'incomplete_expired') plan = 'free';
      const values = [userId, plan, status, input.customerId || null, input.subscriptionId || null, input.priceId || null, currentPeriodEnd, Boolean(input.cancelAtPeriodEnd), graceUntil, eventCreated, JSON.stringify(input.metadata || {})];
      await client.query(`INSERT INTO billing_subscriptions(user_id,plan,status,stripe_customer_id,stripe_subscription_id,price_id,current_period_end,cancel_at_period_end,grace_until,last_event_created,metadata,updated_at)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,now())
        ON CONFLICT(user_id) DO UPDATE SET plan=EXCLUDED.plan,status=EXCLUDED.status,stripe_customer_id=COALESCE(EXCLUDED.stripe_customer_id,billing_subscriptions.stripe_customer_id),stripe_subscription_id=COALESCE(EXCLUDED.stripe_subscription_id,billing_subscriptions.stripe_subscription_id),price_id=COALESCE(EXCLUDED.price_id,billing_subscriptions.price_id),current_period_end=COALESCE(EXCLUDED.current_period_end,billing_subscriptions.current_period_end),cancel_at_period_end=EXCLUDED.cancel_at_period_end,grace_until=EXCLUDED.grace_until,last_event_created=EXCLUDED.last_event_created,metadata=EXCLUDED.metadata,updated_at=now()`, values);
      await client.query('COMMIT');
      return effective((await client.query('SELECT * FROM billing_subscriptions WHERE user_id=$1',[userId])).rows[0]);
    } catch (e) { try { await client.query('ROLLBACK'); } catch {} throw e; } finally { client.release(); }
  }
  async function deleteUserData(userId) {
    const p = await db(); const u=safeUser(userId); await p.query('DELETE FROM billing_events WHERE user_id=$1',[u]); await p.query('DELETE FROM billing_subscriptions WHERE user_id=$1',[u]); return {ok:true};
  }
  async function listForAdmin(limit=100) { const p=await db(); const n=Math.min(500,Math.max(1,Number(limit)||100)); const r=await p.query(`SELECT user_id,plan,status,stripe_customer_id,stripe_subscription_id,price_id,current_period_end,cancel_at_period_end,grace_until,updated_at FROM billing_subscriptions ORDER BY updated_at DESC LIMIT $1`,[n]); return r.rows.map(x=>({userId:x.user_id,plan:x.plan,status:x.status,customerId:x.stripe_customer_id,subscriptionId:x.stripe_subscription_id,priceId:x.price_id,currentPeriodEnd:x.current_period_end,cancelAtPeriodEnd:Boolean(x.cancel_at_period_end),graceUntil:x.grace_until,updatedAt:x.updated_at})); }
  async function metrics() { const p=await db(); const r=await p.query(`SELECT COUNT(*) FILTER (WHERE plan='premium' AND status IN ('active','trialing','past_due')) AS premium, COUNT(*) FILTER (WHERE plan='pro' AND status IN ('active','trialing','past_due')) AS pro, COUNT(*) FILTER (WHERE status='past_due') AS past_due, COUNT(*) FILTER (WHERE status='canceled') AS canceled FROM billing_subscriptions`); const row=r.rows[0]||{}; return {premium:Number(row.premium||0),pro:Number(row.pro||0),pastDue:Number(row.past_due||0),canceled:Number(row.canceled||0)}; }
  return { entitlement, hasEvent, recordEvent, findUserIdByCustomer, upsertSubscription, deleteUserData, listForAdmin, metrics, close };
}
module.exports = { createPostgresBillingRepository };
