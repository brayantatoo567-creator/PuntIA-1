'use strict';
const crypto=require('crypto');
const { assertUsageKind, assertUsageReservation }=require('../core/contracts');
function monthKey(date=new Date()){return `${date.getUTCFullYear()}-${String(date.getUTCMonth()+1).padStart(2,'0')}-01`;}
function safeUser(id){const v=String(id||'').trim();if(!v)throw new Error('userId requerido');return v;}
function createPostgresUsageLedger({databaseUrl,pool:injectedPool}={}){
  if(!databaseUrl&&!injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool=injectedPool;
  async function ensurePool(){
    if(pool)return pool;
    let pg;try{pg=require('pg')}catch{throw new Error('El adaptador PostgreSQL requiere el paquete pg en el entorno de despliegue.');}
    pool=new pg.Pool({connectionString:databaseUrl,max:10});return pool;
  }
  async function close(){if(pool?.end)await pool.end();}
  return {
    async reserve(userId,kind,limit=Infinity,reservationId){
      const user=safeUser(userId), k=assertUsageKind(kind), id=String(reservationId||crypto.randomUUID());
      if(!Number.isFinite(Number(limit)) && limit!==Infinity) throw new Error('limit inválido');
      const db=await ensurePool(), client=await db.connect(), month=monthKey();
      try{
        await client.query('BEGIN');
        const existing=await client.query('SELECT reservation_id,user_id,kind,state FROM usage_reservations WHERE reservation_id=$1 FOR UPDATE',[id]);
        if(existing.rowCount){const r=existing.rows[0];if(r.user_id!==user||r.kind!==k)throw Object.assign(new Error('Reserva de uso inválida.'),{code:'USAGE_RESERVATION_MISMATCH',status:409});const usedRow=await client.query(`SELECT ${k} AS used FROM usage_monthly WHERE user_id=$1 AND month=$2`,[user,month]);const used=Number(usedRow.rows[0]?.used||0);await client.query('COMMIT');return assertUsageReservation({allowed:r.state!=='released',used,limit,reservationId:id,state:r.state,idempotent:true});}
        await client.query(`INSERT INTO usage_monthly(user_id,month) VALUES($1,$2) ON CONFLICT(user_id,month) DO NOTHING`,[user,month]);
        const row=await client.query(`SELECT ${k} AS used FROM usage_monthly WHERE user_id=$1 AND month=$2 FOR UPDATE`,[user,month]);
        const used=Number(row.rows[0]?.used||0);
        if(used>=limit){await client.query('ROLLBACK');return assertUsageReservation({allowed:false,used,limit,reservationId:id});}
        await client.query(`UPDATE usage_monthly SET ${k}=${k}+1 WHERE user_id=$1 AND month=$2`,[user,month]);
        await client.query(`INSERT INTO usage_reservations(reservation_id,user_id,kind,month,state) VALUES($1,$2,$3,$4,'reserved')`,[id,user,k,month]);
        await client.query('COMMIT');
        return assertUsageReservation({allowed:true,used:used+1,limit,reservationId:id,state:'reserved'});
      }catch(e){try{await client.query('ROLLBACK')}catch{};throw e;}finally{client.release();}
    },
    async snapshot(userId){
      const db=await ensurePool(), user=safeUser(userId), month=monthKey();
      const r=await db.query('SELECT pattern,chat,image,vision,pdf FROM usage_monthly WHERE user_id=$1 AND month=$2',[user,month]);
      return r.rows[0] || {pattern:0,chat:0,image:0,vision:0,pdf:0};
    },
    async confirm(reservationId){
      const id=String(reservationId||'');if(!id)throw new Error('reservationId requerido');const db=await ensurePool();
      const r=await db.query(`UPDATE usage_reservations SET state='confirmed',confirmed_at=now() WHERE reservation_id=$1 AND state='reserved' RETURNING state`,[id]);
      if(r.rowCount)return {ok:true,state:'confirmed'};
      const current=await db.query('SELECT state FROM usage_reservations WHERE reservation_id=$1',[id]);
      if(!current.rowCount)return {ok:false,code:'RESERVATION_NOT_FOUND'};
      return {ok:true,state:current.rows[0].state};
    },
    async release(userId,kind,reservationId){
      const user=safeUser(userId), k=assertUsageKind(kind), id=String(reservationId||'');if(!id)throw new Error('reservationId requerido');const db=await ensurePool(),client=await db.connect();
      try{
        await client.query('BEGIN');
        const r=await client.query('SELECT * FROM usage_reservations WHERE reservation_id=$1 FOR UPDATE',[id]);
        if(!r.rowCount){await client.query('ROLLBACK');return {ok:false,code:'USAGE_RESERVATION_NOT_FOUND'};}
        const row=r.rows[0];if(row.user_id!==user||row.kind!==k){await client.query('ROLLBACK');return {ok:false,code:'USAGE_RESERVATION_MISMATCH'};}
        if(row.state==='released'){await client.query('ROLLBACK');return {ok:true,state:'released',idempotent:true};}
        if(row.state==='confirmed'){await client.query('ROLLBACK');return {ok:false,code:'USAGE_ALREADY_CONFIRMED'};}
        const month=String(row.month).slice(0,10);await client.query(`UPDATE usage_monthly SET ${k}=GREATEST(${k}-1,0) WHERE user_id=$1 AND month=$2`,[user,month]);
        await client.query(`UPDATE usage_reservations SET state='released',released_at=now() WHERE reservation_id=$1`,[id]);
        await client.query('COMMIT');return {ok:true,state:'released'};
      }catch(e){try{await client.query('ROLLBACK')}catch{};throw e;}finally{client.release();}
    },
    close
  };
}
module.exports={createPostgresUsageLedger};
