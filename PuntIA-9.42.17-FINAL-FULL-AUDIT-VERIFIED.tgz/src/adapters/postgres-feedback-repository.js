'use strict';
function createPostgresFeedbackRepository({databaseUrl,pool:injectedPool}={}){
  if(!databaseUrl&&!injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool=injectedPool;
  async function db(){if(pool)return pool; const pg=require('pg'); pool=new pg.Pool({connectionString:databaseUrl,max:6}); return pool;}
  async function upsert(item){const p=await db(); const r=await p.query(`INSERT INTO feedback_events(id,user_id,result_type,result_id,project_id,pattern_hash,rating,categories,comment,created_at,updated_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11) ON CONFLICT(user_id,result_type,result_id) DO UPDATE SET project_id=EXCLUDED.project_id,pattern_hash=EXCLUDED.pattern_hash,rating=EXCLUDED.rating,categories=EXCLUDED.categories,comment=EXCLUDED.comment,updated_at=EXCLUDED.updated_at RETURNING *`,[item.id,item.userId,item.resultType,item.resultId||'',item.projectId||null,item.patternHash||null,item.rating,JSON.stringify(item.categories||[]),item.comment||'',item.createdAt,item.updatedAt]); return map(r.rows[0]);}
  async function listForUser(userId){const p=await db(); const r=await p.query('SELECT * FROM feedback_events WHERE user_id=$1 ORDER BY updated_at DESC',[String(userId)]); return r.rows.map(map);}
  async function metrics(){const p=await db(); const base=await p.query(`SELECT COUNT(*)::int AS count,COALESCE(ROUND(AVG(rating)::numeric,2),0) AS avg,COUNT(*) FILTER(WHERE rating<=2)::int AS negative FROM feedback_events`); const cats=await p.query(`SELECT jsonb_array_elements_text(categories) AS category,COUNT(*)::int AS count FROM feedback_events GROUP BY 1 ORDER BY count DESC`); const x=base.rows[0]||{}; return {count:Number(x.count||0),averageRating:Number(x.avg||0),negative:Number(x.negative||0),categoryCounts:Object.fromEntries(cats.rows.map(r=>[r.category,Number(r.count)]))};}
  async function deleteUserData(userId){const p=await db(); await p.query('DELETE FROM feedback_events WHERE user_id=$1',[String(userId)]); return {ok:true};}
  async function close(){if(pool?.end&&!injectedPool)await pool.end();}
  function map(r){return {id:r.id,userId:r.user_id,resultType:r.result_type,resultId:r.result_id,projectId:r.project_id,patternHash:r.pattern_hash,rating:Number(r.rating),categories:r.categories||[],comment:r.comment||'',createdAt:r.created_at,updatedAt:r.updated_at};}
  return {upsert,listForUser,metrics,deleteUserData,close};
}
module.exports={createPostgresFeedbackRepository};
