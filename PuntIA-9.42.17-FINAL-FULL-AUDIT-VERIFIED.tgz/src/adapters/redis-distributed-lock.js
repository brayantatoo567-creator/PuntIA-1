'use strict';
const crypto=require('crypto');
const RELEASE_LUA="if redis.call('get',KEYS[1]) == ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end";
function createRedisDistributedLock({client:injectedClient,prefix='puntia:lock'}={}){
  let client=injectedClient;
  async function acquire(name,ttlMs=10000){
    if(!client) throw new Error('Redis client requerido');
    const token=crypto.randomUUID(); const key=`${prefix}:${String(name)}`;
    const ok=await client.set(key,token,'PX',Math.max(1000,Number(ttlMs)||10000),'NX');
    if(ok!=='OK') return null;
    return {key,token,release:async()=>{try{return Number(await client.eval(RELEASE_LUA,1,key,token))===1;}catch{return false;}}};
  }
  return {acquire};
}
module.exports={createRedisDistributedLock};
