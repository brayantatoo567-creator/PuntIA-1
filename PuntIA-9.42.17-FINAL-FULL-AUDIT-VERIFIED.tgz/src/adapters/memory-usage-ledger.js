'use strict';
function createMemoryUsageLedger(){
  const rows=new Map(); const reservations=new Map();
  const key=(u,k)=>`${u}:${k}`;
  return {
    async reserve(userId,kind,limit=Infinity,reservationId){
      const id=String(reservationId||`${userId}:${kind}:${Date.now()}:${Math.random()}`);
      if(reservations.has(id)){ const existing=reservations.get(id); if(existing.userId!==userId || existing.kind!==kind) throw Object.assign(new Error('Reserva de uso inválida.'),{code:'USAGE_RESERVATION_MISMATCH',status:409}); if(existing.state==='released') return {allowed:false,used:rows.get(key(userId,kind))||0,limit,reservationId:id,state:'released',idempotent:true}; return {...existing,allowed:true}; }
      const k=key(userId,kind),used=rows.get(k)||0;
      if(used>=limit){return {allowed:false,used,limit,reservationId:id};}
      const result={allowed:true,used:used+1,limit,reservationId:id};rows.set(k,used+1);reservations.set(id,{...result,userId,kind,state:'reserved'});return result;
    },
    async confirm(reservationId){const r=reservations.get(String(reservationId));if(!r)return {ok:false,code:'RESERVATION_NOT_FOUND'};if(r.state==='confirmed'||r.state==='released')return {ok:true,state:r.state};r.state='confirmed';return {ok:true,state:'confirmed'};},
    async release(userId,kind,reservationId){
      if(reservationId){const r=reservations.get(String(reservationId));if(!r)return {ok:false,code:'RESERVATION_NOT_FOUND'};if(r.state==='released')return {ok:true,used:rows.get(key(r.userId,r.kind))||0};if(r.state==='confirmed')return {ok:false,code:'ALREADY_CONFIRMED'};const k=key(r.userId,r.kind);rows.set(k,Math.max(0,(rows.get(k)||0)-1));r.state='released';return {ok:true,used:rows.get(k)||0};
      }
      const k=key(userId,kind),used=Math.max(0,(rows.get(k)||0)-1);rows.set(k,used);return {ok:true,used};
    }
  };
}
module.exports={createMemoryUsageLedger};
