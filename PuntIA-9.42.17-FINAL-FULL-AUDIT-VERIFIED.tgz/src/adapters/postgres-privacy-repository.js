'use strict';

function createPostgresPrivacyRepository({ databaseUrl, pool: injectedPool } = {}) {
  if (!databaseUrl && !injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool = injectedPool;
  async function db() {
    if (pool) return pool;
    const pg = require('pg');
    pool = new pg.Pool({ connectionString: databaseUrl, max: 6 });
    return pool;
  }
  async function close() { if (pool?.end && !injectedPool) await pool.end(); }

  async function deleteUserData(ownerId) {
    const owner = String(ownerId || '').trim();
    if (!owner) throw new Error('ownerId requerido');
    const p = await db();
    const client = await p.connect();
    try {
      await client.query('BEGIN');
      const projects = await client.query('SELECT id, data FROM projects WHERE user_id=$1 FOR UPDATE', [owner]);
      const projectIds = projects.rows.map(r => String(r.id));
      const assetKeys = [];
      for (const row of projects.rows) {
        const assets = Array.isArray(row.data?.assets) ? row.data.assets : [];
        for (const asset of assets) {
          if (asset?.key) assetKeys.push(String(asset.key));
        }
      }
      const jobs = await client.query('SELECT id FROM puntia_jobs WHERE owner_id=$1 FOR UPDATE', [owner]);
      const jobIds = jobs.rows.map(r => String(r.id));
      if (projectIds.length) {
        await client.query('DELETE FROM project_versions WHERE project_id = ANY($1::text[])', [projectIds]);
      }
      await client.query('DELETE FROM projects WHERE user_id=$1', [owner]);
      await client.query('DELETE FROM puntia_jobs WHERE owner_id=$1', [owner]);
      await client.query('DELETE FROM usage_reservations WHERE user_id=$1', [owner]);
      await client.query('DELETE FROM usage_monthly WHERE user_id=$1', [owner]);
      await client.query('DELETE FROM assistant_conversations WHERE user_id=$1', [owner]);
      await client.query('DELETE FROM assistant_patterns WHERE user_id=$1', [owner]);
      await client.query('COMMIT');
      return { ok: true, ownerId: owner, projectIds, jobIds, assetKeys: [...new Set(assetKeys)] };
    } catch (error) {
      try { await client.query('ROLLBACK'); } catch {}
      throw error;
    } finally { client.release(); }
  }

  return { deleteUserData, close };
}
module.exports = { createPostgresPrivacyRepository };
