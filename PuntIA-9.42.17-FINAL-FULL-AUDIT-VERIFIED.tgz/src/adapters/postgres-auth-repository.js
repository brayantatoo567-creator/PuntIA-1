'use strict';

function safeId(value, name='id') {
  const v = String(value || '').trim();
  if (!v) throw new Error(`${name} requerido`);
  return v;
}

function mapUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    passwordHash: row.password_hash,
    passwordSalt: row.password_salt,
    authVersion: Number(row.auth_version || 1),
    plan: row.plan || 'free',
    role: row.role === 'admin' ? 'admin' : 'user',
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : row.created_at
  };
}

function mapSession(row) {
  if (!row) return null;
  return {
    sessionId: row.session_id,
    userId: row.user_id,
    authVersion: Number(row.auth_version || 1),
    csrf: row.csrf,
    createdAt: row.created_at instanceof Date ? row.created_at.toISOString() : row.created_at,
    lastSeenAt: row.last_seen_at instanceof Date ? row.last_seen_at.toISOString() : row.last_seen_at,
    expiresAt: row.expires_at instanceof Date ? row.expires_at.toISOString() : row.expires_at,
    userAgent: row.user_agent || ''
  };
}

async function createPostgresAuthRepository({ databaseUrl, pool: injectedPool } = {}) {
  if (!databaseUrl && !injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool = injectedPool;
  let owned = false;
  if (!pool) {
    const pg = require('pg');
    pool = new pg.Pool({ connectionString: databaseUrl, max: 10 });
    owned = true;
  }
  return {
    async findByEmail(email) {
      const r = await pool.query('SELECT * FROM users WHERE email=$1 LIMIT 1', [String(email || '').trim().toLowerCase()]);
      return mapUser(r.rows[0]);
    },
    async findById(id) {
      const r = await pool.query('SELECT * FROM users WHERE id=$1 LIMIT 1', [safeId(id, 'user.id')]);
      return mapUser(r.rows[0]);
    },
    async list() {
      const r = await pool.query('SELECT * FROM users ORDER BY created_at ASC');
      return r.rows.map(mapUser);
    },
    async createUser(user) {
      const candidate = {
        id: safeId(user?.id, 'user.id'),
        email: String(user?.email || '').trim().toLowerCase(),
        name: String(user?.name || '').trim().slice(0, 80),
        passwordHash: String(user?.passwordHash || ''),
        passwordSalt: String(user?.passwordSalt || ''),
        authVersion: Number(user?.authVersion || 1),
        plan: ['free', 'premium', 'pro'].includes(user?.plan) ? user.plan : 'free',
        role: user?.role === 'admin' ? 'admin' : 'user'
      };
      const r = await pool.query(`INSERT INTO users(id,email,name,password_hash,password_salt,auth_version,plan,role)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`, [candidate.id,candidate.email,candidate.name,candidate.passwordHash,candidate.passwordSalt,candidate.authVersion,candidate.plan,candidate.role]);
      return mapUser(r.rows[0]);
    },
    async updateUser(id, patch = {}) {
      const current = await this.findById(id);
      if (!current) return null;
      const next = { ...current, ...patch };
      const r = await pool.query(`UPDATE users SET name=$2,password_hash=$3,password_salt=$4,auth_version=$5,plan=$6,role=$7 WHERE id=$1 RETURNING *`, [safeId(id,'user.id'),String(next.name||''),String(next.passwordHash||''),String(next.passwordSalt||''),Number(next.authVersion||1),['free','premium','pro'].includes(next.plan)?next.plan:'free',next.role==='admin'?'admin':'user']);
      return mapUser(r.rows[0]);
    },
    async createSession(tokenHash, session) {
      await pool.query(`INSERT INTO auth_sessions(token_hash,session_id,user_id,auth_version,csrf,created_at,last_seen_at,expires_at,user_agent)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [tokenHash,session.sessionId,safeId(session.userId,'session.userId'),Number(session.authVersion||1),String(session.csrf||''),session.createdAt,session.lastSeenAt,session.expiresAt,String(session.userAgent||'').slice(0,300)]);
      return session;
    },
    async getSession(tokenHash) {
      const r = await pool.query(`SELECT s.*, u.email,u.name,u.password_hash,u.password_salt,u.plan,u.role,u.created_at AS user_created_at,u.auth_version AS user_auth_version
        FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now() LIMIT 1`, [tokenHash]);
      if (!r.rowCount) return null;
      const row = r.rows[0];
      const session = mapSession(row);
      session.user = mapUser({id:row.user_id,email:row.email,name:row.name,password_hash:row.password_hash,password_salt:row.password_salt,plan:row.plan,role:row.role,created_at:row.user_created_at,auth_version:row.user_auth_version});
      return session;
    },
    async deleteSession(tokenHash) { const r=await pool.query('DELETE FROM auth_sessions WHERE token_hash=$1',[tokenHash]); return r.rowCount; },
    async listSessions(userId) { const r=await pool.query('SELECT * FROM auth_sessions WHERE user_id=$1 AND expires_at>now() ORDER BY created_at DESC',[safeId(userId,'user.id')]); return r.rows.map(mapSession); },
    async revokeAllSessions(userId) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const r = await client.query('UPDATE users SET auth_version=auth_version+1 WHERE id=$1 RETURNING auth_version',[safeId(userId,'user.id')]);
        const deleted = await client.query('DELETE FROM auth_sessions WHERE user_id=$1',[safeId(userId,'user.id')]);
        await client.query('COMMIT');
        return { count:deleted.rowCount, authVersion:Number(r.rows[0]?.auth_version || 1) };
      } catch(e){ try{await client.query('ROLLBACK')}catch{}; throw e; } finally { client.release(); }
    },
    async createResetToken(tokenHash,userId,expiresAt) {
      await pool.query(`INSERT INTO auth_reset_tokens(token_hash,user_id,expires_at) VALUES($1,$2,$3)`,[tokenHash,safeId(userId,'user.id'),expiresAt]);
    },
    async consumeResetToken(tokenHash) {
      const client=await pool.connect();
      try{
        await client.query('BEGIN');
        const r=await client.query('SELECT user_id,expires_at FROM auth_reset_tokens WHERE token_hash=$1 FOR UPDATE',[tokenHash]);
        if(!r.rowCount || new Date(r.rows[0].expires_at).getTime()<=Date.now()){await client.query('ROLLBACK');return null;}
        await client.query('DELETE FROM auth_reset_tokens WHERE token_hash=$1',[tokenHash]);
        await client.query('COMMIT');
        return {userId:r.rows[0].user_id,expiresAt:new Date(r.rows[0].expires_at).toISOString()};
      }catch(e){try{await client.query('ROLLBACK')}catch{};throw e;}finally{client.release();}
    },
    async deleteUser(id) {
      const r=await pool.query('DELETE FROM users WHERE id=$1',[safeId(id,'user.id')]);
      return r.rowCount;
    },
    async ensureAdmin({email,password,hashPassword}) {
      const normalized=String(email||'').trim().toLowerCase();
      if(!normalized || !password) return null;
      const existing=await this.findByEmail(normalized);
      if(!existing){const hp=hashPassword(password);return this.createUser({id:require('crypto').randomUUID(),email:normalized,name:'PuntIA Admin',passwordHash:hp.hash,passwordSalt:hp.salt,authVersion:1,plan:'pro',role:'admin'});}
      const patch={role:'admin',plan:'pro'};
      if(String(process.env.PUNTIA_ADMIN_SYNC_PASSWORD||'').toLowerCase()==='true'){const hp=hashPassword(password);patch.passwordHash=hp.hash;patch.passwordSalt=hp.salt;patch.authVersion=Number(existing.authVersion||1)+1;}
      return this.updateUser(existing.id,patch);
    },
    async prune() { const a=await pool.query('DELETE FROM auth_sessions WHERE expires_at<=now()'); const b=await pool.query('DELETE FROM auth_reset_tokens WHERE expires_at<=now()'); return {sessions:a.rowCount,resetTokens:b.rowCount}; },
    async close(){if(owned)await pool.end();}
  };
}
module.exports={createPostgresAuthRepository};
