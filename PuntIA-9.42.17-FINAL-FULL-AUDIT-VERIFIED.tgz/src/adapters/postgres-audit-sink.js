'use strict';
const crypto = require('crypto');
async function createPostgresAuditSink({ databaseUrl, pool: injectedPool } = {}) {
  let pool = injectedPool;
  if (!pool) {
    let pg; try { pg = require('pg'); } catch { throw new Error('PostgreSQL requiere pg.'); }
    pool = new pg.Pool({ connectionString: databaseUrl, max: 10 });
  }
  await pool.query(`CREATE TABLE IF NOT EXISTS audit_events (
    event_id text PRIMARY KEY, occurred_at timestamptz NOT NULL, action text NOT NULL,
    resource_type text NOT NULL, resource_id text, actor_id text, correlation_id text,
    status text NOT NULL, metadata jsonb NOT NULL DEFAULT '{}'::jsonb, previous_hash text NOT NULL DEFAULT '', hash text NOT NULL
  )`);
  return {
    async record(event) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const last = await client.query('SELECT hash FROM audit_events ORDER BY occurred_at DESC, event_id DESC LIMIT 1 FOR UPDATE');
        const previousHash = last.rows[0]?.hash || '';
        const body = { ...event, previousHash };
        const hash = crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
        await client.query(`INSERT INTO audit_events(event_id,occurred_at,action,resource_type,resource_id,actor_id,correlation_id,status,metadata,previous_hash,hash) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,$10,$11)`, [event.eventId,event.occurredAt,event.action,event.resourceType,event.resourceId,event.actorId,event.correlationId,event.status,JSON.stringify(event.metadata||{}),previousHash,hash]);
        await client.query('COMMIT');
        return { ...body, hash };
      } catch (e) { try { await client.query('ROLLBACK'); } catch {} throw e; } finally { client.release(); }
    },
    async list(limit=100) { const r=await pool.query('SELECT * FROM audit_events ORDER BY occurred_at DESC, event_id DESC LIMIT $1',[Math.min(500,Math.max(1,Number(limit)||100))]); return r.rows; },
    async pruneBefore(cutoff) {
      const client=await pool.connect();
      try{await client.query('BEGIN');const r=await client.query('DELETE FROM audit_events WHERE occurred_at < $1 RETURNING event_id',[cutoff]);const rows=await client.query('SELECT * FROM audit_events ORDER BY occurred_at ASC, event_id ASC FOR UPDATE');let previous='';for(const row of rows.rows){const body={eventId:row.event_id,occurredAt:new Date(row.occurred_at).toISOString(),action:row.action,resourceType:row.resource_type,resourceId:row.resource_id,actorId:row.actor_id,correlationId:row.correlation_id,status:row.status,metadata:row.metadata,previousHash:previous};const hash=crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');await client.query('UPDATE audit_events SET previous_hash=$2, hash=$3 WHERE event_id=$1',[row.event_id,previous,hash]);previous=hash;}await client.query('COMMIT');return r.rowCount;}catch(e){try{await client.query('ROLLBACK')}catch{};throw e;}finally{client.release();}
    },
    async redactActor({ actorId, resourceIds = [] } = {}) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query(`UPDATE audit_events SET actor_id=NULL, resource_id=NULL, correlation_id=NULL, metadata='{"privacyRedacted":true}'::jsonb WHERE actor_id=$1 OR resource_id = ANY($2::text[])`, [String(actorId), (resourceIds || []).map(String)]);
        const rows = await client.query('SELECT * FROM audit_events ORDER BY occurred_at ASC, event_id ASC FOR UPDATE');
        let previous='';
        for (const row of rows.rows) {
          const body={eventId:row.event_id,occurredAt:new Date(row.occurred_at).toISOString(),action:row.action,resourceType:row.resource_type,resourceId:row.resource_id,actorId:row.actor_id,correlationId:row.correlation_id,status:row.status,metadata:row.metadata,previousHash:previous};
          const hash=crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex');
          await client.query('UPDATE audit_events SET previous_hash=$2, hash=$3 WHERE event_id=$1',[row.event_id,previous,hash]);
          previous=hash;
        }
        await client.query('COMMIT');
        return rows.rowCount;
      } catch(e){try{await client.query('ROLLBACK')}catch{};throw e;} finally{client.release();}
    },
    async health(){ try { await pool.query('SELECT 1'); return true; } catch { return false; } },
    async close(){ if(pool?.end && !injectedPool) await pool.end(); },
    async verify() { const r=await pool.query('SELECT * FROM audit_events ORDER BY occurred_at ASC, event_id ASC'); let previous=''; let count=0; for(const row of r.rows){const body={eventId:row.event_id,occurredAt:new Date(row.occurred_at).toISOString(),action:row.action,resourceType:row.resource_type,resourceId:row.resource_id,actorId:row.actor_id,correlationId:row.correlation_id,status:row.status,metadata:row.metadata,previousHash:row.previous_hash}; if(row.previous_hash!==previous)return{ok:false,count,error:'AUDIT_CHAIN_BROKEN'}; const expected=crypto.createHash('sha256').update(JSON.stringify(body)).digest('hex'); if(row.hash!==expected)return{ok:false,count,error:'AUDIT_HASH_MISMATCH'}; previous=row.hash; count++;} return {ok:true,count}; }
  };
}
module.exports = { createPostgresAuditSink };
