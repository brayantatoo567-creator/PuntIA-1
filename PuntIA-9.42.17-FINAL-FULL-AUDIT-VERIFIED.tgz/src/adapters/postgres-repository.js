'use strict';
const { normalizeProjectInput, assertProject, assertProjectList, requireId, contractError } = require('../core/contracts');
/** PostgreSQL project repository. Requires `pg` in the deployment image. */
function safeOwner(ownerId) {
  const v = String(ownerId || '').trim();
  if (!v) throw new Error('ownerId requerido');
  return v;
}
function mapRow(row) {
  if (!row) return null;
  return {
    id: row.id,
    ownerId: row.user_id,
    title: row.name,
    description: row.data?.description || '',
    level: row.data?.level || 'Principiante',
    size: row.data?.size || '',
    style: row.data?.style || '',
    status: row.status,
    progress: row.progress,
    pattern: row.pattern,
    image: row.image_url || '',
    notes: row.data?.notes || '',
    visualIdentity: row.data?.visualIdentity || {},
    assets: row.data?.assets || [],
    progressState: row.data?.progressState || {},
    versions: row.data?.versions || [],
    lastMutationKey: row.data?.lastMutationKey || '',
    version: Number(row.version || row.data?.version || 1),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
async function createPostgresRepository({databaseUrl, pool: injectedPool}={}) {
  if (!databaseUrl && !injectedPool) throw new Error('DATABASE_URL no configurada');
  let pool = injectedPool;
  if (!pool) {
    let pg;
    try { pg=require('pg'); } catch { throw new Error('El adaptador PostgreSQL requiere el paquete pg en el entorno de despliegue.'); }
    pool = new pg.Pool({connectionString:databaseUrl,max:10});
  }
  return {
    async list(ownerId) {
      const r=await pool.query('SELECT * FROM projects WHERE user_id=$1 ORDER BY updated_at DESC',[safeOwner(ownerId)]);
      return assertProjectList(r.rows.map(mapRow));
    },
    async get(id,ownerId) {
      const r=await pool.query('SELECT * FROM projects WHERE id=$1 AND user_id=$2',[String(id),safeOwner(ownerId)]);
      const mapped=mapRow(r.rows[0]);
      return mapped ? assertProject(mapped) : null;
    },
    async create(item,ownerId=item?.ownerId) {
      const owner=safeOwner(ownerId);
      const id=requireId(item?.id,'project.id');
      const mutationKey=String(item?.idempotencyKey||'').trim().slice(0,200);
      if (mutationKey) {
        const replay=await pool.query(`SELECT * FROM projects WHERE user_id=$1 AND data->>'lastMutationKey'=$2 LIMIT 1`,[owner,mutationKey]);
        if (replay.rowCount) return mapRow(replay.rows[0]);
      }
      const candidate=assertProject(normalizeProjectInput({...item, id, ownerId:owner}, {}, owner));
      await pool.query(`INSERT INTO projects (id,user_id,name,status,progress,pattern,image_url,data)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)`,[
        id,owner,String(candidate.title||'Proyecto sin nombre'),String(candidate.status||'idea'),Math.max(0,Math.min(100,Number(candidate.progress)||0)),candidate.pattern||null,candidate.image||null,JSON.stringify(candidate)
      ]);
      return this.get(id,owner);
    },
    async update(id,next,ownerId=next?.ownerId) {
      const owner=safeOwner(ownerId);
      // The cloud repository must apply the same partial-update/defaulting contract as the local service.
      // Otherwise fields omitted by a PATCH disappear from the JSONB projection.
      const client=await pool.connect();
      try {
        await client.query('BEGIN');
        const current=await client.query('SELECT * FROM projects WHERE id=$1 AND user_id=$2 FOR UPDATE',[String(id),owner]);
        if(!current.rowCount){await client.query('ROLLBACK');return null;}
        const row=current.rows[0];
        const existing=mapRow(row);
        const candidate=assertProject(normalizeProjectInput({...next, id:String(id), ownerId:owner}, existing, owner));
        const mutationKey=String(next?.idempotencyKey||'').trim().slice(0,200);
        if (mutationKey && String(row.data?.lastMutationKey||'') === mutationKey) { await client.query('COMMIT'); return this.get(id,owner); }
        const currentVersion=Number(row.version||1);
        if (next?.expectedVersion !== undefined && Number(next.expectedVersion) !== currentVersion) { await client.query('ROLLBACK'); throw contractError('PROJECT_VERSION_CONFLICT','El proyecto cambió en otro dispositivo.',409,{expectedVersion:Number(next.expectedVersion),actualVersion:currentVersion}); }
        const nextVersion=currentVersion+1;
        candidate.version=nextVersion;
        candidate.updatedAt=new Date().toISOString();
        const snapshot={...row.data,version:currentVersion,ownerId:row.user_id,id:row.id,title:row.name,status:row.status,progress:row.progress,pattern:row.pattern,image:row.image_url||'',updatedAt:row.updated_at};
        await client.query(`INSERT INTO project_versions(project_id,version,snapshot) VALUES($1,$2,$3::jsonb) ON CONFLICT DO NOTHING`,[String(id),currentVersion,JSON.stringify(snapshot)]);
        await client.query(`UPDATE projects SET name=$3,status=$4,progress=$5,pattern=$6,image_url=$7,data=$8::jsonb,version=$9,updated_at=now() WHERE id=$1 AND user_id=$2`,[String(id),owner,String(candidate.title||'Proyecto sin nombre'),String(candidate.status||'idea'),Math.max(0,Math.min(100,Number(candidate.progress)||0)),candidate.pattern||null,candidate.image||null,JSON.stringify(candidate),nextVersion]);
        await client.query('COMMIT');
        return this.get(id,owner);
      } catch(e){try{await client.query('ROLLBACK')}catch{};throw e;} finally {client.release();}
    },
    async remove(id,ownerId) {
      const r=await pool.query('DELETE FROM projects WHERE id=$1 AND user_id=$2',[String(id),safeOwner(ownerId)]);
      requireId(id,'project.id');
      return r.rowCount===1;
    },
    async close(){ if (!injectedPool && pool?.end) await pool.end(); }
  };
}
module.exports={createPostgresRepository};
