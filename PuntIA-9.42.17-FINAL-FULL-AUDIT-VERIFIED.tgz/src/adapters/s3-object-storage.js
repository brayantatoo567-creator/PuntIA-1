'use strict';
const { PutObjectCommand, GetObjectCommand, DeleteObjectCommand, ListObjectsV2Command, S3Client } = require('@aws-sdk/client-s3');
const { assertObjectPutResult } = require('../core/contracts');
function safeKey(key){const v=String(key||'').replace(/\\/g,'/');if(!v||v.startsWith('/')||v.includes('..')||v.length>300||v.includes('\0'))throw new Error('Clave de objeto inválida.');return v;}
function createS3ObjectStorage(config={}){
  const bucket=String(config.bucket||'').trim(); if(!bucket) throw new Error('PUNTIA_STORAGE_BUCKET no configurado.');
  const client=new S3Client({region:config.region||'auto',endpoint:config.endpoint||undefined,forcePathStyle:config.forcePathStyle!==false,credentials:config.accessKeyId?{accessKeyId:config.accessKeyId,secretAccessKey:config.secretAccessKey}:undefined});
  return { async put(key,data){const safe=safeKey(key);const bytes=Buffer.from(data);await client.send(new PutObjectCommand({Bucket:bucket,Key:safe,Body:bytes,ContentType:config.contentType||'application/octet-stream'}));return assertObjectPutResult({key:safe,size:bytes.length});}, async get(key){const safe=safeKey(key);try{const r=await client.send(new GetObjectCommand({Bucket:bucket,Key:safe}));return Buffer.from(await r.Body.transformToByteArray());}catch(e){if(e?.$metadata?.httpStatusCode===404||e?.name==='NoSuchKey')return null;throw e;}}, async remove(key){const safe=safeKey(key);await client.send(new DeleteObjectCommand({Bucket:bucket,Key:safe}));return true;},async list(){const out=[];let token;do{const r=await client.send(new ListObjectsV2Command({Bucket:bucket,ContinuationToken:token}));for(const x of (r.Contents||[]))out.push({key:String(x.Key),size:Number(x.Size||0),etag:x.ETag||null,lastModified:x.LastModified||null});token=r.IsTruncated?r.NextContinuationToken:undefined;}while(token);return out;} };
}
module.exports={createS3ObjectStorage};
