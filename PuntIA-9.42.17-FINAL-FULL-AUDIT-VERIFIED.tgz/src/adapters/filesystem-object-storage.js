'use strict';
const fs=require('fs');
const path=require('path');
const {assertObjectPutResult}=require('../core/contracts');
function safeKey(key){const v=String(key||'').replace(/\\/g,'/');if(!v||v.startsWith('/')||v.includes('..')||v.length>300||v.includes('\0'))throw new Error('Clave de objeto inválida.');return v;}
function createFilesystemObjectStorage(root){
  const base=path.resolve(root);
  fs.mkdirSync(base,{recursive:true,mode:0o700});
  const resolveKey=k=>{const safe=safeKey(k),p=path.resolve(base,safe);if(!p.startsWith(base+path.sep))throw new Error('Ruta de objeto inválida.');return p;};
  return {
    async put(key,data){
      if(!Buffer.isBuffer(data)&&!(data instanceof Uint8Array))throw new TypeError('data debe ser Buffer o Uint8Array');
      const safe=safeKey(key),p=resolveKey(safe);fs.mkdirSync(path.dirname(p),{recursive:true,mode:0o700});
      const tmp=`${p}.${process.pid}.${Date.now()}.${Math.random().toString(16).slice(2)}.tmp`;
      fs.writeFileSync(tmp,Buffer.from(data),{mode:0o600});
      try{fs.renameSync(tmp,p)}catch(e){try{fs.rmSync(tmp,{force:true})}catch{}throw e;}
      return assertObjectPutResult({key:safe,size:Buffer.from(data).length});
    },
    async get(key){try{return fs.readFileSync(resolveKey(key));}catch(e){if(e.code==='ENOENT')return null;throw e;}},
    async remove(key){try{fs.unlinkSync(resolveKey(key));return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}},
    async list(){
      const out=[];
      function walk(dir,prefix=''){
        if(!fs.existsSync(dir))return;
        for(const ent of fs.readdirSync(dir,{withFileTypes:true})){
          const full=path.join(dir,ent.name),key=prefix?`${prefix}/${ent.name}`:ent.name;
          if(ent.isDirectory())walk(full,key);else{const st=fs.statSync(full);out.push({key,size:st.size,lastModified:st.mtime.toISOString(),etag:null});}
        }
      }
      walk(base);return out;
    }
  };
}
module.exports={createFilesystemObjectStorage};
