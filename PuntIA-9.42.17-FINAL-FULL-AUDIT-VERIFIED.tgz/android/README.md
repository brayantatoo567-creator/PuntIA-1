# PuntIA Android 9.42.17

- The Android wrapper targets the HTTPS URL supplied at build time through `PUNTIA_WEB_APP_URL`.
- The WebView allowlist is restricted to that exact HTTPS host and its subdomains.
- External HTTP/HTTPS links open in the system browser.
- Minimum Android: 10 (API 29). Target/compile: API 35.
- Release build: AGP 8.7.3 + Gradle 8.9 + JDK 17.

The production URL is injected at build time; no production domain is hard-coded in `MainActivity.java`.
