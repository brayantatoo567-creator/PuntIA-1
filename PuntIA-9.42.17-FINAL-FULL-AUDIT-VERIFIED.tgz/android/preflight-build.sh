#!/usr/bin/env bash
set -euo pipefail
command -v java >/dev/null || { echo 'ERROR: Java no encontrado'; exit 1; }
command -v gradle >/dev/null || { echo 'ERROR: Gradle no encontrado. Instala Gradle 8.9 o usa el workflow android-release.yml.'; exit 1; }
java -version
gradle --version | head -12
if [[ -z "${ANDROID_SDK_ROOT:-}" && -z "${ANDROID_HOME:-}" ]]; then
  echo 'ERROR: ANDROID_SDK_ROOT/ANDROID_HOME no configurado.'
  exit 1
fi
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME}}"
test -d "$SDK/platforms/android-35" || { echo 'ERROR: Android SDK platform 35 no instalada.'; exit 1; }
test -d "$SDK/build-tools/35.0.0" || { echo 'ERROR: Android Build Tools 35.0.0 no instaladas.'; exit 1; }
echo 'ANDROID_PREFLIGHT: PASS'
