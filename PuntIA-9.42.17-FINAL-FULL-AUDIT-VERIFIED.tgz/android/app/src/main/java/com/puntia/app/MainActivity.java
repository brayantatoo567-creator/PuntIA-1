package com.puntia.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class MainActivity extends Activity {
    private static final String WEB_APP_URL = BuildConfig.WEB_APP_URL.endsWith("/") ? BuildConfig.WEB_APP_URL : BuildConfig.WEB_APP_URL + "/";
    private static final String TRUSTED_HOST = Uri.parse(WEB_APP_URL).getHost();
    private static final int REQUEST_MICROPHONE = 4101;
    private WebView web;
    private PermissionRequest pendingPermissionRequest;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            settings.setAllowFileAccessFromFileURLs(false);
            settings.setAllowUniversalAccessFromFileURLs(false);
        }
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) settings.setSafeBrowsingEnabled(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " PuntIAAndroid/9.42.17");

        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    Uri origin = request.getOrigin();
                    if (origin == null || !"https".equalsIgnoreCase(origin.getScheme()) || !TRUSTED_HOST.equalsIgnoreCase(origin.getHost())) {
                        request.deny();
                        return;
                    }
                    boolean audioRequested = false;
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) { audioRequested = true; break; }
                    }
                    if (!audioRequested) { request.deny(); return; }
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingPermissionRequest = request;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MICROPHONE);
                    }
                });
            }
        });

        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return routeUrl(request.getUrl()); }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return routeUrl(Uri.parse(url)); }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && view.getUrl() == null) view.loadUrl(WEB_APP_URL);
            }
            @Override public void onSafeBrowsingHit(WebView view, WebResourceRequest request, int threatType, SafeBrowsingResponse callback) { callback.backToSafety(true); }
        });
        setContentView(web);
        if (state == null) web.loadUrl(WEB_APP_URL); else web.restoreState(state);
    }

    private boolean routeUrl(Uri uri) {
        if (uri == null) return true;
        String scheme = String.valueOf(uri.getScheme());
        String host = String.valueOf(uri.getHost());
        if ("https".equalsIgnoreCase(scheme) && (TRUSTED_HOST.equalsIgnoreCase(host) || host.endsWith("." + TRUSTED_HOST))) return false;
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) return true;
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) {}
        return true;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_MICROPHONE || pendingPermissionRequest == null) return;
        PermissionRequest request = pendingPermissionRequest; pendingPermissionRequest = null;
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE}); else request.deny();
    }

    @Override protected void onSaveInstanceState(Bundle outState) { if (web != null) web.saveState(outState); super.onSaveInstanceState(outState); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (pendingPermissionRequest != null) { pendingPermissionRequest.deny(); pendingPermissionRequest = null; } if (web != null) { web.stopLoading(); web.setWebChromeClient(null); web.setWebViewClient(null); web.removeAllViews(); web.destroy(); web = null; } super.onDestroy(); }
}
