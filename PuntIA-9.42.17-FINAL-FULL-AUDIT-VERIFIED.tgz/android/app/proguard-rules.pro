# PuntIA: no reflection-based native bridge is used. Keep rules remain intentionally empty.
