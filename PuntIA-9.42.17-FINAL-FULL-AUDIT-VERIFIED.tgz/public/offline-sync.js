'use strict';
(function(global){
  const KEY='puntia.sync.queue.v2';
  const load=()=>{try{const v=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(v)?v:[]}catch{return[]}};
  const save=q=>localStorage.setItem(KEY,JSON.stringify(q));
  const idempotency=()=>global.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const normalizeOwner=owner=>String(owner||'guest').trim()||'guest';
  async function enqueue(operation){
    const q=load();
    const item={queueId:idempotency(),createdAt:new Date().toISOString(),attempts:0,state:'pending',ownerKey:normalizeOwner(operation?.ownerKey),...operation};
    item.ownerKey=normalizeOwner(item.ownerKey);
    if(!item.id) throw new Error('La operación offline requiere id.');
    q.push(item); save(q); return item;
  }
  async function flush(fetcher, ownerKey='guest'){
    if(!navigator.onLine) return {ok:false,offline:true,processed:0};
    const owner=normalizeOwner(ownerKey); const q=load(); let processed=0, conflicts=0, skipped=0;
    for(const item of q){
      if(item.ownerKey!==owner){skipped++;continue;}
      if(item.state==='synced') continue;
      item.state='syncing'; item.attempts++;
      try { const result=await fetcher(item); if(result?.status==='conflict') {item.state='conflict';conflicts++;} else {item.state='synced';processed++;} }
      catch(error){item.state='failed';item.error=String(error?.message||error);break;}
      save(q);
    }
    save(q.filter(x=>x.state!=='synced'));
    return {ok:conflicts===0,processed,conflicts,skipped,pending:load().length};
  }
  global.PuntIAOfflineSync={enqueue,flush,pending:(ownerKey)=>{const owner=normalizeOwner(ownerKey);return load().filter(x=>x.ownerKey===owner)},pendingAll:()=>load()};
})(window);
