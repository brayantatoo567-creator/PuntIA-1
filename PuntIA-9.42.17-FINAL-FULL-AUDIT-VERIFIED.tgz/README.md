# PuntIA

PuntIA es una aplicación web/PWA para crear, validar, editar, aprender y organizar patrones de crochet/amigurumi con asistencia de IA.

## Producto

- Generación de patrones estructurados.
- Descomposición de conceptos y planificación de piezas.
- Ejecución matemática y Quality Gate antes de entregar patrones.
- Editor determinista de patrones.
- Lector y tutor didáctico.
- Generación/validación visual.
- Proyectos, sincronización offline y resolución de conflictos.
- Asistente contextual, memoria y voz del navegador.
- Planes Free, Premium y Pro con control de uso y Stripe.
- Persistencia local para desarrollo y PostgreSQL/Redis/S3 para cloud.

## Arquitectura

`routes -> application services -> core/domain -> adapters/infrastructure`

En cloud, PostgreSQL es la fuente de verdad para identidad, sesiones, proyectos, jobs, billing, feedback, memoria y auditoría. Redis gestiona cola/bloqueos distribuidos y S3-compatible gestiona objetos.

## Desarrollo local

Requisitos: Node.js 20+.

```bash
npm install
npm run verify:clean
npm run audit:release
npm start
```

Por defecto el servidor local usa `127.0.0.1:8080`.

## Producción

Producción requiere `PUNTIA_CLOUD_MODE=true`, PostgreSQL, Redis, almacenamiento de objetos, HTTPS y las credenciales administrativas/configuración definidas en `.env.example`.

```bash
npm run preflight:production
npm run verify:clean
npm run audit:release
```

El despliegue físico de Android requiere Android SDK/Gradle; el pipeline CI valida el APK/AAB firmado.

## Calidad

No se debe publicar un patrón sin pasar el Quality Gate. Las regresiones de las capas funcionales y de infraestructura están integradas en `npm run verify:clean`.

## Seguridad

Los secretos de OpenAI/Stripe no se incluyen en el repositorio. En cloud, identidad y sesiones son persistentes en PostgreSQL; las cookies de sesión son `HttpOnly` y se aplican CSRF/origin checks en producción.
