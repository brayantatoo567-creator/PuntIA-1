'use strict';
const assert=require('node:assert/strict');
const {createPostgresRepository}=require('../src/adapters/postgres-repository');
const {normalizeProjectInput}=require('../src/core/contracts');
const owner='cloud-fn-user';
const rows=[];
const versions=[];
function rowFrom(candidate){return {id:candidate.id,user_id:candidate.ownerId,name:candidate.title,status:candidate.status,progress:candidate.progress,pattern:candidate.pattern,image_url:candidate.image||null,data:candidate,version:candidate.version,created_at:candidate.createdAt,updated_at:candidate.updatedAt};}
const pool={
  async query(sql,args){
    if(['BEGIN','COMMIT','ROLLBACK'].includes(sql)) return {rows:[],rowCount:0};
    if(sql.includes("SELECT * FROM projects WHERE user_id=$1 AND data->>'lastMutationKey'=$2")){const x=rows.find(r=>r.user_id===args[0]&&r.data?.lastMutationKey===args[1]);return {rows:x?[x]:[],rowCount:x?1:0};}
    if(sql.includes('SELECT * FROM projects WHERE id=$1 AND user_id=$2')){const x=rows.find(r=>r.id===args[0]&&r.user_id===args[1]);return {rows:x?[x]:[],rowCount:x?1:0};}
    if(sql.includes('SELECT * FROM projects WHERE user_id=$1'))return {rows:rows.filter(r=>r.user_id===args[0]),rowCount:rows.filter(r=>r.user_id===args[0]).length};
    if(sql.startsWith('INSERT INTO projects')){rows.push({id:args[0],user_id:args[1],name:args[2],status:args[3],progress:args[4],pattern:args[5],image_url:args[6],data:JSON.parse(args[7]),version:JSON.parse(args[7]).version,created_at:JSON.parse(args[7]).createdAt,updated_at:JSON.parse(args[7]).updatedAt});return {rows:[],rowCount:1};}
    if(sql.startsWith('DELETE FROM projects')){const i=rows.findIndex(r=>r.id===args[0]&&r.user_id===args[1]);if(i>=0){rows.splice(i,1);return {rows:[],rowCount:1}}return {rows:[],rowCount:0};}
    if(sql.startsWith('INSERT INTO project_versions')){versions.push(args);return {rows:[],rowCount:1};}
    if(sql.startsWith('UPDATE projects')){const r=rows.find(r=>r.id===args[0]&&r.user_id===args[1]);r.name=args[2];r.status=args[3];r.progress=args[4];r.pattern=args[5];r.image_url=args[6];r.data=JSON.parse(args[7]);r.version=args[8];r.updated_at=new Date().toISOString();return {rows:[],rowCount:1};}
    throw new Error('Unhandled SQL: '+sql);
  },
  async connect(){return this}, release(){},
};
(async()=>{
 const repo=await createPostgresRepository({pool});
 const base=normalizeProjectInput({id:'cloud-p1',title:'Cloud Project',description:'keep me',level:'Intermedio',status:'pattern_ready',pattern:'{"x":1}',idempotencyKey:'create-cloud-1'}, {}, owner);
 const created=await repo.create(base,owner); assert.equal(created.title,'Cloud Project'); assert.equal(created.description,'keep me');
 const replay=await repo.create({...base,title:'SHOULD NOT REPLACE'},owner); assert.equal(replay.id,created.id); assert.equal(replay.title,'Cloud Project');
 const updated=await repo.update(created.id,{description:'updated',progress:40,expectedVersion:1,idempotencyKey:'update-cloud-1'},owner); assert.equal(updated.version,2); assert.equal(updated.title,'Cloud Project'); assert.equal(updated.level,'Intermedio'); assert.equal(updated.description,'updated'); assert.equal(updated.pattern,'{"x":1}');
 console.log('PROJECT_CLOUD_DEFAULTS_PRESERVED: PASS');
 console.log('PROJECT_CLOUD_IDEMPOTENCY: PASS');
 console.log('PROJECT_CLOUD_PARTIAL_UPDATE: PASS');
})().catch(e=>{console.error('PROJECT_CLOUD_FUNCTION: FAIL');console.error(e.stack||e);process.exit(1)});
