'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createFileAuditSink } = require('../src/adapters/file-audit-sink');
const { createAuditService } = require('../src/application/audit-service');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'puntia-audit-'));
  const file = path.join(dir, 'audit.jsonl');
  const sink = createFileAuditSink(file);
  const audit = createAuditService({ auditSink: sink });

  await audit.record({action:'pattern.generation.started',resourceType:'pattern',resourceId:'p1',actorId:'u1',correlationId:'req-1',metadata:{model:'gpt-test',prompt:'NO DEBE GUARDARSE',apiKey:'sk-super-secret',nested:{ok:true}}});
  await audit.record({action:'pattern.generation.approved',resourceType:'pattern',resourceId:'p1',actorId:'u1',correlationId:'req-1',metadata:{attempts:2,model:'gpt-test',usage:'confirmed'}});
  await audit.record({action:'visual.validation.completed',resourceType:'pattern-visual',resourceId:'a1',actorId:'u1',correlationId:'req-2',status:'rejected',metadata:{confidence:.42}});

  const rows = await audit.list(10);
  assert.equal(rows.length, 3);
  assert.equal(rows[0].action, 'visual.validation.completed');
  const raw = fs.readFileSync(file, 'utf8');
  assert.ok(!raw.includes('NO DEBE GUARDARSE'));
  assert.ok(!raw.includes('sk-super-secret'));
  const verified = await audit.verify();
  assert.equal(verified.ok, true);
  assert.equal(verified.count, 3);

  fs.appendFileSync(file, '{"tampered":true}\n');
  const broken = await audit.verify();
  assert.equal(broken.ok, false);

  console.log('Capa 20 regression: PASS');
})().catch(error => { console.error(error); process.exit(1); });
