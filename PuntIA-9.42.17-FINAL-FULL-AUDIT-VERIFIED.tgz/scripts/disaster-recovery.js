'use strict';
const path=require('path');
const {createDisasterRecoveryService}=require('../src/application/disaster-recovery-service');
const dr=createDisasterRecoveryService();
const cmd=process.argv[2];
(async()=>{
  if(cmd==='plan'){console.log(JSON.stringify(dr.recoveryPlan(),null,2));return;}
  if(cmd==='backup-db'){const r=await dr.databaseBackup({databaseUrl:process.env.DATABASE_URL,outputDir:process.env.PUNTIA_BACKUP_DIR||path.resolve('.puntia-backups')});console.log(JSON.stringify(r,null,2));return;}
  if(cmd==='verify-db'){const r=await dr.verifyDatabaseBackup({file:process.argv[3]});console.log(JSON.stringify(r,null,2));if(!r.ok)process.exitCode=2;return;}
  if(cmd==='restore-db'){const r=await dr.restoreDatabase({databaseUrl:process.env.DATABASE_URL,backupFile:process.argv[3],confirmRestore:process.env.PUNTIA_RESTORE_CONFIRM==='YES'});console.log(JSON.stringify(r,null,2));return;}
  throw new Error('Uso: plan | backup-db | verify-db <file> | restore-db <file>');
})().catch(e=>{console.error(`DR: FAIL ${e.message}`);process.exitCode=1;});
