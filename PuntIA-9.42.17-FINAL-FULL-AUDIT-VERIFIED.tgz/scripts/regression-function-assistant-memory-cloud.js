'use strict';
const assert=require('node:assert/strict');
const {createPostgresMemoryRepository}=require('../src/adapters/postgres-memory-repository');
const rows={conversations:new Map(),patterns:new Map()};
const pool={
  async query(sql,p=[]){
    if(/INSERT INTO assistant_conversations/i.test(sql)){rows.conversations.set(p[0],{id:p[0],user_id:p[1],title:p[2],turns:JSON.parse(p[3]),created_at:p[4],updated_at:p[5]});return {rows:[],rowCount:1};}
    if(/SELECT \* FROM assistant_conversations WHERE user_id=\$1 AND id=\$2/i.test(sql)){const r=rows.conversations.get(p[1]);return {rows:r&&r.user_id===p[0]?[r]:[],rowCount:r&&r.user_id===p[0]?1:0};}
    if(/SELECT \* FROM assistant_conversations WHERE user_id=\$1 ORDER BY/i.test(sql)){const a=[...rows.conversations.values()].filter(r=>r.user_id===p[0]).sort((a,b)=>String(b.updated_at).localeCompare(String(a.updated_at)));return {rows:a.slice(0,1),rowCount:Math.min(1,a.length)};}
    if(/INSERT INTO assistant_patterns/i.test(sql)){const key=p[1]+'|'+p[4];rows.patterns.set(key,{id:p[0],user_id:p[1],name:p[2],pattern:JSON.parse(p[3]),pattern_hash:p[4],model:p[5],project_id:p[6],created_at:p[7]});return {rows:[],rowCount:1};}
    if(/SELECT id,user_id,name,pattern_hash/i.test(sql)){const a=[...rows.patterns.values()].filter(r=>r.user_id===p[0]).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at)));return {rows:a.slice(0,Number(p[1])||20),rowCount:a.length};}
    return {rows:[],rowCount:0};
  },
  async connect(){return {query:async(sql,p=[])=>{if(/DELETE FROM assistant_conversations/i.test(sql)){let n=0;for(const [k,v] of rows.conversations){if(v.user_id===p[0]){rows.conversations.delete(k);n++;}}return {rowCount:n};}if(/DELETE FROM assistant_patterns/i.test(sql)){let n=0;for(const [k,v] of rows.patterns){if(v.user_id===p[0]){rows.patterns.delete(k);n++;}}return {rowCount:n};}return {rowCount:0};},release(){}};}
};
(async()=>{const repo=createPostgresMemoryRepository({pool});const conversation={id:'c1',ownerId:'u1',title:'Clase',turns:[{role:'user',text:'Hola'}],createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};await repo.upsertConversation('u1',conversation);assert.equal((await repo.getConversation('u1','c1')).title,'Clase');await repo.addPattern('u1',{id:'p1',name:'Dragón',pattern:'{"title":"Dragón"}',patternHash:'hash1',model:'test',projectId:'',createdAt:new Date().toISOString()});assert.equal((await repo.listPatterns('u1',20)).length,1);assert.equal((await repo.listPatterns('u2',20)).length,0);assert.equal(await repo.deleteUser('u1'),2);assert.equal((await repo.getConversation('u1','c1')),null);assert.equal((await repo.listPatterns('u1',20)).length,0);await repo.close();console.log('ASSISTANT_MEMORY_CLOUD_REPOSITORY: PASS');})().catch(e=>{console.error('ASSISTANT_MEMORY_CLOUD_REPOSITORY: FAIL');console.error(e.stack||e);process.exit(1)});
