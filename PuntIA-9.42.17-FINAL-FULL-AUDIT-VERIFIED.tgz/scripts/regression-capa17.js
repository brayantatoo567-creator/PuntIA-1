'use strict';
const assert=require('node:assert/strict');
const {createPatternService}=require('../src/application/pattern-service');
const {createPatternVisualService}=require('../src/application/pattern-visual-service');
const {validatePattern,extractFirstJsonObject}=require('../src/core/pattern-engine');
const pattern={title:'Dragón tejido',initialStitches:6,materials:['hilo rojo','hilo negro'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],assembly:['unir alas y cola'],notes:['ojos negros'],geometry:{type:'body',targetHeightCm:12}};
let confirmed=0,released=0,cost=0,put=0;
const deps={runtime:{imageModel:'img-test'},IMAGE_MODEL_DEFAULT:'img-test',IMAGE_SIZE:'1024x1024',validatePattern,extractFirstJsonObject,estimateCost:()=>.04,recordCost:()=>cost++,async openaiPost(path,payload){assert.equal(path,'images/generations');assert.match(payload.prompt,/Dragón tejido/);assert.match(payload.prompt,/hilo rojo/);assert.match(payload.prompt,/12 cm/);return {model:'img-test',data:[{b64_json:Buffer.from('fakepng').toString('base64')}]};},objectStorage:{async put(key,data){put++;assert.match(key,/pattern-visuals/);return {key,size:data.length};}}};
const services={usage:{async reserve(){return {allowed:true,reservationId:'img-r',limit:10}},async confirm(){confirmed++},async release(){released++}},patternVisualValidation:{async validate({pattern:checkedPattern,image,patternHash}){assert.equal(checkedPattern.title,pattern.title);assert.match(image,/^data:image\/png;base64,/);assert.equal(patternHash,visualHash(checkedPattern));return {ok:true,accepted:true,threshold:.8,patternHash,validation:{matchesPattern:true,confidence:.95,criticalMismatches:[],observations:[]},model:'vision-test'};}}};
function visualHash(p){const crypto=require('crypto');return crypto.createHash('sha256').update(JSON.stringify(p)).digest('hex');}
const visual=createPatternVisualService(deps,services);
(async()=>{
 const a=await visual.generate({user:{id:'u17'},pattern,prompt:'fondo limpio'});
 assert.equal(a.ok,true);assert.equal(a.binding,'validated-pattern');assert.equal(a.patternHash,visual.hashPattern(pattern));assert.equal(confirmed,1);assert.equal(released,0);assert.equal(cost,1);assert.equal(put,1);
 const bad={...pattern,rounds:pattern.rounds.map(r=>({...r}))};bad.rounds[1].expectedStitches=11;
 await assert.rejects(()=>visual.generate({user:{id:'u17'},pattern:bad}),e=>e.code==='PATTERN_QUALITY_GATE');
 assert.equal(confirmed,1);assert.equal(put,1);
 console.log('CAPA17_VALIDATED_PATTERN_REQUIRED: PASS');
 console.log('CAPA17_PROMPT_BOUND_TO_PATTERN: PASS');
 console.log('CAPA17_PATTERN_HASH_BINDING: PASS');
 console.log('CAPA17_STORAGE_METADATA_BINDING: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1)});
