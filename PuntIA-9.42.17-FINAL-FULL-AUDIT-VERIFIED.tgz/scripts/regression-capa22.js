'use strict';
const assert = require('assert');
const { createHttpSecurity } = require('../src/infrastructure/http/middleware/security');

function response() {
  return { headers: {}, statusCode: 200, ended: false, setHeader(k,v){this.headers[k]=v;}, end(){this.ended=true;} };
}

async function main(){
  let requests = 0;
  const security = createHttpSecurity({
    requestId: () => 'security-test',
    cors: () => true,
    rateLimit: () => { requests++; return true; },
    requireCsrf: () => true,
    pSafeOrigin: () => true,
    requireOriginOnMutations: true,
    maxUrlLength: 32
  });

  let res=response();
  let ok=await security.before({url:'/api/health',method:'GET',headers:{}},res);
  assert.strictEqual(ok,true);
  assert.strictEqual(res.headers['X-Request-ID'],'security-test');
  assert.strictEqual(requests,1);

  res=response();
  ok=await security.before({url:'/api/health?'+('x'.repeat(40)),method:'GET',headers:{}},res);
  assert.strictEqual(ok,false);
  assert.strictEqual(res.statusCode,414);

  res=response();
  ok=await security.before({url:'/api/health',method:'TRACE',headers:{}},res);
  assert.strictEqual(ok,false);
  assert.strictEqual(res.statusCode,405);
  assert.ok(res.headers.Allow.includes('GET'));

  let familyKey;
  const hardened = createHttpSecurity({
    requestId: ()=>'id', cors:()=>true, requireCsrf:()=>true, pSafeOrigin:()=>true,
    requireOriginOnMutations:false, maxUrlLength:100,
    rateLimit(req, r){ familyKey = `${req.socket?.remoteAddress || 'x'}:${req.method}:${new URL(req.url,'http://x').pathname.startsWith('/api/puntia/')?'/api/puntia':new URL(req.url,'http://x').pathname}`; return true; }
  });
  res=response();
  await hardened.before({url:'/api/puntia/generate-pattern',method:'POST',headers:{} ,socket:{remoteAddress:'1.2.3.4'}},res);
  assert.strictEqual(familyKey,'1.2.3.4:POST:/api/puntia');

  console.log('Capa 22 regression: PASS');
}
main().catch(e=>{console.error(e);process.exit(1);});
