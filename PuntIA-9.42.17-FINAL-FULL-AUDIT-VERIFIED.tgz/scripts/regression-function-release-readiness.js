'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');
const root=process.cwd();
function walk(dir,out=[]){for(const n of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','.git','.puntia-data','android/.gradle'].some(x=>path.resolve(dir,n.name).includes(path.resolve(root,x))))continue;const p=path.join(dir,n.name);if(n.isDirectory())walk(p,out);else out.push(p)}return out}
const js=walk(root).filter(f=>f.endsWith('.js'));
for(const f of js){const r=cp.spawnSync(process.execPath,['--check',f],{encoding:'utf8'});assert.equal(r.status,0,`syntax: ${path.relative(root,f)}\n${r.stderr}`)}
const html=fs.readFileSync('index.html','utf8');
assert.match(html,/href="\/css\/app\.css"/,'missing CSS reference'); assert.match(html,/src="\/js\/app\.js"/,'missing JS reference'); assert.match(html,/src="\/offline-sync\.js"/,'missing offline reference'); assert.match(html,/assets\/mascot\/puntia-maestra-v2\.svg/,'missing mascot reference');
for(const f of ['Dockerfile','.dockerignore','manifest.webmanifest','sw.js','public/offline-sync.js','android/README.md','android/app/proguard-rules.pro'])assert(fs.existsSync(f),`missing ${f}`);
const env=fs.existsSync('.env.example')?fs.readFileSync('.env.example','utf8'):'';assert(!env.match(/OPENAI_API_KEY\s*=\s*sk-[A-Za-z0-9]{10,}/),'real-looking API key in env example'); const gradle=fs.readFileSync('android/app/build.gradle','utf8'); const android=fs.readFileSync('android/app/src/main/java/com/puntia/app/MainActivity.java','utf8'); assert.match(gradle,/minifyEnabled true/); assert.match(gradle,/shrinkResources true/); assert.match(gradle,/proguard-rules\.pro/); assert.match(android,/setAllowFileAccessFromFileURLs\(false\)/); assert.match(android,/setAllowUniversalAccessFromFileURLs\(false\)/); assert.match(android,/onPermissionRequest/); assert.match(android,/RESOURCE_AUDIO_CAPTURE/);
console.log(`RELEASE_SYNTAX_${js.length}_FILES: PASS`);console.log('RELEASE_ASSET_REFERENCES: PASS');console.log('RELEASE_SECRET_SCAN: PASS');console.log('RELEASE_ARTIFACTS: PASS');console.log('RELEASE_READINESS: PASS');
