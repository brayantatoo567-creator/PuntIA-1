'use strict';
const assert = require('node:assert/strict');
const { interpretConcept, conceptPromptBlock, validateConceptCoverage } = require('../src/core/concept-decomposition');
const { createPatternService } = require('../src/application/pattern-service');
const { createPatternGenerationPipeline } = require('../src/application/pattern-generation-pipeline');
const { validatePattern } = require('../src/core/pattern-engine');

const deps={
  safeText:(v,n)=>String(v??'').slice(0,n), validatePattern,
  extractFirstJsonObject:JSON.parse, SYSTEM:'TEST', PATTERN_MODEL:'p', CHAT_MODEL:'f', runtime:{},
  outputText:d=>d.output_text, openaiPostModelFallback:async()=>({model:'test',data:{output_text:JSON.stringify({title:'Dragon',initialStitches:6,materials:['hilo'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],assembly:['Cuerpo principal','Cabeza','Alas','Cola'],notes:[],geometry:{type:'body',targetHeightCm:15}})}})
};
function services(){return {pattern:createPatternService(deps),usage:{reserve:async()=>({allowed:true,reservationId:'r'}),confirm:async()=>{},release:async()=>{}},audit:{record:async()=>{}},observability:{run:async(_n,fn)=>fn()}}}

const concept=interpretConcept({description:'Dragón cósmico azul con alas, cuernos, cola y ojos de 15 cm'});
assert.equal(concept.category,'fantasy');
assert.deepEqual(concept.colors,['azul']);
for (const id of ['body','head','eyes','wings','tail','horns']) assert.ok(concept.pieces.some(p=>p.id===id),`falta pieza ${id}`);
assert.equal(concept.dimensions.heightCm,15);
assert.equal(concept.requiresClarification,false);
console.log('CONCEPT_INTERPRETATION: PASS');

const block=conceptPromptBlock(concept);
const parsed=JSON.parse(block);
assert.equal(parsed.subject,concept.subject); assert.equal(parsed.pieces.length,concept.pieces.length);
console.log('CONCEPT_STRUCTURED_CONTRACT: PASS');

assert.equal(validateConceptCoverage(concept,{assembly:['unir alas y cola'],notes:[]}).ok,true);
assert.equal(validateConceptCoverage(concept,{assembly:['unir cuerpo'],notes:[]}).ok,false);
console.log('CONCEPT_PATTERN_COVERAGE_GATE: PASS');

assert.throws(()=>interpretConcept({description:'   '}),e=>e.code==='CONCEPT_DESCRIPTION_REQUIRED');
console.log('CONCEPT_REJECTS_EMPTY_INPUT: PASS');

const custom=interpretConcept({description:'criatura inventada'});
assert.equal(custom.category,'custom'); assert.equal(custom.requiresClarification,true);
console.log('CONCEPT_CUSTOM_AMBIGUITY: PASS');

(async()=>{
  const p=createPatternGenerationPipeline(deps,services());
  const r=await p.generate({user:{id:'u'},input:{name:'Dragón cósmico azul con alas y cola',height:'15'}});
  assert.equal(r.ok,true); assert.equal(r.concept.category,'fantasy'); assert.ok(r.concept.pieces.some(x=>x.id==='wings'));
  assert.equal(r.validation.qualityOk,true);
  console.log('CONCEPT_PIPELINE_INTEGRATION: PASS');
  console.log('CONCEPT_DECOMPOSITION_FUNCTION: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1);});
