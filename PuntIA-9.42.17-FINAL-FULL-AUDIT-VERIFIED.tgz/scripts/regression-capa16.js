'use strict';
const assert = require('node:assert/strict');
const { createPatternService } = require('../src/application/pattern-service');
const { createPatternGenerationPipeline } = require('../src/application/pattern-generation-pipeline');
const { validatePattern, extractFirstJsonObject } = require('../src/core/pattern-engine');

const valid = () => ({
  title:'Capa 16', initialStitches:6, materials:['hilo'], abbreviations:['pb'],
  rounds:[
    {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
    {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}
  ], assembly:['unir'], notes:[], geometry:{type:'sphere',targetHeightCm:8}
});
const invalid = () => { const p=valid(); p.rounds[1].expectedStitches=11; return p; };

let calls=0, reserved=0, confirmed=0, released=0, persisted=0, costs=0;
const deps = {
  SYSTEM:'PUNTIA_TEST', PATTERN_MODEL:'primary', CHAT_MODEL:'fallback', runtime:{patternModel:'primary',textModel:'fallback'},
  safeText:(v,n)=>String(v??'').slice(0,n),
  validatePattern, extractFirstJsonObject, outputText:(data)=>data?.output_text||'',
  recordCost:()=>{costs++;}, estimateCost:()=>1,
  async openaiPostModelFallback(){
    calls++;
    const payload = calls===1 ? invalid() : valid();
    return { model:'fake-test-model', fallback:false, data:{ output_text:JSON.stringify(payload) } };
  },
  async persistApprovedPattern(){ persisted++; }
};
const pattern = createPatternService(deps);
const services = {
  pattern,
  usage:{
    async reserve(){ reserved++; return {allowed:true,reservationId:'r16',limit:100}; },
    async confirm(){ confirmed++; return {ok:true,state:'confirmed'}; },
    async release(){ released++; return {ok:true,state:'released'}; }
  }
};
const pipeline = createPatternGenerationPipeline(deps, services);

(async()=>{
  const result = await pipeline.generate({user:{id:'u16'},input:{name:'Dragón',level:'Principiante'},persist:true});
  assert.equal(result.ok,true);
  assert.equal(result.repaired,true);
  assert.equal(result.attempts,2);
  assert.equal(result.validation.qualityOk,true);
  assert.equal(calls,2);
  assert.equal(reserved,1);
  assert.equal(confirmed,1);
  assert.equal(released,0);
  assert.equal(persisted,1);
  assert.equal(costs,1);

  let rejectedCalls=0;
  const badDeps={...deps, async openaiPostModelFallback(){rejectedCalls++;return {model:'fake',data:{output_text:JSON.stringify(invalid())}}}, async persistApprovedPattern(){throw new Error('NO_PERSIST');}};
  const badServices={...services,pattern:createPatternService(badDeps),usage:{...services.usage,async reserve(){return {allowed:true,reservationId:'bad-r'}},async release(){released++;return {ok:true}}}};
  const badPipeline=createPatternGenerationPipeline(badDeps,badServices);
  await assert.rejects(()=>badPipeline.generate({user:{id:'u16'},input:{name:'Fallo'}}),e=>e.code==='PATTERN_QUALITY_GATE');
  assert.equal(rejectedCalls,3);
  assert.equal(persisted,1);

  console.log('CAPA16_PIPELINE_SINGLE_PATH: PASS');
  console.log('CAPA16_AI_CANNOT_BYPASS_VALIDATION: PASS');
  console.log('CAPA16_REPAIR_REVALIDATION: PASS');
  console.log('CAPA16_PERSIST_ONLY_AFTER_APPROVAL: PASS');
  console.log('CAPA16_USAGE_ACCOUNTING: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1);});
