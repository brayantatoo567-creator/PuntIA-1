'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');

const required=[
  'manifest.webmanifest','sw.js','public/offline-sync.js',
  'android/settings.gradle','android/build.gradle','android/app/build.gradle',
  'android/app/src/main/AndroidManifest.xml',
  'android/app/src/main/java/com/puntia/app/MainActivity.java',
  'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
  'android/app/src/main/res/drawable/ic_launcher_foreground.png',
  'android/app/src/main/res/values/colors.xml','Dockerfile','.dockerignore'
];
for(const f of required) assert(fs.existsSync(f),`missing ${f}`);

const manifest=fs.readFileSync('android/app/src/main/AndroidManifest.xml','utf8');
assert(manifest.includes('RECORD_AUDIO'));
assert(manifest.includes('android:exported="true"'));
assert(manifest.includes('android:icon="@mipmap/ic_launcher"'));
assert(manifest.includes('android:roundIcon="@mipmap/ic_launcher"'));
assert(manifest.includes('android:usesCleartextTraffic="false"'));

const gradle=fs.readFileSync('android/app/build.gradle','utf8');
assert(gradle.includes('minSdk 29'));
assert(gradle.includes('targetSdk 35'));
assert(gradle.includes('compileSdk 35'));
assert(gradle.includes("versionName '9.42.17'"));
assert(gradle.includes('signingConfigs'));
assert(gradle.includes('PUNTIA_RELEASE_STORE_FILE'));
assert(gradle.includes('minifyEnabled true'));
assert(gradle.includes('shrinkResources true'));
assert(gradle.includes('PUNTIA_WEB_APP_URL'));

for(const dir of ['mipmap-mdpi','mipmap-hdpi','mipmap-xhdpi','mipmap-xxhdpi','mipmap-xxxhdpi']) {
  const icon=path.join('android/app/src/main/res',dir,'ic_launcher.png');
  assert(fs.existsSync(icon),`legacy launcher icon missing: ${icon}`);
  assert(fs.statSync(icon).size>100,`legacy launcher icon empty: ${icon}`);
}
const launcherXml=fs.readFileSync('android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml','utf8');
assert(launcherXml.includes('@drawable/ic_launcher_foreground'));
assert(launcherXml.includes('@color/puntia_icon_background'));

const java=fs.readFileSync('android/app/src/main/java/com/puntia/app/MainActivity.java','utf8');
assert(java.includes('setAllowFileAccessFromFileURLs(false)'));
assert(java.includes('setAllowUniversalAccessFromFileURLs(false)'));
assert(java.includes('onPermissionRequest'));
assert(java.includes('RESOURCE_AUDIO_CAPTURE'));
assert(java.includes('MIXED_CONTENT_NEVER_ALLOW'));
assert(java.includes('SafeBrowsingResponse'));

const workflow=fs.readFileSync('.github/workflows/android-release.yml','utf8');
assert(workflow.includes("gradle-version: '8.9'"));
assert(workflow.includes('PUNTIA_WEB_APP_URL'));
assert(workflow.includes('assembleDebug assembleRelease'));
assert(workflow.includes('bundleRelease'));
assert(workflow.includes('app-release.apk'));
assert(workflow.includes('app-release.aab'));
assert(!workflow.includes('app-release-unsigned.apk'));

console.log('PWA_PACKAGE: PASS');
console.log('ANDROID_WRAPPER_SOURCE: PASS');
console.log('ANDROID_API29_COMPATIBILITY: PASS');
console.log('LEGACY_LAUNCHER_ICONS: PASS');
console.log('ANDROID_RELEASE_PIPELINE: PASS');
console.log('DOCKER_RUNTIME: PASS');
console.log('PACKAGING_FUNCTION: PASS');
