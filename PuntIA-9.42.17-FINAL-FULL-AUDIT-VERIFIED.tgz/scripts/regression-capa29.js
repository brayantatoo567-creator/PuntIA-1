'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createPrivacyService } = require('../src/application/privacy-service');
const { createFileAuditSink } = require('../src/adapters/file-audit-sink');

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'puntia-capa29-'));
  const files = Object.fromEntries(['users','sessions','reset-tokens','jobs','usage','reservations','tombstones','events'].map(n => [n, path.join(dir, `${n}.json${n==='events'? 'l':''}`)]));
  const projectsFile = path.join(dir,'projects.json');
  const auditFile = path.join(dir,'audit.jsonl');
  const userId='u-delete';
  const auditSink=createFileAuditSink(auditFile);
  const save=(file,v)=>fs.writeFileSync(file,JSON.stringify(v,null,2));
  save(files.users,[{id:userId,email:'delete@example.com'},{id:'keep',email:'keep@example.com'}]);
  save(files.sessions,{'a':{userId},'b':{userId:'keep'}});
  save(files['reset-tokens'],{'t':{userId},'k':{userId:'keep'}});
  save(files.jobs,{'j1':{id:'j1',ownerId:userId},'j2':{id:'j2',ownerId:'keep'}});
  save(files.usage,{[`${userId}:2026-10-01`]:{userId,pattern:2},['keep:2026-10-01']:{userId:'keep',pattern:1}});
  save(files.reservations,{'r1':{userId},'r2':{userId:'keep'}});
  save(files.tombstones,{'x':{ownerId:userId,id:'p1'},'y':{ownerId:'keep',id:'p2'}});
  fs.writeFileSync(files.events,JSON.stringify({id:'e1',userId,name:'account.test'})+'\n'+JSON.stringify({id:'e2',userId:'keep',name:'keep'})+'\n');
  save(projectsFile,[{id:'p1',ownerId:userId,assets:[{key:`users/${userId}/pattern-visuals/a.png`}]},{id:'p2',ownerId:'keep',assets:[]}]);
  await auditSink.record({eventId:'a1',occurredAt:new Date().toISOString(),action:'project.created',resourceType:'project',resourceId:'p1',actorId:userId,correlationId:'c1',status:'success',metadata:{x:1}});
  await auditSink.record({eventId:'a2',occurredAt:new Date().toISOString(),action:'project.created',resourceType:'project',resourceId:'p2',actorId:'keep',correlationId:'c2',status:'success',metadata:{x:1}});
  const deps={
    USERS_FILE:files.users,SESSIONS_FILE:files.sessions,RESET_TOKENS_FILE:files['reset-tokens'],JOB_FILE:files.jobs,USAGE_FILE:files.usage,RESERVATIONS_FILE:files.reservations,SYNC_TOMBSTONES_FILE:files.tombstones,EVENTS_FILE:files.events,loadJsonFile:(f,d)=>{try{return JSON.parse(fs.readFileSync(f,'utf8'))}catch{return d}},saveJsonFile:save,loadProjects:()=>JSON.parse(fs.readFileSync(projectsFile,'utf8')),saveProjects:(v)=>save(projectsFile,v),auditSink,
    objectStorage:{removed:[],async remove(k){this.removed.push(k);return true;}},
  };
  const services={auth:{verifyPassword:(p,u)=>p==='correct'},audit:{record:async()=>{}}};
  const privacy=createPrivacyService(deps,services);
  const result=await privacy.deleteAccount({user:{id:userId,role:'user'},currentPassword:'correct',confirmation:'DELETE_ACCOUNT'});
  assert.equal(result.ok,true);
  assert.equal(JSON.parse(fs.readFileSync(files.users)).some(x=>x.id===userId),false);
  assert.equal(JSON.parse(fs.readFileSync(files.sessions)).a,undefined);
  assert.equal(JSON.parse(fs.readFileSync(files.jobs)).j1,undefined);
  assert.equal(JSON.parse(fs.readFileSync(projectsFile)).length,1);
  assert.equal(JSON.parse(fs.readFileSync(projectsFile))[0].ownerId,'keep');
  const eventLines=fs.readFileSync(files.events,'utf8').split('\n').filter(Boolean).map(JSON.parse); assert.equal(eventLines.length,1); assert.equal(eventLines[0].userId,'keep');
  assert.equal((await auditSink.verify()).ok,true);
  const rows=await auditSink.list(10);
  assert.ok(rows.some(x=>x.actorId===null && x.resourceId===null && x.metadata?.privacyRedacted));
  await assert.rejects(()=>privacy.deleteAccount({user:{id:userId,role:'admin'},currentPassword:'correct',confirmation:'DELETE_ACCOUNT'}),/administradora/);
  assert.equal(privacy.retentionPolicy().analyticsDays,90);

  // Cloud deletion contract: DB-owned records + object prefix + local identity cleanup.
  const cloudDir = fs.mkdtempSync(path.join(os.tmpdir(), 'puntia-capa29-cloud-'));
  const cloudFiles = {
    users:path.join(cloudDir,'users.json'), sessions:path.join(cloudDir,'sessions.json'), reset:path.join(cloudDir,'reset.json'), events:path.join(cloudDir,'events.jsonl'), tomb:path.join(cloudDir,'tomb.json')
  };
  save(cloudFiles.users,[{id:'cloud-user',email:'cloud@example.com'}]);
  save(cloudFiles.sessions,{'s':{userId:'cloud-user'}}); save(cloudFiles.reset,{'r':{userId:'cloud-user'}}); save(cloudFiles.tomb,{}); fs.writeFileSync(cloudFiles.events,'');
  const cloudDeps={
    USERS_FILE:cloudFiles.users,SESSIONS_FILE:cloudFiles.sessions,RESET_TOKENS_FILE:cloudFiles.reset,SYNC_TOMBSTONES_FILE:cloudFiles.tomb,EVENTS_FILE:cloudFiles.events,
    loadJsonFile:(f,d)=>{try{return JSON.parse(fs.readFileSync(f,'utf8'))}catch{return d}},saveJsonFile:save,loadProjects:()=>[],saveProjects:()=>{},
    cloud:{privacyRepo:{async deleteUserData(id){assert.equal(id,'cloud-user');return {projectIds:['cp1'],jobIds:['cj1'],assetKeys:['users/cloud-user/a.png']};}},objectStorage:{removed:[],async list(){return [{key:'users/cloud-user/a.png'},{key:'users/cloud-user/b.png'},{key:'users/other/x.png'}]},async remove(k){this.removed.push(k);return true;}},auditSink:{async redactActor(){return 2;}}},
  };
  const cloudPrivacy=createPrivacyService(cloudDeps,{auth:{verifyPassword:()=>true},audit:{record:async()=>{}}});
  const cloudResult=await cloudPrivacy.deleteAccount({user:{id:'cloud-user',role:'user'},currentPassword:'correct',confirmation:'DELETE_ACCOUNT'});
  assert.equal(cloudResult.deleted.projects,1); assert.equal(cloudResult.deleted.jobs,1); assert.equal(cloudResult.deleted.assets,2); assert.equal(JSON.parse(fs.readFileSync(cloudFiles.users)).length,0);

  // Retention purges expired local records and preserves audit-chain integrity.
  const oldAudit=path.join(dir,'old-audit.jsonl'); const retentionSink=createFileAuditSink(oldAudit);
  await retentionSink.record({eventId:'old',occurredAt:new Date(Date.now()-200*86400000).toISOString(),action:'old',resourceType:'system',resourceId:null,actorId:null,correlationId:null,status:'success',metadata:{}});
  await retentionSink.record({eventId:'new',occurredAt:new Date().toISOString(),action:'new',resourceType:'system',resourceId:null,actorId:null,correlationId:null,status:'success',metadata:{}});
  const retentionDeps={...deps,EVENTS_FILE:path.join(dir,'retention-events.jsonl'),auditSink:retentionSink};
  fs.writeFileSync(retentionDeps.EVENTS_FILE,JSON.stringify({id:'old',at:new Date(Date.now()-100*86400000).toISOString()})+'\n'+JSON.stringify({id:'new',at:new Date().toISOString()})+'\n');
  const retentionPrivacy=createPrivacyService(retentionDeps,services);
  const pr=await retentionPrivacy.pruneRetention();
  assert.equal(pr.analyticsRemoved,1); assert.equal(pr.auditRemoved,1); assert.equal((await retentionSink.verify()).ok,true); assert.equal((await retentionSink.list(10)).length,1);

  console.log('Capa 29 regression: PASS');
})().catch(e=>{console.error(`Capa 29 regression: FAIL ${e.stack||e.message}`);process.exit(1);});
