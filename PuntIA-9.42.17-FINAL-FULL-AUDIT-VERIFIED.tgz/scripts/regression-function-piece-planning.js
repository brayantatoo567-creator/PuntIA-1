'use strict';
const assert = require('node:assert/strict');
const { interpretConcept } = require('../src/core/concept-decomposition');
const { planPatternPieces, validatePiecePlan, validatePieceCoverageByPlan } = require('../src/core/pattern-piece-planner');
const { validatePattern } = require('../src/core/pattern-engine');
const { createPatternService } = require('../src/application/pattern-service');
const { createPatternGenerationPipeline } = require('../src/application/pattern-generation-pipeline');

function mainPattern(){return {title:'Dragón',initialStitches:6,materials:['hilo'],abbreviations:['pb','aum','dis'],rounds:[
  {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
  {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12},
  {round:3,inputStitches:12,operations:[{type:'increase',count:1,repeats:12}],expectedStitches:24},
  {round:4,inputStitches:24,operations:[{type:'decrease',count:1,repeats:12}],expectedStitches:12},
  {round:5,inputStitches:12,operations:[{type:'decrease',count:1,repeats:6}],expectedStitches:6}],
  assembly:['Cuerpo principal','Cabeza','Alas','Cola','Cuernos'],notes:[],geometry:{type:'body',targetHeightCm:15}}}

const concept=interpretConcept({description:'Dragón azul con alas, cuernos y cola de 15 cm'});
const pattern=mainPattern();
const plan=planPatternPieces(concept,pattern);
assert.equal(plan.ok,true,plan.issues.join(' | '));
for (const piece of plan.piecePlans) assert.equal(validatePiecePlan(piece).ok,true,`${piece.id} inválida`);
console.log('PIECE_PLAN_EXECUTION: PASS');
assert.equal(plan.piecePlans.length,concept.pieces.length);
console.log('PIECE_PLAN_COVERAGE: PASS');
assert.ok(plan.piecePlans.some(p=>p.id==='wings'&&p.quantity===2));
console.log('PIECE_QUANTITY_MAPPING: PASS');
assert.equal(validatePieceCoverageByPlan(concept,plan.piecePlans).ok,true);
console.log('PIECE_COVERAGE_GATE: PASS');
const bad=plan.piecePlans.filter(p=>p.id!=='wings');
assert.equal(validatePieceCoverageByPlan(concept,bad).ok,false);
console.log('PIECE_GATE_REJECTS_MISSING_REQUIRED: PASS');

const deps={
 safeText:(v,n)=>String(v??'').slice(0,n),validatePattern,extractFirstJsonObject:JSON.parse,SYSTEM:'TEST',PATTERN_MODEL:'p',CHAT_MODEL:'f',runtime:{},outputText:d=>d.output_text,
 openaiPostModelFallback:async()=>({model:'test',data:{output_text:JSON.stringify(pattern)}})
};
const services=()=>({pattern:createPatternService(deps),usage:{reserve:async()=>({allowed:true,reservationId:'r'}),confirm:async()=>{},release:async()=>{}},audit:{record:async()=>{}},observability:{run:async(_n,fn)=>fn()}});
(async()=>{
 const pipeline=createPatternGenerationPipeline(deps,services());
 const result=await pipeline.generate({user:{id:'u'},input:{name:'Dragón azul con alas, cuernos y cola',height:'15'}});
 assert.equal(result.ok,true,result.error||'pipeline failed');
 assert.ok(Array.isArray(result.structured.piecePlans));
 assert.equal(result.structured.piecePlans.length,result.concept.pieces.length);
 assert.ok(result.structured.reader);
 assert.ok(result.structured.reader.guidedSteps.length > 0);
 console.log('PIECE_PIPELINE_INTEGRATION: PASS');
 console.log('PATTERN_READER_PIPELINE_INTEGRATION: PASS');
 console.log('FUNCTION_6_PIECE_TO_EXECUTABLE_PATTERN: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1)});
