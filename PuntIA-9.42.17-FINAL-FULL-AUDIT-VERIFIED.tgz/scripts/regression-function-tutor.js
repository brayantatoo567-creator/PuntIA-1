'use strict';
const assert=require('node:assert/strict');
const {createTutorialService}=require('../src/application/tutorial-service');
const {validatePattern}=require('../src/core/pattern-engine');
function pattern(){return {title:'Ajolote',initialStitches:6,materials:['hilo','gancho'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],assembly:['unir'],notes:[],geometry:{type:'sphere',targetHeightCm:8}}}
(async()=>{
 const svc=createTutorialService({validatePattern}); const t=svc.create(pattern(),{level:'Principiante'});
 assert.equal(t.steps.length,2); assert.equal(t.steps[1].expectedStitches,12); assert.equal(t.steps[1].teacher.checkpoint.expectedStitches,12); assert(t.tutor.supportedStates.includes('demonstrating')); assert(t.tutor.interaction.includes('no_me_sale'));
 console.log('TUTOR_PATTERN_BOUND: PASS');
 console.log('TUTOR_DIDACTIC_STATE_MACHINE: PASS');
 console.log('TUTOR_PROGRESS_CONTRACT: PASS');
 console.log('TUTOR_FUNCTION: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1)});
