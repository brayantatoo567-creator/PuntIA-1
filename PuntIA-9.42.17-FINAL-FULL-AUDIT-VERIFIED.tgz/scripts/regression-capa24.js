'use strict';
const assert = require('assert');
const { createJobService } = require('../src/application/job-service');
const { createProjectService } = require('../src/application/project-service');
const { createMemoryUsageLedger } = require('../src/adapters/memory-usage-ledger');
const { createObservabilityService } = require('../src/application/observability-service');

(async () => {
  const user = { id:'u24', plan:'free' };

  // Concurrent job idempotency: only one quota reservation/job may be created.
  let jobs = {};
  let created = 0;
  let reserved = 0;
  const usage = { async reserve(){ reserved++; await new Promise(r=>setTimeout(r,5)); return {allowed:true,used:reserved,limit:100,reservationId:`r${reserved}`,state:'reserved'}; } };
  const deps = {
    safeText:(v,n)=>String(v ?? '').slice(0,n),
    findJobByIdempotency:(kind,owner,key)=>Object.values(jobs).find(j=>j.kind===kind&&j.ownerId===owner&&j.idempotencyKey===key&&['queued','running','completed'].includes(j.status)) || null,
    createJob:(kind,owner,meta)=>{ const id=`job-${++created}`; const j={id,kind,ownerId:owner,status:'queued',progress:0,attempts:0,maxAttempts:3,idempotencyKey:meta.idempotencyKey,meta}; jobs[id]=j; return j; },
    updateJob:(id,p)=>{ jobs[id]={...jobs[id],...p}; return jobs[id]; },
    enqueueLocalJob:()=>{},
    getJob:(id,owner)=>jobs[id]?.ownerId===owner?jobs[id]:null,
    cancelJob:()=>null,
  };
  const services = { usage, audit:{record:async()=>{}}, patternPipeline:{generate:async()=>({validation:{ok:true}})}, observability:{run:async(_n,fn)=>fn()} };
  const jobService = createJobService(deps,services);
  const inputs = Array.from({length:50},()=>jobService.createPatternJob({user,input:{name:'dragón',idempotencyKey:'same-key'}}));
  const results = await Promise.all(inputs);
  assert.strictEqual(new Set(results.map(j=>j.id)).size,1,'concurrent idempotency created multiple jobs');
  assert.strictEqual(created,1,'concurrent idempotency created more than one job');
  assert.strictEqual(reserved,1,'concurrent idempotency reserved quota more than once');

  // Concurrent distinct keys create distinct jobs.
  const distinct = await Promise.all(Array.from({length:30},(_,i)=>jobService.createPatternJob({user,input:{name:'gato',idempotencyKey:`k-${i}`}})));
  assert.strictEqual(new Set(distinct.map(j=>j.id)).size,30,'distinct idempotency keys collapsed');

  // Memory usage ledger remains bounded under concurrent reservations.
  const ledger=createMemoryUsageLedger();
  const quota=await Promise.all(Array.from({length:100},()=>ledger.reserve('u','pattern',10)));
  assert.strictEqual(quota.filter(x=>x.allowed).length,10,'memory ledger over-reserved quota');
  assert.strictEqual(new Set(quota.filter(x=>x.allowed).map(x=>x.reservationId)).size,10,'reservation IDs duplicated');

  // Project optimistic concurrency: exactly one stale-version update wins.
  let store=[{id:'p24',ownerId:'u24',version:1,title:'A',description:'',pattern:null,image:null,progress:0,assets:[],progressState:{},versions:[],updatedAt:new Date().toISOString()}];
  const ps=createProjectService({MAX_PROJECTS_TOTAL:100,MAX_PROJECTS:100,projectStore:()=>store,saveProjects:v=>{store=v;}});
  const updates=await Promise.all(Array.from({length:40},async(_,i)=>{
    try{return {ok:true,value:ps.update(user,'p24',{title:`T${i}`,expectedVersion:1})};}
    catch(e){return {ok:false,error:e};}
  }));
  assert.strictEqual(updates.filter(x=>x.ok).length,1,'more than one concurrent version-1 update succeeded');
  assert.strictEqual(updates.filter(x=>!x.ok&&x.error.code==='PROJECT_VERSION_CONFLICT').length,39,'stale updates were not rejected as conflicts');

  // Circuit breaker opens under concurrent failures and recovers after cooldown.
  const obs=createObservabilityService({},{});
  let calls=0;
  for(let i=0;i<3;i++) await assert.rejects(obs.run('stress',async()=>{calls++;throw Object.assign(new Error('boom'),{code:'UPSTREAM_5XX'});},{threshold:3,cooldownMs:1}));
  assert.strictEqual(obs.health().circuitBreakers.stress.state,'open');
  await new Promise(r=>setTimeout(r,3));
  await obs.run('stress',async()=>{calls++;return {ok:true};},{threshold:3,cooldownMs:1});
  assert.strictEqual(obs.health().circuitBreakers.stress.state,'closed');
  assert.ok(calls>=4);

  console.log('Capa 24 regression: PASS');
})().catch(e=>{console.error('Capa 24 regression: FAIL');console.error(e.stack||e);process.exit(1);});
