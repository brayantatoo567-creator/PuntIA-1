'use strict';
const assert=require('node:assert/strict');
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const ROOT=path.resolve(__dirname,'..');
for(const f of ['.puntia-stripe-config.json']){try{fs.unlinkSync(path.join(ROOT,f))}catch{}}
let calls=0;
const provider=http.createServer((req,res)=>{if(req.method==='GET'&&req.url==='/balance'){calls++;res.writeHead(200,{'content-type':'application/json'});return res.end(JSON.stringify({object:'balance',available:[]}));}res.writeHead(404);res.end();});
(async()=>{
 await new Promise(r=>provider.listen(0,'127.0.0.1',r));
 process.env.PORT='0'; process.env.PUNTIA_STRIPE_BASE_URL=`http://127.0.0.1:${provider.address().port}`; process.env.PUNTIA_ALLOW_LOCAL_CONFIG='true'; process.env.PUNTIA_REQUIRE_CSRF='false'; process.env.PUNTIA_REQUIRE_ORIGIN='false'; delete process.env.STRIPE_SECRET_KEY; delete process.env.STRIPE_WEBHOOK_SECRET; delete process.env.STRIPE_PRICE_PLUS; delete process.env.STRIPE_PRICE_PRO;
 const {createHttpRuntime}=require('../src/infrastructure/http/runtime'); const server=createHttpRuntime(); await new Promise((r,j)=>{server.once('listening',r);server.once('error',j);server.listen(0,'127.0.0.1')}); const base=`http://127.0.0.1:${server.address().port}`;
 const secret='sk_test_'+ 'A'.repeat(24), wh='whsec_'+ 'B'.repeat(24), plus='price_'+ 'P'.repeat(12), pro='price_'+ 'Q'.repeat(12);
 const save=await fetch(`${base}/api/config/stripe`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({secretKey:secret,webhookSecret:wh,plusPrice:plus,proPrice:pro})}); const sd=await save.json(); assert.equal(save.status,200); assert.equal(sd.verified,true); assert.equal(sd.configured,true); assert.match(sd.key,/^sk_test…AAAA$/);
 const disk=JSON.parse(fs.readFileSync(path.join(ROOT,'.puntia-stripe-config.json'),'utf8')); assert.equal(typeof disk.secretKey,'undefined'); assert.match(disk.secretKeyEncrypted,/^v1:/); assert.equal(fs.statSync(path.join(ROOT,'.puntia-stripe-config.json')).mode&0o777,0o600);
 const get=await (await fetch(`${base}/api/config/stripe`)).json(); assert.equal(get.configured,true); assert.equal(get.prices.plus,plus); assert.equal(get.prices.pro,pro); assert.equal(get.webhookConfigured,true);
 const test=await fetch(`${base}/api/config/stripe/test`,{method:'POST'}); assert.equal(test.status,200); assert.equal((await test.json()).verified,true); assert.equal(calls,2);
 const del=await fetch(`${base}/api/config/stripe`,{method:'DELETE'}); assert.equal(del.status,200); assert.equal((await del.json()).configured,false);
 await new Promise(r=>server.close(r)); await new Promise(r=>provider.close(r)); try{fs.unlinkSync(path.join(ROOT,'.puntia-stripe-config.json'))}catch{}
 console.log('STRIPE_CONFIG_E2E: PASS');
})().catch(e=>{console.error(e.stack||e);try{provider.close()}catch{};try{fs.unlinkSync(path.join(ROOT,'.puntia-stripe-config.json'))}catch{};process.exit(1)});
