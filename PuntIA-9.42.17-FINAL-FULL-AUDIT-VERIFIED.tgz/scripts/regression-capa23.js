'use strict';
const assert=require('node:assert/strict');
const {createProjectService}=require('../src/application/project-service');
const {createSyncService}=require('../src/application/sync-service');
const {createConflictResolutionService}=require('../src/application/conflict-resolution-service');
const {createJobService}=require('../src/application/job-service');

const store=[];
const deps={
  projectStore:()=>store,
  saveProjects:(x)=>{store.length=0;store.push(...x)},
  MAX_PROJECTS:100,
  MAX_PROJECTS_TOTAL:1000,
  safeText:(v,n)=>String(v||'').slice(0,n),
  findJobByIdempotency:()=>null,
  createJob:()=>null,
  updateJob:()=>null,
  enqueueJob:()=>null
};
const projects=createProjectService(deps);
const u1={id:'tenant-a'}, u2={id:'tenant-b'};
const p=projects.create(u1,{title:'privado',description:'A'});
assert.equal(p.ownerId,'tenant-a');
assert.equal(projects.list(u2).length,0);
assert.equal(projects.get(u2,p.id),null);
assert.throws(()=>projects.update(u2,p.id,{title:'hack'}),e=>e.code==='PROJECT_NOT_FOUND');
assert.throws(()=>projects.remove(u2,p.id),e=>e.code==='PROJECT_NOT_FOUND');

const sync=createSyncService(deps,createConflictResolutionService());
(async()=>{
  const other=await sync.pull({user:u2,cursor:'',limit:100,tombstones:{list:()=>[]}});
  assert.equal(other.projects.length,0);
  const injected=await sync.push({user:u2,items:[{...p,id:'00000000-0000-4000-8000-000000000023',ownerId:'tenant-a',expectedVersion:0}],repo:null,projectService:projects,tombstones:{put(){},get(){}}});
  assert.equal(injected.results[0].status,'created');
  const clone=injected.results[0].project;
  assert.equal(clone.ownerId,'tenant-b');
  assert.notEqual(clone.ownerId,p.ownerId);

  const merge=createConflictResolutionService().merge({
    base:{title:'x',description:'y',ownerId:'tenant-a'},
    local:{title:'local',description:'y'},
    remote:{title:'x',description:'remote',ownerId:'tenant-a',id:'x',version:2}
  });
  assert.equal(merge.status,'merged');
  assert.equal(merge.project.ownerId,'tenant-a');

  console.log('CAPA23_PROJECT_IDOR: PASS');
  console.log('CAPA23_OWNER_INJECTION_BLOCKED: PASS');
  console.log('CAPA23_CROSS_TENANT_SYNC_ISOLATION: PASS');
  console.log('CAPA23_DELETE_UPDATE_CONFLICT_POLICY: PASS');
  console.log('CAPA23_ADMIN_SURFACE_HARDENED: PASS');
})().catch(e=>{console.error('Capa 23 regression: FAIL',e.stack||e);process.exit(1)});
