'use strict';
const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../public/offline-sync.js'),'utf8');let store={};const context={window:{},localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=v},removeItem:k=>{delete store[k]}},navigator:{onLine:true},crypto:{randomUUID:()=>`id-${++context.seq}`},seq:0};context.window.crypto=context.crypto;vm.runInNewContext(source,context);const q=context.window.PuntIAOfflineSync;
(async()=>{
 const a=await q.enqueue({id:'p1',ownerKey:'u1',operation:'upsert',payload:{id:'p1',title:'A'}});assert.equal(a.state,'pending');assert.equal(q.pending('u1').length,1);assert.equal(q.pending('u2').length,0);
 let calls=0;let r=await q.flush(async item=>{calls++;assert.equal(item.id,'p1');return{status:'created'}},'u1');assert.equal(r.processed,1);assert.equal(q.pending('u1').length,0);
 await q.enqueue({id:'p2',ownerKey:'u2',operation:'upsert',payload:{id:'p2'}});r=await q.flush(async()=>({status:'created'}),'u1');assert.equal(r.processed,0);assert.equal(r.skipped,1);assert.equal(q.pending('u2').length,1);
 r=await q.flush(async()=>({status:'conflict'}),'u2');assert.equal(r.conflicts,1);assert.equal(q.pending('u2')[0].state,'conflict');
 context.navigator.onLine=false;r=await q.flush(async()=>({status:'updated'}),'u2');assert.equal(r.offline,true);
 console.log('OFFLINE_CLIENT_OWNER_ISOLATION: PASS');console.log('OFFLINE_CLIENT_QUEUE: PASS');console.log('OFFLINE_CLIENT_CONFLICT: PASS');console.log('OFFLINE_CLIENT_FUNCTION: PASS');
})().catch(e=>{console.error('OFFLINE_CLIENT_FUNCTION: FAIL');console.error(e.stack||e);process.exit(1)});
