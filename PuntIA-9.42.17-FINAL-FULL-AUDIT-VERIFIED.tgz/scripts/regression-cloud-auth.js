'use strict';
const assert=require('node:assert/strict');
const {createPostgresAuthRepository}=require('../src/adapters/postgres-auth-repository');
function fakePool(){
  const state={users:new Map(),sessions:new Map(),resets:new Map()};
  const rows=(sql,args)=>{
    if(sql.startsWith('SELECT * FROM users WHERE email=')){const u=[...state.users.values()].find(x=>x.email===args[0]);return u?[u]:[];}
    if(sql.startsWith('SELECT * FROM users WHERE id=')){const u=state.users.get(args[0]);return u?[u]:[];}
    if(sql.startsWith('SELECT * FROM users ORDER'))return [...state.users.values()];
    if(sql.startsWith('SELECT s.*')){const s=state.sessions.get(args[0]);if(!s)return[];const u=state.users.get(s.user_id);if(!u)return[];return [{...s,email:u.email,name:u.name,password_hash:u.password_hash,password_salt:u.password_salt,plan:u.plan,role:u.role,user_created_at:u.created_at,user_auth_version:u.auth_version}];}
    if(sql.startsWith('SELECT * FROM auth_sessions WHERE user_id='))return [...state.sessions.values()].filter(x=>x.user_id===args[0]);
    if(sql.startsWith('SELECT user_id,expires_at FROM auth_reset_tokens')){const r=state.resets.get(args[0]);return r?[r]:[];}
    return [];
  };
  return {async query(sql,args=[]){
    if(sql.startsWith('INSERT INTO users')){const u={id:args[0],email:args[1],name:args[2],password_hash:args[3],password_salt:args[4],auth_version:args[5],plan:args[6],role:args[7],created_at:new Date().toISOString()};state.users.set(u.id,u);return{rows:[u],rowCount:1};}
    if(sql.startsWith('UPDATE users SET auth_version')){const u=state.users.get(args[0]);u.auth_version++;return{rows:[u],rowCount:1};}
    if(sql.startsWith('UPDATE users SET')){const u=state.users.get(args[0]);if(!u)return{rows:[],rowCount:0};Object.assign(u,{name:args[1],password_hash:args[2],password_salt:args[3],auth_version:args[4],plan:args[5],role:args[6]});return{rows:[u],rowCount:1};}
    if(sql.startsWith('INSERT INTO auth_sessions')){const s={token_hash:args[0],session_id:args[1],user_id:args[2],auth_version:args[3],csrf:args[4],created_at:args[5],last_seen_at:args[6],expires_at:args[7],user_agent:args[8]};state.sessions.set(s.token_hash,s);return{rows:[],rowCount:1};}
    if(sql.startsWith('DELETE FROM auth_sessions WHERE token_hash')){return{rows:[],rowCount:state.sessions.delete(args[0])?1:0};}
    if(sql.startsWith('DELETE FROM auth_sessions WHERE user_id')){let n=0;for(const[k,v]of state.sessions){if(v.user_id===args[0]){state.sessions.delete(k);n++;}}return{rows:[],rowCount:n};}
    if(sql.startsWith('INSERT INTO auth_reset_tokens')){state.resets.set(args[0],{user_id:args[1],expires_at:args[2]});return{rows:[],rowCount:1};}
    if(sql.startsWith('DELETE FROM auth_reset_tokens WHERE token_hash')){return{rows:[],rowCount:state.resets.delete(args[0])?1:0};}
    if(sql.startsWith('DELETE FROM users')){return{rows:[],rowCount:state.users.delete(args[0])?1:0};}
    if(sql.startsWith('DELETE FROM auth_sessions WHERE expires_at'))return{rows:[],rowCount:0};
    if(sql.startsWith('DELETE FROM auth_reset_tokens WHERE expires_at'))return{rows:[],rowCount:0};
    const r=rows(sql,args);return{rows:r,rowCount:r.length};
  },async connect(){const pool=this;return{query:(...a)=>pool.query(...a),release(){}}},_state:state};
}
(async()=>{
 const pool=fakePool();const repo=await createPostgresAuthRepository({pool});
 const user=await repo.createUser({id:'u1',email:'a@b.com',name:'A',passwordHash:'h',passwordSalt:'s',authVersion:1,plan:'free',role:'user'});
 assert.equal((await repo.findByEmail('A@B.COM')).id,'u1');
 await repo.createSession('th',{sessionId:'s1',userId:'u1',authVersion:1,csrf:'c',createdAt:new Date().toISOString(),lastSeenAt:new Date().toISOString(),expiresAt:new Date(Date.now()+60000).toISOString(),userAgent:'test'});
 const session=await repo.getSession('th');assert.equal(session.user.id,'u1');assert.equal(session.csrf,'c');
 await repo.revokeAllSessions('u1');assert.equal(await repo.getSession('th'),null);assert.equal((await repo.findById('u1')).authVersion,2);
 await repo.createResetToken('rt','u1',new Date(Date.now()+60000).toISOString());assert.equal((await repo.consumeResetToken('rt')).userId,'u1');assert.equal(await repo.consumeResetToken('rt'),null);
 assert.equal(await repo.deleteUser('u1'),1);console.log('CLOUD_AUTH_REPOSITORY: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
