'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const {validateProductionConfig}=require('../src/infrastructure/config/production-config');
const result=validateProductionConfig({...process.env,NODE_ENV:'production'});
if(!result.ok){ console.error('PRODUCTION_PREFLIGHT: FAIL'); result.errors.forEach(e=>console.error(`- ${e}`)); process.exit(1); }
const persistent=path.resolve(String(process.env.PUNTIA_PERSISTENT_DIR));
assert.notEqual(persistent,path.resolve(__dirname,'..'));
console.log('PRODUCTION_PREFLIGHT: PASS');
console.log(`PERSISTENT_DIR: ${persistent}`);
console.log(`PUBLIC_URL: ${process.env.PUNTIA_PUBLIC_URL}`);
