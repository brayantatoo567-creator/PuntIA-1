'use strict';
const assert = require('assert');
const { validateProductionConfig } = require('../src/infrastructure/config/production-config');
const { MIGRATIONS, runCloudMigrations } = require('../src/infrastructure/migrations/cloud-migrations');
const { spawn } = require('child_process');
const http = require('http');

function fakePool() {
  const applied = new Set();
  const statements = [];
  return {
    statements,
    async query(sql, params=[]) {
      statements.push(sql);
      if (/CREATE TABLE IF NOT EXISTS schema_migrations/i.test(sql)) return {rows:[],rowCount:0};
      if (/SELECT 1 FROM schema_migrations/i.test(sql)) return {rows: applied.has(params[0]) ? [{}] : [], rowCount: applied.has(params[0]) ? 1 : 0};
      if (/SELECT id, applied_at FROM schema_migrations/i.test(sql)) return {rows:[...applied].map(id=>({id,applied_at:new Date()})),rowCount:applied.size};
      if (/INSERT INTO schema_migrations/i.test(sql)) { applied.add(params[0]); return {rows:[],rowCount:1}; }
      return {rows:[],rowCount:0};
    },
    async connect() {
      return {
        query: async (sql, params=[]) => {
          statements.push(sql);
          if (/INSERT INTO schema_migrations/i.test(sql)) applied.add(params[0]);
          return {rows:[],rowCount:0};
        },
        release() {}
      };
    }
  };
}

(async()=>{
  const bad = validateProductionConfig({NODE_ENV:'production',PUNTIA_CLOUD_MODE:'false'});
  assert.equal(bad.ok,false);
  assert(bad.errors.length >= 5); assert(bad.errors.some(e=>/OPENAI_API_KEY o PUNTIA_CONFIG_MASTER_KEY/.test(e)));

  const good = validateProductionConfig({
    NODE_ENV:'production', PUNTIA_CLOUD_MODE:'true', DATABASE_URL:'postgres://db', REDIS_URL:'redis://r',
    PUNTIA_STORAGE_BUCKET:'puntia', PUNTIA_PUBLIC_URL:'https://puntia.example', PUNTIA_PERSISTENT_DIR:'/data/puntia', PUNTIA_ADMIN_EMAIL:'admin@example.com',
    PUNTIA_ADMIN_PASSWORD:'123456789012', PUNTIA_CONFIG_MASTER_KEY:'QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUE=', PUNTIA_ALLOW_LOCAL_CONFIG:'false'
  });
  assert.equal(good.ok,true);

  const pool=fakePool();
  const first=await runCloudMigrations({pool});
  assert.equal(first.ok,true);
  assert.equal(first.applied.length,MIGRATIONS.length);
  const count=pool.statements.length;
  const second=await runCloudMigrations({pool});
  assert.equal(second.applied.length,MIGRATIONS.length);
  assert(pool.statements.length < count + MIGRATIONS.length + 3, 'segunda ejecución no debe repetir todo el DDL');


  const port = 18927;
  const child = spawn(process.execPath, ['server.js'], { cwd: require('path').resolve(__dirname, '..'), env: { ...process.env, NODE_ENV:'development', PUNTIA_CLOUD_MODE:'false', PORT:String(port), PUNTIA_HOST:'127.0.0.1' }, stdio:['ignore','pipe','pipe'] });
  let output=''; child.stdout.on('data',d=>output+=d); child.stderr.on('data',d=>output+=d);
  async function get(path){return await new Promise((resolve,reject)=>{const req=http.get({host:'127.0.0.1',port,path,timeout:1500},res=>{let body='';res.on('data',d=>body+=d);res.on('end',()=>resolve({status:res.statusCode,body}));});req.on('error',reject);req.on('timeout',()=>req.destroy(new Error('timeout')));});}
  let live=null;
  for(let i=0;i<30;i++){try{live=await get('/api/live');if(live.status===200)break;}catch{} await new Promise(r=>setTimeout(r,50));}
  assert.equal(live?.status,200,`servidor no inició: ${output}`);
  const ready=await get('/api/ready'); assert.equal(ready.status,200);
  child.kill('SIGTERM');
  const exitCode=await new Promise(resolve=>{const t=setTimeout(()=>resolve('timeout'),5000);child.once('exit',code=>{clearTimeout(t);resolve(code);});});
  assert.equal(exitCode,0,`SIGTERM no terminó limpiamente: ${output}`);

  console.log('Capa 27 regression: PASS (config + migrations + readiness + graceful shutdown)');
})().catch(error=>{console.error('Capa 27 regression: FAIL',error);process.exit(1);});
