'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const { createPatternService, PATTERN_JSON_SCHEMA } = require('../src/application/pattern-service');
const { validatePattern } = require('../src/core/pattern-engine');

const deps = {
  validatePattern,
  extractFirstJsonObject(raw) {
    if (raw && typeof raw === 'object') return raw;
    const text = String(raw || '').trim();
    return JSON.parse(text);
  },
  safeText: (v, n) => String(v ?? '').slice(0, n)
};
const service = createPatternService(deps);

function validPattern() {
  return {
    title: 'Prueba Capa 3', initialStitches: 6,
    materials: ['hilo'], abbreviations: ['pb'],
    rounds: [
      { round: 1, inputStitches: 6, operations: [{ type: 'single', count: 6, repeats: 1 }], expectedStitches: 6 },
      { round: 2, inputStitches: 6, operations: [{ type: 'increase', count: 1, repeats: 6 }], expectedStitches: 12 }
    ],
    assembly: ['unir'], notes: []
  };
}

const format = service.responseFormat();
assert.deepEqual(Object.keys(format).sort(), ['name', 'schema', 'strict', 'type']);
assert.equal(format.type, 'json_schema');
assert.equal(format.strict, true);
assert.equal(format.name, 'puntia_pattern');
assert.equal(format.schema, PATTERN_JSON_SCHEMA);
assert.equal(format.schema.additionalProperties, false);
assert.equal(service.qualityGate(validPattern()).qualityOk, true);

const bad = validPattern();
bad.rounds[1].expectedStitches = 11;
assert.throws(() => service.qualityGate(bad), /Quality Gate/);

assert.equal(deps.extractFirstJsonObject(JSON.stringify(validPattern())).title, 'Prueba Capa 3');

function request(port, path, method = 'GET') {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port, path, method }, res => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.end();
  });
}

(async () => {
  const port = 3219;
  const child = require('node:child_process').spawn(process.execPath, ['server.js'], {
    cwd: require('node:path').resolve(__dirname, '..'),
    env: { ...process.env, PORT: String(port), PUNTIA_ALLOW_LOCAL_CONFIG: 'true' },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let logs = '';
  child.stdout.on('data', d => logs += d);
  child.stderr.on('data', d => logs += d);
  try {
    const deadline = Date.now() + 8000;
    let health;
    while (Date.now() < deadline) {
      try { health = await request(port, '/api/health'); if (health.status) break; } catch {}
      await new Promise(r => setTimeout(r, 100));
    }
    assert.ok(health, `Servidor no inició. ${logs.slice(-1000)}`);
    assert.equal(health.status, 200);
    const parsed = JSON.parse(health.body);
    assert.equal(parsed.ok, true);
    console.log('CAPA3_STRUCTURED_CONTRACT: PASS');
    console.log('CAPA3_QUALITY_GATE: PASS');
    console.log('CAPA3_HTTP_HEALTH: PASS');
    console.log('CAPA3_NO_FAKE_AI: PASS (real provider test requiere credencial activa)');
  } finally {
    child.kill('SIGTERM');
    setTimeout(() => child.kill('SIGKILL'), 500).unref();
  }
})().catch(err => { console.error(err.stack || err); process.exit(1); });
