'use strict';
const assert = require('node:assert/strict');
const { evaluatePattern } = require('../src/services/quality-gate');

function pattern() {
  return {
    title:'Dragón', initialStitches:6, materials:['estambre'], abbreviations:['pb','aum','dis'],
    rounds:[
      {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
      {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12},
      {round:3,inputStitches:12,operations:[{type:'decrease',count:1,repeats:6}],expectedStitches:6}
    ],
    assembly:['Unir cabeza al cuerpo.'], notes:[], geometry:{type:'body',targetHeightCm:12},
    piecePlans:[{id:'body',name:'Cuerpo',quantity:1,rounds:[{round:1}],geometry:'body'}]
  };
}

const valid = pattern();
const good = evaluatePattern(valid, {qualityOk:true,issues:[]});
assert.equal(good.accepted,true);
assert.equal(good.quality,100);
assert.deepEqual(good.failedChecks,[]);
console.log('QUALITY_GATE_ACCEPTS_VALID_PATTERN: PASS');

const math = pattern();
math.rounds[1].expectedStitches = 99;
const badMath = evaluatePattern(math, {qualityOk:true,issues:[]});
assert.equal(badMath.accepted,false);
assert.ok(badMath.issues.some(x=>x.startsWith('Matemática:')));
console.log('QUALITY_GATE_REJECTS_MATH: PASS');

const readable = pattern();
readable.rounds[0].operations[0].type = 'magic';
const badReadable = evaluatePattern(readable, {qualityOk:true,issues:[]});
assert.equal(badReadable.accepted,false);
assert.ok(badReadable.issues.some(x=>x.startsWith('Legibilidad:')));
console.log('QUALITY_GATE_REJECTS_UNSUPPORTED_OPERATION: PASS');

const geometry = pattern();
delete geometry.geometry.targetHeightCm;
const badGeometry = evaluatePattern(geometry, {qualityOk:true,issues:[]});
assert.equal(badGeometry.accepted,false);
assert.equal(badGeometry.checks.geometry,false);
console.log('QUALITY_GATE_REJECTS_INVALID_GEOMETRY: PASS');

const pieces = pattern();
pieces.piecePlans[0].quantity = 0;
const badPieces = evaluatePattern(pieces, {qualityOk:true,issues:[]});
assert.equal(badPieces.accepted,false);
assert.equal(badPieces.checks.pieces,false);
console.log('QUALITY_GATE_REJECTS_INVALID_PIECE_PLAN: PASS');

const externalReject = evaluatePattern(pattern(), {qualityOk:false,issues:['Quality Gate previo rechazó el patrón.']});
assert.equal(externalReject.accepted,false);
assert.ok(externalReject.issues.includes('Quality Gate previo rechazó el patrón.'));
console.log('QUALITY_GATE_HONORS_DOMAIN_REJECTION: PASS');

console.log('FUNCTION_14_PATTERN_QUALITY_GATE: PASS');
