'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '..');
const configFile = path.join(ROOT, '.puntia-config.json');
const keyFile = path.join(ROOT, '.puntia-config.key');
for (const f of [configFile,keyFile]) { try { fs.unlinkSync(f); } catch {} }

let providerCalls=0;
const provider=http.createServer((req,res)=>{
  if(req.method==='GET' && req.url==='/models'){
    res.writeHead(200,{'content-type':'application/json'});
    return res.end(JSON.stringify({data:[{id:'gpt-6-luna'}]}));
  }
  if(req.method==='POST' && req.url==='/responses'){
    providerCalls++;
    let raw=''; req.on('data',c=>raw+=c); req.on('end',()=>{
      res.writeHead(200,{'content-type':'application/json'});
      res.end(JSON.stringify({output_text:'PUNTIA_API_OK'}));
    });
    return;
  }
  res.writeHead(404); res.end();
});

(async()=>{
  await new Promise(resolve=>provider.listen(0,'127.0.0.1',resolve));
  const port=provider.address().port;
  process.env.PORT='0';
  process.env.OPENAI_API_BASE_URL=`http://127.0.0.1:${port}`;
  delete process.env.PUNTIA_CONFIG_MASTER_KEY;
  process.env.PUNTIA_ALLOW_LOCAL_CONFIG='true';
  process.env.PUNTIA_REQUIRE_CSRF='false';
  process.env.PUNTIA_REQUIRE_ORIGIN='false';
  process.env.OPENAI_API_KEY='';
  const {createHttpRuntime}=require('../src/infrastructure/http/runtime');
  const server=createHttpRuntime();
  await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);server.listen(0,'127.0.0.1');});
  const base=`http://127.0.0.1:${server.address().port}`;
  const save=await fetch(`${base}/api/config/openai`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({apiKey:'sk-'+'z'.repeat(32),textModel:'gpt-6-luna',visionModel:'gpt-6-luna',imageModel:'gpt-image-2'})});
  const saved=await save.json();
  assert.equal(save.status,200); assert.equal(saved.ok,true); assert.equal(saved.verified,true); assert.equal(saved.persisted,true);
  const disk=JSON.parse(fs.readFileSync(configFile,'utf8'));
  assert.equal(typeof disk.apiKey,'undefined'); assert.match(String(disk.apiKeyEncrypted),/^v1:/);
  assert.equal(fs.statSync(configFile).mode & 0o777,0o600);
  assert.equal(fs.statSync(keyFile).mode & 0o777,0o600);
  const get=await fetch(`${base}/api/config/openai`); const info=await get.json();
  assert.equal(info.configured,true); assert.equal(info.source,'saved'); assert.match(info.key,/^sk-z{4}…z{4}$/);
  const test=await fetch(`${base}/api/config/openai/test`,{method:'POST'}); const tested=await test.json();
  assert.equal(test.status,200); assert.equal(tested.verified,true); assert.equal(providerCalls,2);
  const del=await fetch(`${base}/api/config/openai`,{method:'DELETE'}); const deleted=await del.json();
  assert.equal(del.status,200); assert.equal(deleted.configured,false); assert.equal(fs.existsSync(configFile),false);
  await new Promise(resolve=>server.close(resolve)); await new Promise(resolve=>provider.close(resolve));
  try { fs.unlinkSync(keyFile); } catch {}
  fs.writeFileSync(configFile, JSON.stringify({apiKey:'sk-'+'m'.repeat(32),textModel:'gpt-6-luna',visionModel:'gpt-6-luna',imageModel:'gpt-image-2'}), {mode:0o600});
  const migrated= require('node:child_process').spawnSync(process.execPath,['-e',"require('./src/infrastructure/http/runtime')"],{cwd:ROOT,env:{...process.env,PORT:'0',PUNTIA_ALLOW_LOCAL_CONFIG:'true',PUNTIA_REQUIRE_CSRF:'false',PUNTIA_REQUIRE_ORIGIN:'false',OPENAI_API_KEY:''},encoding:'utf8'});
  assert.equal(migrated.status,0,migrated.stderr||migrated.stdout);
  const migratedDisk=JSON.parse(fs.readFileSync(configFile,'utf8'));
  assert.equal(typeof migratedDisk.apiKey,'undefined'); assert.match(String(migratedDisk.apiKeyEncrypted),/^v1:/);
  try { fs.unlinkSync(configFile); } catch {}
  console.log('CONFIG_LEGACY_SECRET_MIGRATION: PASS');
  console.log('CONFIG_SECRET_VAULT_E2E: PASS');
})().catch(async e=>{console.error(e.stack||e);try{provider.close()}catch{};try{fs.unlinkSync(configFile)}catch{};try{fs.unlinkSync(keyFile)}catch{};process.exit(1)});
