'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const cp=require('node:child_process');
const root=path.resolve(__dirname,'..');
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
assert.match(pkg.version,/^9\.42\.\d+$/);
const version=pkg.version;
const expectedFiles={
  'src/core/config.js': new RegExp(`version:'${version.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}'`),
  'manifest.webmanifest': new RegExp(`\"version\":\"${version}\"`),
  'index.html': new RegExp(version),
  'sw.js': new RegExp(version),
  'android/app/build.gradle': new RegExp(`versionName '${version}'`),
  'android/app/src/main/java/com/puntia/app/MainActivity.java': new RegExp(`PuntIAAndroid/${version}`),
  'android/README.md': new RegExp(version),
  '.github/workflows/android-release.yml': new RegExp(`puntia-${version}-android-release`)
};
for(const [file,rx] of Object.entries(expectedFiles)){const body=fs.readFileSync(path.join(root,file),'utf8'); assert.match(body,rx,`release version drift: ${file}`);}
for(const [name,version] of Object.entries(pkg.dependencies||{})) assert.equal(version,String(version).trim(),`dependency not exact: ${name}`);
for(const file of ['.puntia-data','.puntia-config.key','.puntia-config.json','.puntia-stripe-config.json']) assert(!fs.existsSync(path.join(root,file)),`release contains runtime secret/data: ${file}`);
const android=fs.readFileSync(path.join(root,'android/app/src/main/java/com/puntia/app/MainActivity.java'),'utf8');
assert.match(android,/BuildConfig\.WEB_APP_URL/); assert(!android.includes('puntia-9-14-runtime-production.up.railway.app'));
const gradle=fs.readFileSync(path.join(root,'android/app/build.gradle'),'utf8');
assert.match(gradle,/PUNTIA_WEB_APP_URL es obligatorio/); assert.match(gradle,/compileSdk 35/); assert.match(gradle,/minSdk 29/); assert.match(gradle,/targetSdk 35/);
const workflow=fs.readFileSync(path.join(root,'.github/workflows/android-release.yml'),'utf8');
assert.match(workflow,/PUNTIA_WEB_APP_URL/); assert.match(workflow,/assembleDebug assembleRelease/); assert.match(workflow,/bundleRelease/);
const docker=fs.readFileSync(path.join(root,'Dockerfile'),'utf8'); assert.match(docker,/HEALTHCHECK/);
for(const file of ['server.js','src/infrastructure/http/runtime.js','src/application/pattern-generation-pipeline.js','src/routes/ai.js','scripts/regression-function-deployment.js','scripts/regression-function-production-hardening.js']) { const r=cp.spawnSync(process.execPath,['--check',file],{cwd:root,encoding:'utf8'}); assert.equal(r.status,0,`${file}\n${r.stderr}`); }
console.log('RELEASE_AUDIT: PASS');
