'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createProjectService } = require('../src/application/project-service');
const { normalizeProjectInput, assertProject } = require('../src/core/contracts');

const userA={id:'fn-project-a',plan:'free'};
const userB={id:'fn-project-b',plan:'free'};
let projects=[];
const deps={MAX_PROJECTS_TOTAL:100,MAX_PROJECTS:20,projectStore:()=>projects,saveProjects:v=>{projects=v}};
const service=createProjectService(deps);

(async()=>{
  const structured={title:'Dragón funcional',initialStitches:6,materials:['hilo'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6}],assembly:['unir'],notes:[],geometry:{type:'sphere',targetHeightCm:8}};
  const created=service.create(userA,{title:structured.title,status:'pattern_ready',pattern:JSON.stringify(structured),idempotencyKey:'create-1'});
  assert.equal(created.ownerId,userA.id); assert.equal(created.version,1); assert.equal(JSON.parse(created.pattern).title,structured.title);
  const replay=service.create(userA,{title:'NO DEBE DUPLICAR',status:'pattern_ready',pattern:'bad',idempotencyKey:'create-1'});
  assert.equal(replay.id,created.id); assert.equal(service.list(userA).length,1);
  assert.equal(service.list(userB).length,0);
  const updated=service.update(userA,created.id,{description:'Descripción',progress:25,progressState:{currentRound:2,completedRounds:[1],stitchesCompleted:6},assets:[{id:'a1',type:'image',url:'https://example.test/a',patternHash:'hash'}],expectedVersion:1,idempotencyKey:'update-1'});
  assert.equal(updated.version,2); assert.equal(updated.progressState.currentRound,2); assert.equal(updated.assets[0].id,'a1');
  const updateReplay=service.update(userA,created.id,{description:'OTRA',expectedVersion:1,idempotencyKey:'update-1'});
  assert.equal(updateReplay.version,2); assert.equal(updateReplay.description,'Descripción');
  assert.throws(()=>service.update(userA,created.id,{title:'stale',expectedVersion:1,idempotencyKey:'update-2'}),e=>e.code==='PROJECT_VERSION_CONFLICT'&&e.status===409);
  assert.equal(service.get(userB,created.id),null);
  assert.throws(()=>service.update(userB,created.id,{title:'IDOR'}),e=>e.code==='PROJECT_NOT_FOUND');
  assert.equal(service.remove(userA,created.id),created.id); assert.equal(service.get(userA,created.id),null);
  assert.equal(projects.length,0);

  const staticFile=fs.readFileSync(path.join(__dirname,'../src/infrastructure/http/transport/static-files.js'),'utf8');
  assert(staticFile.includes("pathname === '/offline-sync.js'"),'offline sync asset must be routable');
  assert(fs.existsSync(path.join(__dirname,'../public/offline-sync.js')),'offline sync source missing');
  assert(fs.existsSync(path.join(__dirname,'../sw.js')),'service worker missing');
  console.log('PROJECT_LIFECYCLE_SERVICE: PASS');
  console.log('PROJECT_CREATE_IDEMPOTENCY: PASS');
  console.log('PROJECT_VERSIONING_CONFLICTS: PASS');
  console.log('PROJECT_OWNER_ISOLATION: PASS');
  console.log('PROJECT_STATE_ASSETS_PRESERVED: PASS');
  console.log('PROJECT_OFFLINE_ASSETS_WIRED: PASS');
  console.log('PROJECT_LIFECYCLE_FUNCTION: PASS');
})().catch(e=>{console.error('PROJECT_LIFECYCLE_FUNCTION: FAIL');console.error(e.stack||e);process.exit(1)});
