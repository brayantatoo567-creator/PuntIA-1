'use strict';
const assert=require('node:assert/strict'); const fs=require('node:fs'); const path=require('node:path');
const root=path.resolve(__dirname,'..'); const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const config=fs.readFileSync(path.join(root,'src/core/config.js'),'utf8'); const gradle=fs.readFileSync(path.join(root,'android/app/build.gradle'),'utf8'); const docker=fs.readFileSync(path.join(root,'Dockerfile'),'utf8'); const manifest=fs.readFileSync(path.join(root,'android/app/src/main/AndroidManifest.xml'),'utf8');
assert.match(config,new RegExp(`version:'${pkg.version.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}'`));
assert.match(gradle,new RegExp(`versionName '${pkg.version.replace(/[^0-9.]/g,'')}'`));
assert.match(docker,/EXPOSE 8080/); assert.match(manifest,/android:usesCleartextTraffic="false"/);
console.log('RELEASE_VERSION_SYNC: PASS');
