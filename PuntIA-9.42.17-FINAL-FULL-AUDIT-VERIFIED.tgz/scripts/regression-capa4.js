'use strict';
const assert = require('assert');
const { createJsonRepository } = require('../src/adapters/json-repository');
const { createPostgresRepository } = require('../src/adapters/postgres-repository');
const { assertPort, PORTS } = require('../src/core/architecture');
const { normalizeProjectInput, assertProject, assertProjectList } = require('../src/core/contracts');
const fs = require('fs');
const os = require('os');
const path = require('path');

function project(id='p-1', ownerId='u-1') {
  return assertProject(normalizeProjectInput({id,title:'Amigurumi prueba',status:'idea'}, {}, ownerId));
}

(async()=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'puntia-c4-'));
  const repo=createJsonRepository(path.join(tmp,'projects.json'));
  const p=project();
  await repo.create(p);
  assert.deepStrictEqual((await repo.get(p.id)).id,p.id);
  assert.strictEqual((await repo.list()).length,1);
  await repo.update(p.id,{...p,title:'Actualizado'});
  assert.strictEqual((await repo.get(p.id)).title,'Actualizado');
  assert.strictEqual(await repo.remove(p.id),true);

  const queries=[];
  const fakeClient={
    async query(sql,args){queries.push({sql,args});
      if(sql.includes('SELECT * FROM projects WHERE id=$1 AND user_id=$2')) return {rows:[],rowCount:0};
      if(sql.includes('SELECT * FROM projects WHERE user_id=$1')) return {rows:[],rowCount:0};
      if(sql.startsWith('INSERT INTO projects')) return {rows:[],rowCount:1};
      return {rows:[],rowCount:0};
    },
    async connect(){return this;}, release(){},
  };
  const pg=await createPostgresRepository({pool:fakeClient});
  await pg.list('u-1');
  await pg.create(p,'u-1');
  assert.ok(queries.some(q=>q.sql.includes('WHERE user_id=$1')));
  assert.ok(queries.some(q=>q.sql.includes('INSERT INTO projects')));

  const queueMethods=PORTS.jobQueue;
  assert.ok(queueMethods.includes('enqueue') && queueMethods.includes('claim') && queueMethods.includes('complete') && queueMethods.includes('fail'));
  assert.throws(()=>assertPort({},'jobQueue'),/no implementa/);

  const storageSource=fs.readFileSync(path.join(__dirname,'../src/adapters/s3-object-storage.js'),'utf8');
  assert.ok(storageSource.includes("v.includes('..')"), 'Object storage path traversal guard missing');
  assert.ok(storageSource.includes('PutObjectCommand') && storageSource.includes('GetObjectCommand') && storageSource.includes('DeleteObjectCommand'));

  const valid=assertProjectList([p]); assert.strictEqual(valid.length,1);
  console.log('Capa 4 regression: PASS');
  console.log('JSON repository: PASS');
  console.log('PostgreSQL adapter contract: PASS');
  console.log('Redis queue port contract: PASS');
  console.log('Object storage safety: PASS');
  console.log('Domain contract regression: PASS');
  fs.rmSync(tmp,{recursive:true,force:true});
})().catch(e=>{console.error('Capa 4 regression: FAIL');console.error(e.stack||e);process.exit(1)});
