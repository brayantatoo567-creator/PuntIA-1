'use strict';
const fs=require('fs');const path=require('path');const http=require('http');const {spawn}=require('child_process');
const root=path.resolve(__dirname,'..');const data=path.join(root,'.puntia-data');const backup=`${data}.capa11-backup-${process.pid}`;const port=18991;
function request(method,payload,cookie=''){return new Promise((resolve,reject)=>{const body=payload===undefined?'':JSON.stringify(payload);const req=http.request({hostname:'127.0.0.1',port,path:'/api/auth/'+method,method:['me','sessions'].includes(method)?'GET':'POST',headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}), 'User-Agent':'PuntIA-Capa11-Test/1.0'}},res=>{let b='';res.on('data',c=>b+=c);res.on('end',()=>resolve({status:res.statusCode,body:b?JSON.parse(b):{},cookie:res.headers['set-cookie']?.[0]||''}));});req.on('error',reject);if(body)req.end(body);else req.end();});}
async function wait(){for(let i=0;i<40;i++){try{await request('me');return;}catch{}await new Promise(r=>setTimeout(r,100));}throw new Error('server timeout');}
(async()=>{let child;try{if(fs.existsSync(backup))fs.rmSync(backup,{recursive:true,force:true});if(fs.existsSync(data))fs.renameSync(data,backup);fs.mkdirSync(data,{recursive:true,mode:0o700});child=spawn(process.execPath,['server.js'],{cwd:root,env:{...process.env,PORT:String(port),NODE_ENV:'test',PUNTIA_REQUIRE_CSRF:'false'},stdio:'ignore'});await wait();
let r=await request('register',{email:'capa11@example.com',name:'Capa 11',password:'PasswordSegura123'});if(r.status!==201)throw new Error('register failed');const c1=r.cookie.split(';')[0];
r=await request('sessions',undefined,c1);if(r.status!==200||r.body.sessions.length!==1||!r.body.sessions[0].current)throw new Error('session listing failed');
r=await request('change-password',{currentPassword:'PasswordSegura123',newPassword:'PasswordNueva123'},c1);if(r.status!==200)throw new Error('password change failed');
r=await request('me',undefined,c1);if(r.status!==200||r.body.authenticated)throw new Error('old session remained valid');
r=await request('login',{email:'capa11@example.com',password:'PasswordNueva123'});if(r.status!==200)throw new Error('new password login failed');const c2=r.cookie.split(';')[0];
r=await request('sessions',undefined,c2);if(r.status!==200||r.body.sessions.length!==1)throw new Error('session isolation failed');
r=await request('logout-all',undefined,c2);if(r.status!==200)throw new Error('logout-all failed');
r=await request('me',undefined,c2);if(r.body.authenticated)throw new Error('revoked session remained valid');
console.log('Capa 11 regression: PASS');
}catch(e){console.error('Capa 11 regression: FAIL',e.message);process.exitCode=1;}finally{if(child)child.kill('SIGTERM');await new Promise(r=>setTimeout(r,150));try{if(fs.existsSync(data))fs.rmSync(data,{recursive:true,force:true});if(fs.existsSync(backup))fs.renameSync(backup,data);}catch(e){console.error('restore failed',e.message);process.exitCode=1;}}})();
