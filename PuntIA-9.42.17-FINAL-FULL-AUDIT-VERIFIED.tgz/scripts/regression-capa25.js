'use strict';
const assert=require('assert');
const {createRedisDistributedLock}=require('../src/adapters/redis-distributed-lock');
class FakeRedis{
 constructor(){this.k=new Map();}
 async set(key,val,...args){const nx=args.includes('NX');if(nx&&this.k.has(key))return null;this.k.set(key,val);return 'OK';}
 async eval(_lua,_n,key,val){if(this.k.get(key)===val){this.k.delete(key);return 1;}return 0;}
}
(async()=>{
 const r=new FakeRedis(); const a=createRedisDistributedLock({client:r,prefix:'test'}); const l1=await a.acquire('same',10000); assert(l1); const l2=await a.acquire('same',10000); assert.strictEqual(l2,null); assert.strictEqual(await l1.release(),true); const l3=await a.acquire('same',10000); assert(l3); assert.strictEqual(await l3.release(),true);
 console.log('Capa 25 distributed lock: PASS');
 console.log('Capa 25 multi-instance primitives: PASS');
})().catch(e=>{console.error(e);process.exit(1);});
