'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
process.env.NODE_ENV='development';
process.env.PUNTIA_CLOUD_MODE='false';
process.env.PUNTIA_REQUIRE_CSRF='false';
process.env.PUNTIA_REQUIRE_ACCOUNT_FOR_PROJECTS='false';
process.env.PUNTIA_REQUIRE_ORIGIN='false';
const dataFile=path.resolve(__dirname,'../.puntia-data/projects.json');
let backup=null;
try { if(fs.existsSync(dataFile)) backup=fs.readFileSync(dataFile); } catch {}
try { fs.rmSync(dataFile,{force:true}); } catch {}
const {createHttpRuntime}=require('../src/infrastructure/http/runtime');
const server=createHttpRuntime();
const json=(r)=>r.json();
(async()=>{
  await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);server.listen(0,'127.0.0.1');});
  const base=`http://127.0.0.1:${server.address().port}`;
  const pattern=JSON.stringify({title:'HTTP Project',initialStitches:6,materials:['hilo'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6}],assembly:['unir'],notes:[],geometry:{type:'sphere',targetHeightCm:8}});
  let r=await fetch(base+'/api/projects',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:'HTTP Project',status:'pattern_ready',pattern,idempotencyKey:'http-create-1'})});
  let d=await json(r); assert.equal(r.status,201); assert.equal(d.ok,true); const id=d.project.id; assert.equal(d.project.version,1);
  r=await fetch(base+'/api/projects',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({title:'DUPLICATE',status:'pattern_ready',pattern:'bad',idempotencyKey:'http-create-1'})}); d=await json(r); assert.equal(r.status,201); assert.equal(d.project.id,id); assert.equal(d.project.title,'HTTP Project');
  r=await fetch(base+`/api/projects/${id}`); d=await json(r); assert.equal(r.status,200); assert.equal(JSON.parse(d.project.pattern).title,'HTTP Project'); assert.equal(d.project.version,1);
  r=await fetch(base+`/api/projects/${id}`,{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({description:'Desc',progress:30,status:'in_progress',expectedVersion:1,idempotencyKey:'http-update-1'})}); d=await json(r); assert.equal(r.status,200); assert.equal(d.project.version,2); assert.equal(d.project.description,'Desc'); assert.equal(d.project.title,'HTTP Project');
  r=await fetch(base+`/api/projects/${id}`,{method:'PUT',headers:{'content-type':'application/json'},body:JSON.stringify({description:'stale',expectedVersion:1,idempotencyKey:'http-update-2'})}); d=await json(r); assert.equal(r.status,409); assert.equal(d.code,'PROJECT_VERSION_CONFLICT');
  r=await fetch(base+'/offline-sync.js'); assert.equal(r.status,200); assert.match(await r.text(),/PuntIAOfflineSync/);
  r=await fetch(base+'/sw.js'); assert.equal(r.status,200); assert.match(await r.text(),new RegExp('puntia-'+require('../package.json').version.replace(/\./g,'\\.')+'-shell-v1'));
  r=await fetch(base+`/api/projects/${id}`,{method:'DELETE'}); d=await json(r); assert.equal(r.status,200); assert.equal(d.deleted,id);
  r=await fetch(base+`/api/projects/${id}`); assert.equal(r.status,404);
  await new Promise(resolve=>server.close(resolve));
  try { if(backup===null) fs.rmSync(dataFile,{force:true}); else fs.writeFileSync(dataFile,backup,{mode:0o600}); } catch {}
  console.log('PROJECT_LIFECYCLE_HTTP_E2E: PASS');
})().catch(async e=>{try{await new Promise(resolve=>server.close(resolve))}catch{};try{if(backup===null)fs.rmSync(dataFile,{force:true});else fs.writeFileSync(dataFile,backup,{mode:0o600})}catch{};console.error('PROJECT_LIFECYCLE_HTTP_E2E: FAIL');console.error(e.stack||e);process.exit(1)});
