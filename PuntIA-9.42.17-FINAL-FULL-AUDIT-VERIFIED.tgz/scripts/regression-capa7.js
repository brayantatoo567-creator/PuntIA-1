'use strict';
const assert = require('assert');
const { createTutorialService } = require('../src/application/tutorial-service');
const validPattern={title:'Esfera de prueba',initialStitches:6,materials:['Estambre'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:1,repeats:6}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:2,repeats:3}],expectedStitches:9}],assembly:['Rellenar y cerrar'],notes:['Contar puntos']};
const service=createTutorialService({validatePattern:p=>({qualityOk:p===validPattern,quality:100})});
const tutorial=service.create(validPattern); assert.equal(tutorial.steps.length,2); assert.equal(tutorial.steps[1].expectedStitches,9); assert.match(tutorial.steps[1].actions[0],/aumento/); assert.throws(()=>service.create({...validPattern,title:'invalid'}),/Quality Gate/); console.log('Capa 7 regression: PASS');
