'use strict';
const assert = require('node:assert/strict');
const http = require('http');

const valid = {title:'HTTP Test',initialStitches:6,materials:['hilo'],abbreviations:['pb'],rounds:[
  {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
  {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}
],assembly:['unir'],notes:[],geometry:{type:'sphere',targetHeightCm:8}};
let providerCalls=0;
const provider=http.createServer((req,res)=>{
  if(req.method==='POST' && req.url==='/responses'){
    providerCalls++;
    let raw=''; req.on('data',c=>raw+=c); req.on('end',()=>{
      const body=JSON.parse(raw);
      assert(body.model);
      res.writeHead(200,{'Content-Type':'application/json'});
      res.end(JSON.stringify({output_text:JSON.stringify(valid)}));
    });
    return;
  }
  res.writeHead(404); res.end();
});
(async()=>{
  await new Promise(resolve=>provider.listen(0,'127.0.0.1',resolve));
  const port=provider.address().port;
  process.env.PORT='0';
  process.env.OPENAI_API_KEY='sk-'+'a'.repeat(24);
  process.env.OPENAI_API_BASE_URL=`http://127.0.0.1:${port}`;
  process.env.PUNTIA_REQUIRE_ACCOUNT_FOR_AI='false';
  process.env.PUNTIA_REQUIRE_CSRF='false';
  process.env.PUNTIA_ALLOW_LOCAL_CONFIG='true';
  const {createHttpRuntime}=require('../src/infrastructure/http/runtime');
  const server=createHttpRuntime();
  await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);server.listen(0,'127.0.0.1');});
  const address=server.address();
  const response=await fetch(`http://127.0.0.1:${address.port}/api/puntia/generate-pattern`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'Dragón rojo',level:'Principiante',height:'18 cm',style:'kawaii'})});
  const data=await response.json();
  assert.equal(response.status,200);
  assert.equal(data.ok,true);
  assert.equal(data.validation.qualityOk,true);
  assert.equal(data.persisted,false);
  assert.equal(data.mode,'provider');
  assert.equal(providerCalls,1);
  await new Promise(resolve=>server.close(resolve));
  await new Promise(resolve=>provider.close(resolve));
  console.log('PATTERN_GENERATION_HTTP_E2E: PASS');
})().catch(async e=>{console.error(e.stack||e);try{provider.close()}catch{};process.exit(1)});
