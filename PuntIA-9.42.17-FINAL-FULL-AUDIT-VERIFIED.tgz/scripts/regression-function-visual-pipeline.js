'use strict';
const assert=require('node:assert/strict');
const {createPatternVisualService}=require('../src/application/pattern-visual-service');
const {createPatternVisualValidationService}=require('../src/application/pattern-visual-validation-service');
const {createVisualAssetLifecycleService}=require('../src/application/visual-asset-lifecycle-service');
const {validatePattern,extractFirstJsonObject}=require('../src/core/pattern-engine');
const pattern={title:'Dragón tejido',initialStitches:6,materials:['hilo rojo','hilo negro'],abbreviations:['pb'],rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],assembly:['unir alas y cola'],notes:['ojos negros'],geometry:{type:'body',targetHeightCm:12}};
const crypto=require('crypto');
const hash=p=>crypto.createHash('sha256').update(JSON.stringify(p)).digest('hex');

async function main(){
  const projects=new Map();
  const services={
    projects:{
      get:(u,id)=>projects.get(id)||null,
      update:(u,id,input)=>{const p=projects.get(id);assert.equal(input.expectedVersion,p.version);const next={...p,...input,version:p.version+1,updatedAt:new Date().toISOString()};projects.set(id,next);return next;}
    },
    usage:{async reserve(u,k){return {allowed:true,reservationId:`${k}-${Math.random()}`,limit:99}},async confirm(u,k,id){this.confirmed=(this.confirmed||0)+1},async release(u,k,id){this.released=(this.released||0)+1}},
    costAccounting:{recordProviderUsage(){this.calls=(this.calls||0)+1}},
    audit:{record:async()=>{}},
    observability:null
  };
  const deps={runtime:{imageModel:'img-test',visionModel:'vision-test',textModel:'text-test'},IMAGE_MODEL_DEFAULT:'img-test',IMAGE_SIZE:'1024x1024',VISION_MODEL_DEFAULT:'vision-test',CHAT_MODEL:'text-test',validatePattern,extractFirstJsonObject,outputText:x=>x.output_text||'',openaiPost:async(path,payload)=>({model:'img-test',data:[{b64_json:Buffer.from('fakepng').toString('base64')}]}),openaiPostModelFallback:async()=>({model:'vision-test',fallback:false,data:{output_text:JSON.stringify({matchesPattern:true,confidence:.95,criticalMismatches:[],observations:['coherent']})}})};
  const lifecycle=createVisualAssetLifecycleService({projectStore:()=>[],cloud:null},services);
  services.visualAssets=lifecycle;
  let put=0;
  deps.objectStorage={async put(){put++;return{}},async remove(){}};
  services.patternVisualValidation=createPatternVisualValidationService(deps,services);
  projects.set('p1',{id:'p1',ownerId:'u1',version:1,status:'pattern_ready',progress:0,assets:[]});
  const visual=createPatternVisualService(deps,services);
  const out=await visual.generate({user:{id:'u1'},pattern,projectId:'p1'});
  assert.equal(out.ok,true); assert.equal(out.attempts,1); assert.equal(out.visualValidation.accepted,true);
  const p=projects.get('p1'); const a=p.assets.find(x=>x.id===out.assetId);
  assert.equal(a.state,'accepted'); assert.equal(a.patternHash,hash(pattern)); assert.match(a.key,/pattern-visuals/); assert.equal(a.metadata.patternHash,hash(pattern));
  assert.equal(put,1); assert.equal(services.usage.confirmed,2); assert.equal(services.usage.released||0,0);
  console.log('VISUAL_PIPELINE_ACCEPTED_ONLY_AFTER_STORAGE: PASS');
  console.log('VISUAL_PIPELINE_PATTERN_PROJECT_BINDING: PASS');
  console.log('VISUAL_PIPELINE_PATTERN_HASH_BINDING: PASS');
  console.log('VISUAL_PIPELINE_QUOTA_RECONCILIATION: PASS');
}
main().catch(e=>{console.error('VISUAL_PIPELINE_E2E: FAIL');console.error(e.stack||e);process.exit(1)});
