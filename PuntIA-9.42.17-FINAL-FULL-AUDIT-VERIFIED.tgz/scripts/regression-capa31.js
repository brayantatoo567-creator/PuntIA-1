'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const handleBilling=require('../src/routes/billing');
const handleAdmin=require('../src/routes/admin');
const {createBillingService}=require('../src/application/billing-service');

function response(){const chunks=[];return {headers:{},statusCode:200,writableEnded:false,setHeader(k,v){this.headers[k]=String(v)},end(v=''){this.writableEnded=true;chunks.push(String(v))},get body(){try{return JSON.parse(chunks.join('')||'{}')}catch{return chunks.join('')}}};}
async function call(route,{method='GET',p='/',body=null,headers={},depsExtra={},servicesExtra={}}={}){
 const res=response();const req={method,url:p,headers};const state={u1:{plan:'premium',status:'active',access:true,customerId:'cus_1',subscriptionId:'sub_1',currentPeriodEnd:new Date(Date.now()+86400000).toISOString(),cancelAtPeriodEnd:false}};const calls=[];
 const deps={USERS_FILE:'users.json',SUBSCRIPTIONS_FILE:'billing-subscriptions.json',STRIPE_EVENTS_FILE:'events.json',STRIPE_SECRET_KEY:'sk_test_x',STRIPE_WEBHOOK_SECRET:'whsec',STRIPE_PRICES:{plus:'price_plus',pro:'price_pro'},PUBLIC_URL:'https://puntia.test',BILLING_GRACE_DAYS:3,DATA_DIR:process.cwd(),LIMIT_BODY:1024*1024,
  send:(r,s,d)=>{r.statusCode=s;r.end(JSON.stringify(d))},jsonError:(r,s,m,c)=>{r.statusCode=s;r.end(JSON.stringify({ok:false,error:m,code:c}))},readBody:async()=>Buffer.from(body||''),readJson:async()=>body||{},safeText:v=>String(v??'').trim(),
  currentUser:()=>({id:'u1',email:'u@example.com',name:'U',plan:'premium',role:'admin'}),publicUser:u=>u,usagePayload:()=>({plan:'premium',used:{pattern:2},limits:{pattern:80}}),requireUser:()=>({id:'u1',email:'u@example.com',name:'U',plan:'premium',role:'admin'}),requireAdmin:()=>true,
  validatePlan:p=>['free','premium','pro'].includes(p)?p:'free',billingEffectiveLocal:id=>state[id]||{plan:'free',status:'none',access:false},saveLocalBillingState:(id,input)=>{state[id]={plan:input.plan,status:input.status,access:['active','trialing','past_due'].includes(input.status),customerId:input.customerId,subscriptionId:input.subscriptionId};return state[id]},
  loadJsonFile:file=>String(file).includes('billing-subscriptions')?{'u1':state.u1}:[],saveJsonFile:()=>{},trackEvent:()=>{},requestId:()=> 'req-12345678',stripeSignatureValid:()=>true,
  stripeRequest:async(pathname,b,opts)=>{calls.push({pathname,b,opts});if(pathname==='invoices')return {data:[{id:'in_1',status:'paid',amount_paid:9900,currency:'mxn',created:Date.now()/1000,hosted_invoice_url:'https://invoice.test'}],has_more:false};if(pathname.startsWith('subscriptions/'))return {id:'sub_1',status:'active',cancel_at_period_end:b.cancel_at_period_end==='true',current_period_end:Math.floor(Date.now()/1000)+86400};return {id:'cs_1',url:'https://checkout.test'}},
  cloud:null,...depsExtra};
 const services={audit:{record:async()=>{}},billing:createBillingService({FREE_LIMITS:{pattern:5},PREMIUM_LIMITS:{pattern:80},PRO_LIMITS:{pattern:250},usagePayload:deps.usagePayload,validatePlan:deps.validatePlan,billingEffectiveLocal:deps.billingEffectiveLocal}),...servicesExtra};
 await route({req,res,p,deps,services,url:new URL(`https://puntia.test${p}`)});return {res,calls};
}
(async()=>{
 const svc=createBillingService({FREE_LIMITS:{pattern:5},PREMIUM_LIMITS:{pattern:80},PRO_LIMITS:{pattern:250},usagePayload:()=>({}),validatePlan:p=>p,billingEffectiveLocal:()=>({plan:'free'})});
 assert.strictEqual(svc.plans().premium.price,99); assert.strictEqual(svc.plans().pro.price,199);
 let r=await call(handleBilling,{p:'/api/billing/status'});assert.strictEqual(r.res.statusCode,200);assert.strictEqual(r.res.body.subscription.plan,'premium');assert.ok(r.res.body.usage);
 r=await call(handleBilling,{p:'/api/billing/plans'});assert.strictEqual(r.res.statusCode,200);assert.ok(r.res.body.plans.pro);
 r=await call(handleBilling,{p:'/api/billing/invoices'});assert.strictEqual(r.res.statusCode,200);assert.strictEqual(r.res.body.invoices[0].status,'paid');assert.strictEqual(r.calls[0].opts.method,'GET');
 r=await call(handleBilling,{method:'POST',p:'/api/billing/cancel',headers:{'idempotency-key':'idem-12345678'}});assert.strictEqual(r.res.statusCode,200);assert.strictEqual(r.res.body.cancelAtPeriodEnd,true);
 r=await call(handleBilling,{method:'POST',p:'/api/billing/resume',headers:{'idempotency-key':'idem-12345679'}});assert.strictEqual(r.res.statusCode,200);assert.strictEqual(r.res.body.cancelAtPeriodEnd,false);
 r=await call(handleBilling,{method:'POST',p:'/api/billing/change-plan',body:{plan:'pro'},headers:{'idempotency-key':'idem-12345680'}});assert.strictEqual(r.res.statusCode,200);assert.strictEqual(r.res.body.plan,'pro');
 r=await call(handleAdmin,{p:'/api/admin/billing/overview'});assert.strictEqual(r.res.statusCode,200);assert.ok(r.res.body.metrics);assert.ok(Array.isArray(r.res.body.subscriptions));
 const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8');const js=fs.readFileSync(path.join(__dirname,'../public/app.js'),'utf8');assert.ok(html.includes('billingPlans'));assert.ok(html.includes('view-admin'));assert.ok(js.includes('/api/billing/change-plan'));assert.ok(js.includes('/api/admin/billing/overview'));
 console.log('Capa 31 regression: PASS');
})().catch(e=>{console.error('Capa 31 regression: FAIL',e);process.exit(1)});
