'use strict';
const assert = require('node:assert/strict');
const { buildPatternReader, validatePatternReader, operationText } = require('../src/core/pattern-reader');
const { validatePattern } = require('../src/core/pattern-engine');

const pattern = {
  title: 'Dragón', initialStitches: 6,
  materials: ['estambre azul', 'relleno', 'aguja 3 mm'],
  abbreviations: ['pb', 'aum', 'dis'],
  rounds: [
    { round:1, inputStitches:6, operations:[{type:'single',count:6,repeats:1}], expectedStitches:6 },
    { round:2, inputStitches:6, operations:[{type:'increase',count:1,repeats:6}], expectedStitches:12 },
    { round:3, inputStitches:12, operations:[{type:'decrease',count:1,repeats:6}], expectedStitches:6 }
  ],
  assembly:['Coser la cabeza al cuerpo.'], notes:[], geometry:{type:'body',targetHeightCm:15},
  piecePlans:[{
    id:'body', name:'Cuerpo', quantity:1, geometry:'body', targetHeightCm:8,
    rounds:[
      { round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6 },
      { round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12 }
    ], materials:['estambre'], abbreviations:['pb','aum'], assembly:['Unir al resto del proyecto.']
  }]
};
assert.equal(operationText({type:'single',count:6,repeats:1}), '6 pb');
assert.equal(operationText({type:'increase',count:1,repeats:6}), 'aum × 6');
console.log('PATTERN_READER_OPERATION_TRANSLATION: PASS');
const reader = buildPatternReader(pattern);
assert.equal(reader.ok, true, reader.issues?.join(' | '));
assert.equal(reader.rounds.length, pattern.rounds.length);
assert.equal(reader.rounds[1].instruction, 'aum × 6');
console.log('PATTERN_READER_ROUNDS: PASS');
assert.equal(reader.pieces.length, 1);
assert.equal(reader.pieces[0].rounds.length, 2);
console.log('PATTERN_READER_PIECES: PASS');
assert.equal(reader.guidedSteps.at(-1).type, 'assembly');
assert.ok(reader.guidedSteps.some(s=>s.type==='round' && s.round===2));
console.log('PATTERN_READER_GUIDED_STEPS: PASS');
const valid = validatePatternReader(pattern, reader);
assert.equal(valid.ok, true, valid.issues.join(' | '));
console.log('PATTERN_READER_PRESERVES_MATH: PASS');
const broken = structuredClone(pattern); broken.rounds[1].expectedStitches = 99;
assert.equal(validatePatternReader(broken, reader).ok, false);
console.log('PATTERN_READER_REJECTS_MATH_DRIFT: PASS');
assert.equal(validatePattern(pattern, {strict:true}).qualityOk, true);
console.log('PATTERN_READER_COMPATIBILITY: PASS');
