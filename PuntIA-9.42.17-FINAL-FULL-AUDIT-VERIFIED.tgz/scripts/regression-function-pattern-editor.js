'use strict';
const assert = require('node:assert/strict');
const { editPattern, resizePattern } = require('../src/core/pattern-editor');
const { validatePattern } = require('../src/core/pattern-engine');
const { interpretConcept } = require('../src/core/concept-decomposition');

function mainPattern(){return {title:'Dragón',initialStitches:6,materials:['hilo'],abbreviations:['pb','aum','dis'],rounds:[
  {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
  {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12},
  {round:3,inputStitches:12,operations:[{type:'increase',count:1,repeats:12}],expectedStitches:24},
  {round:4,inputStitches:24,operations:[{type:'decrease',count:1,repeats:12}],expectedStitches:12},
  {round:5,inputStitches:12,operations:[{type:'decrease',count:1,repeats:6}],expectedStitches:6}],
  assembly:['Cuerpo principal','Cabeza','Alas','Cola','Cuernos'],notes:[],geometry:{type:'body',targetHeightCm:15},
  piecePlans:[{id:'body',name:'Cuerpo principal',quantity:1,geometry:'body',initialStitches:6,rounds:[
    {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
    {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],targetHeightCm:8,materials:['hilo'],abbreviations:['pb','aum','dis'],assembly:['Cuerpo principal.']},
    {id:'head',name:'Cabeza',quantity:1,geometry:'head',initialStitches:6,rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],targetHeightCm:4,materials:['hilo'],abbreviations:['pb','aum','dis'],assembly:['Unir al cuerpo.']},
    {id:'wings',name:'Alas',quantity:2,geometry:'wing',initialStitches:6,rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}],targetHeightCm:3,materials:['hilo'],abbreviations:['pb','aum','dis'],assembly:['Unir al cuerpo.']},
    {id:'tail',name:'Cola',quantity:1,geometry:'tail',initialStitches:6,rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6}],targetHeightCm:3,materials:['hilo'],abbreviations:['pb','aum','dis'],assembly:['Unir al cuerpo.']},
    {id:'horns',name:'Cuernos',quantity:1,geometry:'cone',initialStitches:6,rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'decrease',count:1,repeats:3}],expectedStitches:3}],targetHeightCm:2,materials:['hilo'],abbreviations:['pb','aum','dis'],assembly:['Unir a la cabeza.']}]
};}

const concept=interpretConcept({description:'Dragón azul con alas, cuernos y cola de 15 cm'});
const base=mainPattern();
const resized=resizePattern(base,2);
assert.equal(validatePattern(resized,{strict:true}).qualityOk,true);
assert.equal(resized.initialStitches,12);
assert.equal(resized.rounds[1].inputStitches,12);
assert.equal(resized.rounds[1].expectedStitches,24);
console.log('PATTERN_EDITOR_RESIZE_RECALCULATES_MATH: PASS');
assert.equal(resized.geometry.targetHeightCm,30);
assert.equal(resized.piecePlans[0].targetHeightCm,16);
console.log('PATTERN_EDITOR_RESIZE_RECALCULATES_DIMENSIONS: PASS');

const edited=editPattern({pattern:base,concept,changes:{sizeScale:2,colors:['azul','negro'],difficulty:'Intermedio',pieces:{rename:[{id:'tail',name:'Cola larga'}],remove:['head']}}});
assert.equal(edited.ok,true);
assert.equal(edited.changed,true);
assert.deepEqual(edited.pattern.design.colors,['azul','negro']);
assert.equal(edited.pattern.design.difficulty,'Intermedio');
assert.ok(!edited.pattern.piecePlans.some(p=>p.id==='head'));
assert.equal(edited.pattern.piecePlans.find(p=>p.id==='tail').name,'Cola larga');
assert.equal(edited.validation.qualityOk,true);
assert.equal(edited.execution.ok,true);
assert.equal(edited.readerValidation.ok,true);
console.log('PATTERN_EDITOR_MULTI_CHANGE: PASS');

assert.throws(()=>editPattern({pattern:base,concept,changes:{pieces:{remove:['wings']}}}),e=>e.code==='EDITOR_REQUIRED_PIECE');
console.log('PATTERN_EDITOR_REJECTS_REQUIRED_PIECE_REMOVAL: PASS');
assert.throws(()=>editPattern({pattern:base,changes:{sizeScale:0.01}}),e=>e.code==='EDITOR_INVALID_SIZE_SCALE');
console.log('PATTERN_EDITOR_REJECTS_INVALID_SCALE: PASS');
assert.throws(()=>editPattern({pattern:{...base,rounds:base.rounds.map((r,i)=>i===1?({...r,expectedStitches:99}):r)},changes:{colors:['rojo']}}),e=>e.code==='EDITOR_QUALITY_GATE' || e.code==='EDITOR_EXECUTION_FAILED');
console.log('PATTERN_EDITOR_REJECTS_INVALID_PATTERN: PASS');

const original=JSON.stringify(base);
assert.equal(JSON.stringify(base),original);
console.log('PATTERN_EDITOR_IMMUTABLE_INPUT: PASS');
console.log('FUNCTION_8_PATTERN_EDITOR: PASS');
