'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'..');
const index=fs.readFileSync(path.join(root,'index.html'),'utf8');
const staticFiles=fs.readFileSync(path.join(root,'src/infrastructure/http/transport/static-files.js'),'utf8');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'));
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
assert.match(index,/href="\/css\/app\.css"/); assert.match(index,/src="\/js\/app\.js"/);
assert.match(staticFiles,/pathname === '\/css\/app\.css'\) relative = 'app\.css'/); assert.match(staticFiles,/pathname === '\/js\/app\.js'\) relative = 'app\.js'/);
const expectedFiles={'/css/app.css':'public/app.css','/js/app.js':'public/app.js','/offline-sync.js':'public/offline-sync.js','/assets/icons/icon-192.png':'public/assets/icons/icon-192.png','/assets/icons/icon-512.png':'public/assets/icons/icon-512.png','/assets/mascot/puntia-maestra-v2.svg':'public/assets/mascot/puntia-maestra-v2.svg'};
for(const [url,file] of Object.entries(expectedFiles)) assert(fs.existsSync(path.join(root,file)),`missing asset ${url}`);
for(const icon of manifest.icons){assert.equal(icon.type,'image/png');assert.match(icon.src,/^\/assets\/icons\/icon-(192|512)\.png$/);assert(fs.existsSync(path.join(root,'public',icon.src.replace(/^\//,''))));}
assert.equal(manifest.version,require('../package.json').version);assert.match(sw,new RegExp('puntia-'+require('../package.json').version.replace(/\./g,'\\.')+'-shell-v1'));assert(!sw.includes('9.38'));
(async()=>{
  const {createHttpRuntime}=require('../src/infrastructure/http/runtime');
  process.env.NODE_ENV='development'; process.env.PUNTIA_PUBLIC_URL='http://127.0.0.1:0';
  const server=createHttpRuntime();
  await new Promise((resolve,reject)=>{server.once('listening',resolve);server.once('error',reject);server.listen(0,'127.0.0.1')});
  const base=`http://127.0.0.1:${server.address().port}`;
  for(const [url, expectedType] of [['/js/app.js','text/javascript'],['/css/app.css','text/css'],['/assets/icons/icon-192.png','image/png'],['/assets/icons/icon-512.png','image/png'],['/sw.js','text/javascript']]){
    const r=await fetch(base+url);assert.equal(r.status,200,url);assert.match(String(r.headers.get('content-type')||''),new RegExp(expectedType.replace('/','\\/')),url);
  }
  const html=await (await fetch(base+'/')).text();assert.match(html,/\/js\/app\.js/);assert.match(html,/\/css\/app\.css/);
  await new Promise(resolve=>server.close(resolve));
  console.log('RELEASE_WEB_ASSETS_E2E: PASS');
})().catch(e=>{console.error('RELEASE_WEB_ASSETS_E2E: FAIL');console.error(e.stack||e);process.exit(1)});
