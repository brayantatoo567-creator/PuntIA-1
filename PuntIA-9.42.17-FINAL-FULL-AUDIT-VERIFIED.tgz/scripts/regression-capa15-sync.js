'use strict';
const assert=require('node:assert/strict');
const {createConflictResolutionService}=require('../src/application/conflict-resolution-service');
const {createProjectService}=require('../src/application/project-service');
const {createSyncService}=require('../src/application/sync-service');
(async()=>{
 let store=[]; const deps={projectStore:()=>store,saveProjects:v=>{store=v},MAX_PROJECTS_TOTAL:100,MAX_PROJECTS:50};
 const projects=createProjectService(deps), conflicts=createConflictResolutionService(), sync=createSyncService(deps,conflicts), user={id:'u15'};
 const created=projects.create(user,{id:'p15',title:'Base',description:'Base',progress:10,pattern:'P1'});
 const base=JSON.parse(JSON.stringify(created));
 projects.update(user,'p15',{description:'Remote',expectedVersion:1});
 const result=await sync.push({user,items:[{...base,title:'Local',expectedVersion:1,baseProject:base}],projectService:projects});
 assert.equal(result.results[0].status,'merged');
 const final=projects.get(user,'p15'); assert.equal(final.title,'Local'); assert.equal(final.description,'Remote'); assert.equal(final.version,3);
 console.log('CAPA15_SYNC_INTEGRATION_MERGE: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1);});
