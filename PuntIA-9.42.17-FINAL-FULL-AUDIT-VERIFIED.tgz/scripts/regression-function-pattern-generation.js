'use strict';
const assert = require('node:assert/strict');
const { createPatternService } = require('../src/application/pattern-service');
const { createPatternGenerationPipeline } = require('../src/application/pattern-generation-pipeline');
const { validatePattern } = require('../src/core/pattern-engine');

function validPattern(title='Test') {
  return {title,initialStitches:6,materials:['hilo'],abbreviations:['pb'],rounds:[
    {round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},
    {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}
  ],assembly:['unir'],notes:[],geometry:{type:'sphere',targetHeightCm:8}};
}
function baseDeps(provider) {
  return {
    SYSTEM:'TEST', PATTERN_MODEL:'primary', CHAT_MODEL:'fallback', runtime:{patternModel:'primary',textModel:'fallback'},
    safeText:(v,n)=>String(v??'').slice(0,n), validatePattern, extractFirstJsonObject:raw=>{try{return JSON.parse(raw)}catch{return null}},
    outputText:d=>d?.output_text||'', recordCost:()=>{}, estimateCost:()=>1, openaiPostModelFallback:provider
  };
}
function makeServices(deps, opts={}) {
  const calls=opts.calls || {reserve:0,confirm:0,release:0};
  const services={
    pattern:createPatternService(deps),
    usage:{
      async reserve(){calls.reserve++; return opts.quota || {allowed:true,reservationId:'r',limit:5};},
      async confirm(){calls.confirm++; return {ok:true,state:'confirmed'};},
      async release(){calls.release++; return {ok:true,state:'released'};}
    },
    audit:{record:async()=>{}}, observability:{run:async(_n,fn)=>fn()}
  };
  return {services,calls};
}
(async()=>{
  // 1. Happy path + exact usage accounting.
  { let calls=0; const deps=baseDeps(async()=>({model:'test',data:{output_text:JSON.stringify(validPattern('happy'))}}));
    const {services,calls:usage}=makeServices(deps); const p=createPatternGenerationPipeline(deps,services);
    const r=await p.generate({user:{id:'u'},input:{name:'Dragón'}});
    assert.equal(r.ok,true); assert.equal(r.validation.qualityOk,true); assert.equal(r.persisted,false); assert.equal(r.mode,'provider');
    assert.equal(usage.reserve,1); assert.equal(usage.confirm,1); assert.equal(usage.release,0); calls++;
    console.log('PATTERN_GENERATION_HAPPY_PATH: PASS'); }

  // 2. Invalid first provider output must repair and revalidate.
  { let n=0; const deps=baseDeps(async()=>({model:'test',data:{output_text:JSON.stringify(n++===0?(()=>{const x=validPattern('bad');x.rounds[1].expectedStitches=11;return x;})():validPattern('repaired'))}}));
    const {services,calls}=makeServices(deps); const p=createPatternGenerationPipeline(deps,services); const r=await p.generate({user:{id:'u'},input:{name:'Gato'}});
    assert.equal(r.repaired,true); assert.equal(r.attempts,2); assert.equal(calls.confirm,1); assert.equal(calls.release,0);
    console.log('PATTERN_GENERATION_REPAIR: PASS'); }

  // 3. Provider never returns valid -> no persistence, reservation released.
  { const deps=baseDeps(async()=>({model:'test',data:{output_text:JSON.stringify(()=>{})}}));
    deps.openaiPostModelFallback=async()=>{const x=validPattern('bad');x.rounds[1].expectedStitches=999;return {model:'test',data:{output_text:JSON.stringify(x)}}};
    const {services,calls}=makeServices(deps); const p=createPatternGenerationPipeline(deps,services);
    await assert.rejects(()=>p.generate({user:{id:'u'},input:{name:'Fallo'}}),e=>e.code==='PATTERN_QUALITY_GATE');
    assert.equal(calls.confirm,0); assert.equal(calls.release,1);
    console.log('PATTERN_GENERATION_REJECTS_INVALID: PASS'); }

  // 4. Quota denied => provider is never called.
  { let providerCalls=0; const deps=baseDeps(async()=>{providerCalls++;return {model:'x',data:{output_text:JSON.stringify(validPattern())}}});
    const {services,calls}=makeServices(deps,{quota:{allowed:false,limit:5}}); const p=createPatternGenerationPipeline(deps,services);
    await assert.rejects(()=>p.generate({user:{id:'u'},input:{name:'Cuota'}}),e=>e.code==='USAGE_LIMIT');
    assert.equal(providerCalls,0); assert.equal(calls.release,0);
    console.log('PATTERN_GENERATION_QUOTA_GATE: PASS'); }

  // 5. Explicit persistence without an adapter must fail closed.
  { const deps=baseDeps(async()=>({model:'x',data:{output_text:JSON.stringify(validPattern())}})); const {services,calls}=makeServices(deps); const p=createPatternGenerationPipeline(deps,services);
    await assert.rejects(()=>p.generate({user:{id:'u'},input:{name:'Persistencia'},persist:true}),e=>e.code==='PATTERN_PERSISTENCE_UNAVAILABLE');
    assert.equal(calls.confirm,0); assert.equal(calls.release,1);
    console.log('PATTERN_GENERATION_PERSISTENCE_FAIL_CLOSED: PASS'); }

  // 6. Input contract.
  { const deps=baseDeps(async()=>({model:'x',data:{output_text:JSON.stringify(validPattern())}})); const {services}=makeServices(deps); const p=createPatternGenerationPipeline(deps,services);
    await assert.rejects(()=>p.generate({user:{id:'u'},input:{name:'   '}}),e=>e.code==='MISSING_PATTERN_NAME');
    console.log('PATTERN_GENERATION_INPUT_CONTRACT: PASS'); }

  console.log('PATTERN_GENERATION_FUNCTION: PASS');
})().catch(e=>{console.error(e.stack||e);process.exit(1);});
