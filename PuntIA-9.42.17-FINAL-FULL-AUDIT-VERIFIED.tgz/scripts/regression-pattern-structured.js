'use strict';
const assert = require('node:assert/strict');
const { createPatternService, PATTERN_JSON_SCHEMA } = require('../src/application/pattern-service');
const { validatePattern } = require('../src/core/pattern-engine');

const deps = { validatePattern, extractFirstJsonObject: JSON.parse, safeText: (v,n) => String(v ?? '').slice(0,n) };
const service = createPatternService(deps);
const format = service.responseFormat();
assert.equal(format.type, 'json_schema');
assert.equal(format.name, 'puntia_pattern');
assert.equal(format.strict, true);
assert.equal(format.schema, PATTERN_JSON_SCHEMA);
assert.ok(format.schema.additionalProperties === false);
assert.ok(format.schema.properties.rounds.items.properties.operations.items.properties.type.enum.includes('increase'));
const valid = { title:'Prueba', initialStitches:6, materials:['hilo'], abbreviations:['pb'], rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:6,repeats:1}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12}], assembly:['unir'], notes:[] };
assert.equal(service.qualityGate(valid).qualityOk, true);
console.log('STRUCTURED_PATTERN_SCHEMA: PASS');
