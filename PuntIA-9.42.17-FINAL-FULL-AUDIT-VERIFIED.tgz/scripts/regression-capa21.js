'use strict';
const assert = require('assert');
const { createObservabilityService } = require('../src/application/observability-service');

(async () => {
  const auditRows=[];
  const audit={record: async e=>auditRows.push(e)};
  const obs=createObservabilityService({}, {audit});

  const ok=await obs.run('provider-test', async()=>42);
  assert.equal(ok,42);
  assert.equal(obs.snapshot().metrics['provider-test'].count,1);

  for(let i=0;i<3;i++){
    try { await obs.run('flaky', async()=>{ throw Object.assign(new Error('upstream'),{code:'UPSTREAM_5XX'}); }, {threshold:3}); } catch(e) {}
  }
  const open=obs.health();
  assert.equal(open.openCircuits,1);
  await assert.rejects(()=>obs.run('flaky', async()=>99), e=>e.code==='CIRCUIT_OPEN');
  assert.ok(auditRows.some(e=>e.action==='provider.circuit_open'));
  obs.reset('flaky');
  assert.equal(await obs.run('flaky', async()=>99),99);
  assert.equal(obs.health().openCircuits,0);

  console.log('Capa 21 regression: PASS');
})().catch(error=>{console.error(error);process.exit(1);});
