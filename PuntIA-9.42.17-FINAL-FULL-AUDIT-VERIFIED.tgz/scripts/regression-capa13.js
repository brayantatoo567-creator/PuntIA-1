'use strict';
const assert=require('assert');
const {createProjectService}=require('../src/application/project-service');
const {createJobService}=require('../src/application/job-service');

const user={id:'user-c13',plan:'free'};
let projects=[];
const pdeps={
  MAX_PROJECTS_TOTAL:50,MAX_PROJECTS:20,
  projectStore:()=>projects,saveProjects:v=>{projects=v},
};
const ps=createProjectService(pdeps);
const created=ps.create(user,{title:'Proyecto C13'});
const first=ps.update(user,created.id,{title:'Cambio 1',expectedVersion:1,idempotencyKey:'mut-001'});
assert.equal(first.version,2);
const replay=ps.update(user,created.id,{title:'Cambio 1',expectedVersion:1,idempotencyKey:'mut-001'});
assert.equal(replay.version,2);
assert.equal(projects[0].version,2);
let conflict=false;
try{ps.update(user,created.id,{title:'Cambio 2',expectedVersion:1,idempotencyKey:'mut-002'});}catch(e){conflict=e.code==='PROJECT_VERSION_CONFLICT'&&e.status===409;}
assert(conflict,'stale mutation must conflict');

let reservations=0;
const jobs={};
const jdeps={
  safeText:(v,max)=>String(v||'').slice(0,max),
  findJobByIdempotency:(kind,owner,key)=>Object.values(jobs).find(j=>j.kind===kind&&j.ownerId===owner&&j.idempotencyKey===key&&['queued','running','completed'].includes(j.status))||null,
  createJob:(kind,owner,meta)=>{const id='job-'+(Object.keys(jobs).length+1); const j={id,kind,ownerId:owner,status:'queued',idempotencyKey:meta.idempotencyKey,meta};jobs[id]=j;return j;},
  updateJob:(id,p)=>{jobs[id]={...jobs[id],...p};return jobs[id]},
  enqueueLocalJob:()=>{},
  openaiPostModelFallback:async()=>({data:{output_text:'{}'},model:'test'}),
  outputText:()=>'',SYSTEM:'',PATTERN_MODEL:'',CHAT_MODEL:'',recordCost:()=>{},estimateCost:()=>0,confirmUsage:async()=>({ok:true})
};
const services={
  usage:{reserve:async()=>{reservations++;return {allowed:true,reservationId:'res-'+reservations}},},
  pattern:{buildPrompt:()=>'',extract:()=>({}),qualityGate:()=>({ok:true})}
};
const js=createJobService(jdeps,services);
(async()=>{
  const a=await js.createPatternJob({user,input:{name:'Dragon',idempotencyKey:'job-key-1'}});
  const b=await js.createPatternJob({user,input:{name:'Dragon',idempotencyKey:'job-key-1'}});
  assert.equal(a.id,b.id);
  assert.equal(reservations,1,'idempotent retry must not reserve usage twice');
  console.log('Capa 13 regression: PASS');
})().catch(e=>{console.error('Capa 13 regression: FAIL',e.message);process.exitCode=1});
