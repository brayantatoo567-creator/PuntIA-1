'use strict';
const assert = require('node:assert/strict');
const { executePattern, validateExecutablePattern } = require('../src/core/pattern-execution');
const { validatePattern } = require('../src/core/pattern-engine');

function base() {
  return { title:'Ejecución', initialStitches:6, materials:['hilo'], abbreviations:['pb','aum','dis'], rounds:[
    {round:1,inputStitches:6,operations:[{type:'single',count:1,repeats:6}],expectedStitches:6},
    {round:2,inputStitches:6,operations:[{type:'increase',count:1,repeats:6}],expectedStitches:12},
    {round:3,inputStitches:12,operations:[{type:'single',count:1,repeats:6},{type:'decrease',count:1,repeats:3}],expectedStitches:9}
  ], assembly:['cerrar y rellenar'], notes:[] };
}

const p = base();
const e = executePattern(p);
assert.equal(e.ok, true);
assert.equal(e.finalStitches, 9);
assert.equal(e.trace[1].operations[0].consumed, 6);
assert.equal(e.trace[1].operations[0].produced, 12);
assert.equal(validateExecutablePattern(p).ok, true);
assert.equal(validatePattern(p, {strict:true}).ok, true);

const mismatch = base();
mismatch.rounds[2].inputStitches = 11;
assert.equal(executePattern(mismatch).ok, false);
assert.match(executePattern(mismatch).errors.join('\n'), /entrada declarada 11/);

const overconsume = base();
overconsume.rounds[0].operations = [{type:'decrease',count:1,repeats:4}];
overconsume.rounds[0].expectedStitches = 2;
assert.equal(executePattern(overconsume).ok, false);
assert.match(executePattern(overconsume).errors.join('\n'), /solo quedan 6/);

const badExpected = base();
badExpected.rounds[1].expectedStitches = 11;
assert.equal(validateExecutablePattern(badExpected).ok, false);
assert.match(validatePattern(badExpected, {strict:true}).issues.join('\n'), /Ejecución/);

console.log('PATTERN_EXECUTION_VALIDATOR: PASS');
console.log('PATTERN_EXECUTION_TRANSITIONS: PASS');
console.log('PATTERN_EXECUTION_INCREASE_DECREASE: PASS');
console.log('PATTERN_EXECUTION_REJECTS_IMPOSSIBLE_SEQUENCE: PASS');
console.log('PATTERN_EXECUTION_INTEGRATED_QUALITY_GATE: PASS');
