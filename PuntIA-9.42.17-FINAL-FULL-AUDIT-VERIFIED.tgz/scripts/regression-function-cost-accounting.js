'use strict';
const assert=require('assert');
const {calculateProviderCost,usageOf,PRICING_VERSION}=require('../src/application/cost-accounting-service');

const text=calculateProviderCost({model:'gpt-6-luna',response:{usage:{input_tokens:1000,output_tokens:2000}}});
assert.equal(text.known,true); assert.equal(text.pricingVersion,PRICING_VERSION);
assert(Math.abs(text.usd-0.0011)<1e-12,`unexpected luna cost ${text.usd}`);

const cached=calculateProviderCost({model:'gpt-6.1-sol',response:{usage:{input_tokens:1000,cached_input_tokens:400,output_tokens:500}}});
assert.equal(cached.known,true); assert(Math.abs(cached.usd-0.00628)<1e-12,`unexpected sol cost ${cached.usd}`);

const image=calculateProviderCost({model:'gpt-image-2',response:{usage:{input_tokens:1000,image_input_tokens:500,image_output_tokens:10000}}});
assert.equal(image.known,true); assert(Math.abs(image.usd-0.1545)<1e-12,`unexpected image cost ${image.usd}`);

const missing=calculateProviderCost({model:'gpt-image-2',response:{data:[{b64_json:'x'}]}});
assert.equal(missing.known,false); assert.equal(missing.reason,'PROVIDER_USAGE_NOT_RETURNED'); assert.equal(missing.usd,null);

const unknownModel=calculateProviderCost({model:'future-model',response:{usage:{input_tokens:1,output_tokens:1}}});
assert.equal(unknownModel.known,false); assert.equal(unknownModel.reason,'MODEL_PRICE_NOT_CONFIGURED');

console.log('COST_ACCOUNTING_FUNCTION: PASS');
