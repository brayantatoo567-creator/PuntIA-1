'use strict';
const assert = require('assert');
const { createObservabilityService } = require('../src/application/observability-service');

(async()=>{
  const audit=[];
  const obs=createObservabilityService({}, {audit:{record:async e=>audit.push(e)}});
  assert.equal(await obs.run('provider.test', async()=>42),42);
  assert.equal(obs.snapshot().metrics['provider.test'].count,1);
  assert.ok(Number.isFinite(obs.snapshot().metrics['provider.test'].avgMs));

  await assert.rejects(()=>obs.run('bad name',async()=>1),e=>e.code==='OBSERVABILITY_INVALID_NAME');
  await assert.rejects(()=>obs.run('x/'.repeat(41),async()=>1),e=>e.code==='OBSERVABILITY_INVALID_NAME');

  const metricObs=createObservabilityService({},{});
  for(let i=0;i<64;i++) metricObs.record(`series-${i}`,1,true);
  assert.throws(()=>metricObs.record('series-overflow',1,true),e=>e.code==='OBSERVABILITY_CARDINALITY_LIMIT');

  const circuitObs=createObservabilityService({}, {audit:{record:async e=>audit.push(e)}});
  for(let i=0;i<3;i++) await assert.rejects(()=>circuitObs.run('unstable',async()=>{throw Object.assign(new Error('upstream'),{code:'UPSTREAM_5XX'});},{threshold:3,cooldownMs:60000}));
  assert.equal(circuitObs.health().circuitBreakers.unstable.state,'open');
  await assert.rejects(()=>circuitObs.run('unstable',async()=>99),e=>e.code==='CIRCUIT_OPEN');
  assert.ok(audit.some(e=>e.action==='provider.circuit_open'));
  circuitObs.reset('unstable');
  assert.equal(await circuitObs.run('unstable',async()=>99),99);

  console.log('FUNCTION_13_OBSERVABILITY: PASS');
})().catch(e=>{console.error('FUNCTION_13_OBSERVABILITY: FAIL');console.error(e.stack||e);process.exit(1);});
