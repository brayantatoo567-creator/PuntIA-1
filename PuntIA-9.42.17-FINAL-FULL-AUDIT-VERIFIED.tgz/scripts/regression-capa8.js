'use strict';
const assert=require('assert');
const {createContextualAssistantService}=require('../src/application/contextual-assistant-service');
const valid={initialStitches:6,rounds:[{round:1,inputStitches:6,operations:[{type:'single',count:1,repeats:6}],expectedStitches:6},{round:2,inputStitches:6,operations:[{type:'increase',count:2,repeats:3}],expectedStitches:9}]};
const service=createContextualAssistantService({validatePattern:p=>({qualityOk:p===valid,quality:100})});
const a=service.answer(valid,{currentRound:2,actualStitches:12,question:'¿qué reviso?'}); assert.equal(a.diagnosis.type,'extra_stitches'); assert.match(a.answer,/aumentos/);
const b=service.answer(valid,{currentRound:2,actualStitches:7}); assert.equal(b.diagnosis.type,'missing_stitches');
assert.equal(service.answer({...valid,rounds:[]},{currentRound:2}).code,'PATTERN_NOT_APPROVED');
console.log('Capa 8 regression: PASS');
