'use strict';
const assert = require('assert');
const { createDistributedWorker } = require('../src/application/distributed-worker');
const { normalizeJob } = require('../src/core/contracts');

function job(id='job-00000000-0000-0000-0000-000000000001', attempts=0){return normalizeJob({id,ownerId:'user-1',kind:'pattern',status:'queued',progress:0,attempts,maxAttempts:3,meta:{user:{id:'user-1',plan:'free'},input:{name:'Dragon'}}});}

(async()=>{
  let stored=job(); let executions=0; let heartbeats=0; let claims=0; let acks=0; let requeued=0; let dlq=0;
  const queue={
    async claim(){ return {id:stored.id}; },
    async ack(){acks++;},
    async enqueue(){requeued++;},
    async deadLetter(){dlq++;}
  };
  const repo={
    async claim(id,workerId){ if(stored.status!=='queued') return null; claims++; stored={...stored,status:'running',attempts:stored.attempts+1,workerId}; return stored; },
    async heartbeat(){heartbeats++; return stored;},
    async completeByWorker(id,workerId,result){ if(stored.workerId!==workerId) return null; stored={...stored,status:'completed',result}; return stored; },
    async failByWorker(id,workerId,error,{retry}){ if(stored.workerId!==workerId) return null; stored={...stored,status:retry?'queued':'dead_letter'}; return stored; },
    async recoverStale(){return []}
  };
  const services={patternPipeline:{generate:async()=>{executions++; return {ok:true,structured:{},validation:{qualityOk:true}};}}};
  const worker=createDistributedWorker({queue,jobRepo:repo,services,resolveUser:async(id,u)=>u,pollMs:1,leaseMs:50,heartbeatMs:5});
  await worker.processOne();
  assert.equal(executions,1); assert.equal(claims,1); assert.equal(stored.status,'completed'); assert.equal(acks,1);

  stored=job('job-00000000-0000-0000-0000-000000000002');
  services.patternPipeline.generate=async()=>{await new Promise(r=>setTimeout(r,1100)); const e=Object.assign(new Error('upstream'),{code:'UPSTREAM_5XX'}); throw e;};
  await worker.processOne();
  assert(heartbeats >= 1, 'heartbeat debe renovarse durante un job prolongado');
  assert.equal(stored.status,'queued'); assert.equal(requeued,1); assert.equal(acks,2);

  stored=job('job-00000000-0000-0000-0000-000000000003',2);
  services.patternPipeline.generate=async()=>{const e=Object.assign(new Error('permanent'),{code:'INVALID_PATTERN'}); throw e;};
  await worker.processOne();
  assert.equal(stored.status,'dead_letter'); assert.equal(dlq,1); assert.equal(acks,3);

  const stale=[]; const recoveredRepo={recoverStale:async()=>[{id:'stale-1',status:'queued',kind:'pattern'}]};
  const recoveredQueue={claim:async()=>null,enqueue:async()=>stale.push('stale-1')};
  const recoveryWorker=createDistributedWorker({queue:recoveredQueue,jobRepo:{...recoveredRepo,claim:async()=>null},services,resolveUser:async()=>({id:'user-1'})});
  await recoveryWorker.recover(); assert.deepEqual(stale,['stale-1']);

  console.log(`Capa 26 regression: PASS (claim=${claims}, heartbeat=${heartbeats}, ack=${acks}, retry=${requeued}, dlq=${dlq})`);
})().catch(e=>{console.error('Capa 26 regression: FAIL',e);process.exit(1);});
