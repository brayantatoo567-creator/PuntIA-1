'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');
const html=fs.readFileSync('index.html','utf8');const js=fs.readFileSync('public/app.js','utf8');
for(const v of ['friendly','playful','teacher','focused']) assert(html.includes(`value="${v}"`));
assert(js.includes("localStorage.getItem('puntia.avatarStyle')"));assert(js.includes('applyAvatarStyle'));assert(js.includes('dataset.personality'));
console.log('AVATAR_PERSONALITIES: PASS');console.log('AVATAR_PERSISTENT_PREFERENCE: PASS');console.log('AVATAR_PRESENTATION_ONLY: PASS');console.log('AVATAR_FUNCTION: PASS');
