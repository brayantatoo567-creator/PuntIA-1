# Historial consolidado de releases

Las iteraciones históricas anteriores a 9.42 se consolidaron para evitar decenas de checkpoints redundantes en la raíz del producto. El detalle funcional queda cubierto por la suite de regresión y el código actual.

- 9.42.2 — cost accounting.
- 9.42.3 — visual pipeline.
- 9.42.4 — pattern execution.
- 9.42.5 — concept decomposition.
- 9.42.6 — piece-to-pattern planning.
- 9.42.7 — pattern reader.
- 9.42.8 — pattern editor.
- 9.42.9 — Android/PWA packaging.
- 9.42.10 — deployment hardening.
- 9.42.11 — production security.
- 9.42.12 — release audit.
- 9.42.13 — observability.
- 9.42.14 — pattern Quality Gate.
- 9.42.16 — final architecture hardening: cloud identity/session persistence and repository cleanup.

## 9.42.17 — Final cloud usage/release consistency
- Cloud usage responses now use the PostgreSQL usage ledger consistently across auth and billing endpoints.
- Production Compose image tag synchronized with the release version.
- Final architecture regression strengthened against version drift.

## 9.42.16 — Cloud identity boundary hardening
- Cloud login now authenticates against PostgreSQL and creates PostgreSQL-backed sessions.
- Cloud logout deletes the PostgreSQL session instead of relying on local session storage.
- Cloud billing updates the PostgreSQL user's authoritative plan after Stripe entitlement changes.
- Admin user/billing/overview surfaces use PostgreSQL identity data in cloud mode.
- Added `regression-cloud-identity-boundary.js` to prevent reintroduction of local identity reads in the cloud authentication boundary.
- Fixed persisted vision-model default consistency to `gpt-6-sol`.
